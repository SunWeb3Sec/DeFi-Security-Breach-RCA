# Misconfiguration

Type: Misconfiguration
Date: 20230112
Lost: $90k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/UFDao_exp.sol
Title: UFDao

**Root cause:**

It’s due to the incorrect parameter setting. The attacker bought a public offer of the UF Dao with 1:1 rate using USDC, then redeemed almost all in UF Dao.

**Vulnerable code snippet:**

```jsx
function buyPublicOffer(address _dao, uint256 _lpAmount)
        external
        nonReentrant
        returns (bool)
    {
        require(
            IFactory(factory).containsDao(_dao),
            "Shop: only DAO can sell LPs"
        );

        PublicOffer memory publicOffer = publicOffers[_dao]; **// Vulnerable point**

        require(publicOffer.isActive, "Shop: this offer is disabled");

        IERC20(publicOffer.currency).safeTransferFrom(
            msg.sender,
            _dao,
            (_lpAmount * publicOffer.rate) / 1e18   **// Vulnerable point**
        );

        address lp = IDao(_dao).lp();

        bool b = ILP(lp).mint(msg.sender, _lpAmount);

        require(b, "Shop: mint error");

        return true;
    }
```

![Untitled](Misconfiguration%20fb7129952fe9453aa6423693e6db14f1/Untitled.png)

Image from blocksec

**Attack tx:**

[https://bscscan.com/tx/0x933d19d7d822e84e34ca47ac733226367fbee0d9c0c89d88d431c4f99629d77a](https://bscscan.com/tx/0x933d19d7d822e84e34ca47ac733226367fbee0d9c0c89d88d431c4f99629d77a)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1613507804412940289](https://twitter.com/BlockSecTeam/status/1613507804412940289)