# Arithmetic Overflow

Type: ERC20, Under/Overflow
Date: 20180422
Lost: $900 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20180422-beauty-chain---integer-overflow
Title: Beauty Chain

Root cause:  Arithmetic Overflow

Vulnerable code snippet:

[https://etherscan.io/address/0xc5d105e63711398af9bbff092d4b6769c82f793d#code#L259](https://etherscan.io/address/0xc5d105e63711398af9bbff092d4b6769c82f793d#code#L259)

```solidity
function batchTransfer(address[] _receivers, uint256 _value) public whenNotPaused returns (bool) {
    uint cnt = _receivers.length;
    **uint256 amount = uint256(cnt) * _value;** **//vulnerable point**
    require(cnt > 0 && cnt <= 20);
    require(_value > 0 && balances[msg.sender] >= amount);

    balances[msg.sender] = balances[msg.sender].sub(amount);
    for (uint i = 0; i < cnt; i++) {
        balances[_receivers[i]] = balances[_receivers[i]].add(_value);
        Transfer(msg.sender, _receivers[i], _value);
    }
    return true;
  }
```