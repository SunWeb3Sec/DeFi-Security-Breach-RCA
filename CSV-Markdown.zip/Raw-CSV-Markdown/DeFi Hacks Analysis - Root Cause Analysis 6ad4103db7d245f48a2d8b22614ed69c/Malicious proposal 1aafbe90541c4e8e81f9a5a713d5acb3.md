# Malicious proposal

Type: DAO, MaliciosProposal
Date: 20220214
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220214-buildfinance---dao
Title: BuildFinance

Root cause:  Malicious proposal

Check: [https://twitter.com/finance_build/status/1493223190071554049](https://twitter.com/finance_build/status/1493223190071554049)

The attacker succeeded in the takeover by having a large enough vote in favour of the proposal and there were not enough countervotes to prevent the takeover from happening.