# Deflationary token abuse via skim

Type: Deflationary token, Flashloans, Price Manipulation
Date: 20221212
Lost: $18k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BGLD_exp.sol
Title: BGLD

**Root cause:** 

Deflationary token abuse via skim.

The exploiter reduces the $BGLD reserve in the pair to a deficient level and then swaps out another token (WBNB).

**Vulnerable code snippet:**

[https://www.bscscan.com/address/0xc2319e87280c64e2557a51cb324713dd8d1410a3#code#L636](https://www.bscscan.com/address/0xc2319e87280c64e2557a51cb324713dd8d1410a3#code#L636)

```jsx
function _transfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal {
        require(sender != address(0), "BEP20: transfer from the zero address");
        require(recipient != address(0), "BEP20: transfer to the zero address");
        require(amount > 0, "Transfer amount must be greater than zero");

        uint256 onePercent = _findOnePercent(amount);
        uint256 burnFee = onePercent.mul(2);
        uint256 miningFee = onePercent.mul(4);
        uint256 liquidityFee = onePercent.mul(4);

        if (!_isExcludedFromFee[sender]) {
            require(
                _balances[sender] >
                    amount.add(miningFee).add(liquidityFee).add(burnFee), //vulnerable point
                "BEP20: transfer amount + fees exceeds balance"
            );
        }
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0xea108fe94bfc9a71bb3e4dee4a1b0fd47572e6ad6aba8b2155ac44861be628ae](https://explorer.phalcon.xyz/tx/bsc/0xea108fe94bfc9a71bb3e4dee4a1b0fd47572e6ad6aba8b2155ac44861be628ae)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1602335214356660225](https://twitter.com/BlockSecTeam/status/1602335214356660225)