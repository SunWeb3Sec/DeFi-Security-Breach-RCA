# abused the LP Mining mechanism by Flashloan

Type: Flashloans, staking
Date: 20230103
Lost: $180k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/GDS_exp.sol
Title: GDS

**Root cause:** 

abused the LP Mining mechanism.

The attacker abused the LP Mining mechanism of the GDS token by first adding liquidity with flashloan, and then using multiple contracts to collect rewards.

GDS token will reward the users who add liquidity to (GDS, USDT) pair in each epoch and the reward amount lpRewardAmount = x * LP token holding amount / LP token total supply (x is a global variable). Thus, the more staking amount, the more rewards users can get.

Borrowing 2.38M USDT token with flashloan.

Swapping 0.6M USDT token for 3.4M GDS token.

Adding liquidity for PancakeSwap (1.7M USDT and 3.4M GDS) and get 2.2M LP tokens.

Collecting rewards from GDS token contract and transferring LP tokens to another new contract.

Repeating step 4 for more than 70 times.

Removing liquidity and repaying the flashloan.

1.Borrowing 2.38M USDT token with flashloan.

1. Swapping 0.6M USDT token for 3.4M GDS token.
2. Adding liquidity for PancakeSwap (1.7M USDT and 3.4M GDS) and get 2.2M LP tokens.
3. Collecting rewards from GDS token contract and transferring LP tokens to another new contract.

5.Repeating step 4 for more than 70 times.

6.Removing liquidity and repaying the flashloan.

1.Borrowing 2.38M USDT token with flashloan.

1. Swapping 0.6M USDT token for 3.4M GDS token.
2. Adding liquidity for PancakeSwap (1.7M USDT and 3.4M GDS) and get 2.2M LP tokens.
3. Collecting rewards from GDS token contract and transferring LP tokens to another new contract.

5.Repeating step 4 for more than 70 times.

6.Removing liquidity and repaying the flashloan.

**Vulnerable code snippet:**

```solidity
function _settlementLpMining(address _from)internal {
        uint256 _lpTokenBalance = IERC20(gdsUsdtPair).balanceOf(_from);
        uint256 _lpTokenTotalSupply = IERC20(gdsUsdtPair).totalSupply();
        if(lastEpoch[_from] >0 && currentEpoch > lastEpoch[_from] && _lpTokenBalance>0){
           uint256 _totalRewardAmount= 0;
           for (uint i = lastEpoch[_from]; i < currentEpoch; i++) {
              _totalRewardAmount += everyEpochLpReward[i];
              _totalRewardAmount += everyDayLpMiningAmount;
           }

           uint256 _lpRewardAmount =  _totalRewardAmount*_lpTokenBalance/_lpTokenTotalSupply;
           _internalTransfer(lpPoolContract,_from,_lpRewardAmount,4);

           lastEpoch[_from] = currentEpoch;
        }

        if(lastEpoch[_from] == 0 && _lpTokenBalance >0){
            lastEpoch[_from] = currentEpoch;
        }

        if(_lpTokenBalance == 0){
            lastEpoch[_from] = 0;
        }
    }

```

**Attack tx:** 

[https://bscscan.com/tx/0xf9b6cc083f6e0e41ce5e5dd65b294abf577ef47c7056d86315e5e53aa662251e](https://bscscan.com/tx/0xf9b6cc083f6e0e41ce5e5dd65b294abf577ef47c7056d86315e5e53aa662251e)
[https://bscscan.com/tx/0x2bb704e0d158594f7373ec6e53dc9da6c6639f269207da8dab883fc3b5bf6694](https://bscscan.com/tx/0x2bb704e0d158594f7373ec6e53dc9da6c6639f269207da8dab883fc3b5bf6694)

**Analysis:**

[https://twitter.com/peckshield/status/1610095490368180224](https://twitter.com/peckshield/status/1610095490368180224)

[https://twitter.com/BlockSecTeam/status/1610167174978760704](https://twitter.com/BlockSecTeam/status/1610167174978760704)