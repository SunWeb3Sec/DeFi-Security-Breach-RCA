# Incorrect access control

Type: Access Control, payment
Date: 20220902
Lost: 1,078 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220902-shadowfi---access-control
Title: ShadowFi

Root cause: incorrect access control.

Vulnerable code snippet: 

Due to the public access of burn() method, an attacker burned 10.3M SDF in the pair and then sync'd the price.

Then they swap 8.4 SDF for 1078 BNB (~$298.2K) and transfer to tornato

```solidity
function burn(address account, uint256 _amount) public { **//vulnerable point**
        _transferFrom(account, DEAD, _amount);

        emit burnTokens(account, _amount);
    }
```