# Incorrect owner address validation

Type: Dex/AMM, Insufficient validation
Date: 20221002
Lost: $21 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221002-transit-swap---incorrect-owner-address-validation
Title: Transit Swap

Root cause: Incorrect owner address validation

Vulnerable code snippet:

1.You can input any innocent user who granted approvals to "0xed1afc8c4604958c2f38a3408fa63b32e737c428" before.

2.Contract "0xed1afc8c4604958c2f38a3408fa63b32e737c428" will perform transferFrom to transfer amount of innocent user to attacker.

3.

"function": "claimTokens(address token,address from,address to,uint256 amount)",
"params": [        "0x55d398326f99059fF775485246999027B3197955","0x1aAe0303f795b6FCb185ea9526Aa0549963319Fc",
0x75F2abA6a44580D7be2C4e42885D4a1917bFFD46",
"6312858905558909501615"]

4. No owner address validation

Decompiled contract 0xed1afc8c4604958c2f38a3408fa63b32e737c428

![Untitled](Incorrect%20owner%20address%20validation%205253c642f7934df58adef3d56f0e2926/Untitled.png)