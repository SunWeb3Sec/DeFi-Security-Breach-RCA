# Outdated global variable sellAmount for calculating burnAmount

Type: Miscalculation
Date: 20230524
Lost: 714K USD
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/CS_exp.sol
Title: CS Token

**Root cause:** 

Blocksec: The root cause is that in _transfer(), the burnAmount is calculated from SellAmount, but the issue is that SellAmount is not updated!

Numen: By exploiting the mechanism of burning funds during the transaction, the attacker gradually reduced the quantity of CS tokens in the [BUSD, CS] trading pair.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x8BC6Ce23E5e2c4f0A96429E3C9d482d74171215e#code#L711](https://bscscan.com/address/0x8BC6Ce23E5e2c4f0A96429E3C9d482d74171215e#code#L711)

```jsx
function _transfer(
        address from,
        address to,
        uint256 amount
    ) private {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");
        require(amount > 0, "Transfer amount must be greater than zero");
        require(!blackList[from], "black account");
        require(!blackList[to], "black account");
        if (!canContract && _isContract(msg.sender) && !exPairs[from]) {
            require(whiteContractList[msg.sender], "not allowed contract trade");
        }

        if (!canBuy &&  exPairs[from]){
            require(whiteList[to], "not allow trade");
        }
        if (!canSell &&  exPairs[to]){
            require(whiteList[from], "not allow trade");
        }        

        bool takeTransFee = isTransFee && !feeWhiteList[from] && !feeWhiteList[to] && !exPairs[from] && !exPairs[to] && !_isLiquidity(from,to)  ;
        bool takeSellFee = isSellFee && !feeWhiteList[from] &&  exPairs[to] && !_isLiquidity(from,to);
        bool takeBuyFee = isBuyFee && !feeWhiteList[to] &&  exPairs[from] && !_isLiquidity(from,to);

        if (_isLiquidity(from,to) && exPairs[to]){
            updateLiquidityInfo(amount);
        }

        bool canSell =  sellAmount >= 1;
        if(canSell &&from != address(this) &&from != uniswapV2Pair &&from != owner() && to != owner() && !_isLiquidity(from,to)){
            sync();
        }

        FeeParam memory param;
        if (takeBuyFee){
            require(amount <= limitBuy,"exceeds buying limit!");
            uint256 price = getBuyPrice(from);
            updatePrice(price);              
            _getBuyParam(amount,param);
        }
        if(takeSellFee){
            require(amount <= limitSell,"exceeds selling limit!");
            uint256 price = getSellPrice(to);
            updatePrice(price);
            _getSellParam(amount,param);
            sellAmount = amount;  **//vulnerable point**
            uint256 contractTokenBalance = balanceOf(address(this));
            bool canSwap = contractTokenBalance >= minTokenNumberToSell;

            if (
                canSwap &&
                !inSwapAndLiquify &&
                from != uniswapV2Pair
            ) {
                inSwapAndLiquify = true;

                swapAndLiquify(contractTokenBalance);

                inSwapAndLiquify = false;
            }
        }
        if (takeTransFee){
            _getTransferParam(amount,param);
        }
        if (param.tTransferAmount == 0) {
            param.tTransferAmount = amount;
        }        
        _tokenTransfer(from,to,amount,param);
    }

function sync() private lockTheSync{
        if (totalBurnAmount>=maxBurnAmount){
            return;
        }
        uint256 burnAmount = sellAmount.mul(800).div(1000); **//vulnerable point**
        sellAmount = 0;
```

![Untitled](Outdated%20global%20variable%20sellAmount%20for%20calculatin%2024ac36077042418e97cec969606062f3/Untitled.jpeg)

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0x906394b2ee093720955a7d55bff1666f6cf6239e46bea8af99d6352b9687baa4](https://explorer.phalcon.xyz/tx/bsc/0x906394b2ee093720955a7d55bff1666f6cf6239e46bea8af99d6352b9687baa4)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1661098394130198528](https://twitter.com/BlockSecTeam/status/1661098394130198528)
[https://twitter.com/numencyber/status/1661207123102167041](https://twitter.com/numencyber/status/1661207123102167041)