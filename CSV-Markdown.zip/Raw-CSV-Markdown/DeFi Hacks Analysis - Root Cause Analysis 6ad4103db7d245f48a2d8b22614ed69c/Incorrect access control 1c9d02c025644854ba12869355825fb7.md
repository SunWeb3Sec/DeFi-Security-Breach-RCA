# Incorrect access control

Type: Access Control, MEV
Date: 20220913
Lost: $140 K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220913-mevbot-private-tx
Title: MevBot private tx

Root cause: Incorrect access control.

Vulnerable code snippet:

We can see a public function called pancakeCall, which means anyone can call this function.

1) Decompile contract

[https://bscscan.com/address/0x64dd59d6c7f09dc05b472ce5cb961b6e10106e1d](https://bscscan.com/address/0x64dd59d6c7f09dc05b472ce5cb961b6e10106e1d)
We can see a public function called pancakeCall, which means anyone can call this function.

![Untitled](Incorrect%20access%20control%201c9d02c025644854ba12869355825fb7/Untitled.png)

2)Check pancakeCall code logic
Once pass all required check then perform 0x10a(v0, varg2, varg1);

3) Track into 0x10a(), we can see transfer funds to addree "MEM[varg0.data+32]". Since variable "[http://varg0.data](https://t.co/KT6EufOI6Z)" attacker can control over calldata in pancakeCall. So that's why an attacker can drain out the funds from the MEV contract.

```jsx
function 0x10a(uint256 varg0, uint256 varg1, uint256 varg2) private { 
    require(varg0.data + varg0.length - varg0.data >= 96);
    require(MEM[varg0.data] == address(MEM[varg0.data]));
    v0 = v1 = MEM[varg0.data + 64];
    if (0 == varg2) {
        v2, v3 = msg.sender.token1().gas(msg.gas);
        require(v2); // checks call status, propagates error data on error
        require(MEM[64] + RETURNDATASIZE() - MEM[64] >= 32);
        require(v3 == address(v3));
        goto 0x214;
    } else {
        v4, v3 = msg.sender.token0().gas(msg.gas);
        require(v4); // checks call status, propagates error data on error
        require(MEM[64] + RETURNDATASIZE() - MEM[64] >= 32);
        require(v3 == address(v3));
    }
    if (varg2) {
    }
    v5, v6 = address(v3).transfer(address(MEM[varg0.data]), varg1).gas(msg.gas);  **//vulnerable point**

}
```