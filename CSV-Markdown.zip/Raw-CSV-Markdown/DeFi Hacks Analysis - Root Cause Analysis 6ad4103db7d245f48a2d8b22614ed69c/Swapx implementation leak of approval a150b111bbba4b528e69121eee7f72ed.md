# Swapx implementation leak of  approval

Type: Access Control, Price Manipulation
Date: 20230227
Lost: $1M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SwapX_exp.sol
Title: swapX

**Root cause:**

determined that Contract X mentioned above is the implementation 
contract of SwapX Proxy (not yet verified and audited), the Proxy will 
allow users to pass data and call the implementation contract: [**https://bscscan.com/address/0x0ccee62efec983f3ec4bad3247153009fb483551](https://bscscan.com/address/0x0ccee62efec983f3ec4bad3247153009fb483551)** 

**Vulnerable code snippet:**

```solidity
function swap(
        IERC20 srcToken,
        IERC20 dstToken,
        address dstReceiver,
        uint256 amount,
        uint256 minReturnAmount,
        address referrer,
        bytes calldata data
    ) 
        external 
        payable 
        whenNotPaused
        returns (uint256 returnAmount)
    {
        require(minReturnAmount > 0, "Min return should not be 0");
        require(data.length > 0, "Call data should exist");

        dstReceiver = (dstReceiver == address(0)) ? msg.sender : dstReceiver;
        uint256 initialSrcBalance = srcToken.universalBalanceOf(msg.sender);
        uint256 initialDstBalance = dstToken.universalBalanceOf(dstReceiver);

        {
        (bool success, bytes memory returndata) = swapXImpl.call{value: msg.value}(data); //vulnerable point
        if (!success)  {
            // Look for revert reason and bubble it up if present
            if (returndata.length > 0) {
                // The easiest way to bubble the revert reason is using memory via assembly

                // solhint-disable-next-line no-inline-assembly
                assembly {
                    let returndata_size := mload(returndata)
                    revert(add(32, returndata), returndata_size)
                }
            } else {
                revert("swap failed");
            }
        }
        }
```

```solidity

    function swap(
        IERC20 srcToken,
        IERC20 dstToken,
        address dstReceiver,
        uint256 amount,
        uint256 minReturnAmount,
        address referrer,
        bytes calldata data
    ) 
        external 
        payable 
        whenNotPaused
        returns (uint256 returnAmount)
    {
        require(minReturnAmount > 0, "Min return should not be 0");
        require(data.length > 0, "Call data should exist");

        dstReceiver = (dstReceiver == address(0)) ? msg.sender : dstReceiver;
        uint256 initialSrcBalance = srcToken.universalBalanceOf(msg.sender);
        uint256 initialDstBalance = dstToken.universalBalanceOf(dstReceiver);

        {
        (bool success, bytes memory returndata) = swapXImpl.call{value: msg.value}(data); **//vulnerable point**
        if (!success)  {
            // Look for revert reason and bubble it up if present
            if (returndata.length > 0) {
                // The easiest way to bubble the revert reason is using memory via assembly

                // solhint-disable-next-line no-inline-assembly
                assembly {
                    let returndata_size := mload(returndata)
                    revert(add(32, returndata), returndata_size)
                }
            } else {
                revert("swap failed");
            }
        }
        }
```

**Attack tx:** 

[https://bscscan.com/tx/0x3ee23c1585474eaa4f976313cafbc09461abb781d263547c8397788c68a00160](https://bscscan.com/tx/0x3ee23c1585474eaa4f976313cafbc09461abb781d263547c8397788c68a00160)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1630111965942018049](https://twitter.com/BlockSecTeam/status/1630111965942018049)
[https://twitter.com/peckshield/status/1630100506319413250](https://twitter.com/peckshield/status/1630100506319413250)