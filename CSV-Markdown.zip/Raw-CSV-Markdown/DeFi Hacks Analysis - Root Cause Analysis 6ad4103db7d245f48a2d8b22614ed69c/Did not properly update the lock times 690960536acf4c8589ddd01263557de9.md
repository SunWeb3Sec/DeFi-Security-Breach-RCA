# Did not properly update the lock times

Type: Business Logic Flaw
Date: 20230513
Lost: $30K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Bitpaidio_exp.sol
Title: Bitpaidio

**Root cause:**

Lock_Token() did not properly update the lock times.

**Vulnerable code snippet:**

```solidity

if(sixMonth[msg.sender].reinvest == 0) {

          uint256 startTime = block.timestamp;

          uint256 endTime = block.timestamp + 180 days;

          sixMonth[msg.sender] = TimeLock_Six_Month(msg.sender,total,startTime,endTime,1);

          }

          else {

              uint256 startTime = sixMonth[msg.sender].start_time;

              uint256 endTime = sixMonth[msg.sender].end_time;

              sixMonth[msg.sender] = TimeLock_Six_Month(msg.sender,total,startTime,endTime,1);

          }

```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0x1ae499ccf292a2ee5e550702b81a4a7f65cd03af2c604e2d401d52786f459ba6](https://explorer.phalcon.xyz/tx/bsc/0x1ae499ccf292a2ee5e550702b81a4a7f65cd03af2c604e2d401d52786f459ba6)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1657411284076478465](https://twitter.com/BlockSecTeam/status/1657411284076478465)