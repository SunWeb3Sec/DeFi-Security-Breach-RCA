# Public burn()

Type: Access Control, Flashloans
Date: 20230322
Lost: $30k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BIGFI_exp.sol
Title: BIGFI

**Root cause:**

Public burn() without to proper access control 

**Vulnerable code snippet:**

```solidity
function burn(uint256 _value) public { **// Vulnerable Point: Public Burn function Without proper Access Control**
        _burn(msg.sender, _value);
    }
```

**Attack tx:**

[https://bscscan.com/tx/0x9fe19093a62a7037d04617b3ac4fbf5cb2d75d8cb6057e7e1b3c75cbbd5a5adc](https://bscscan.com/tx/0x9fe19093a62a7037d04617b3ac4fbf5cb2d75d8cb6057e7e1b3c75cbbd5a5adc)

**Analysis:**

[https://twitter.com/HypernativeLabs/status/1638522680654675970](https://twitter.com/HypernativeLabs/status/1638522680654675970)