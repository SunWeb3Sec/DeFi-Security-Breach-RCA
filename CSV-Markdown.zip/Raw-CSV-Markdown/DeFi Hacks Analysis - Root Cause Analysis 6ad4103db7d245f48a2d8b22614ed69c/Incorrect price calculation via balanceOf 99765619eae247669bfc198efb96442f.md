# Incorrect price calculation via balanceOf

Type: ERC20
Date: 20221012
Lost: $127 k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221012-atk---flashloan-manipulate-price
Title: ATK

Root cause: Insecure use balanceOf to calculate price is vulnerable to price manipulation over flash loan.

The calim Function use getPrice() in ASK Token Contract

Vulnerable code snippet:

Incorrect price calculation via balanceOf.

```solidity
function getPrice() public view returns(uint256){
        uint256 UDPrice;
        uint256 UDAmount  = balanceOf(_uniswapV2Pair); **//vulnerable point**
        uint256 USDTAmount = USDT.balanceOf(_uniswapV2Pair); **//vulnerable point**
        UDPrice = UDAmount.mul(10**18).div(USDTAmount);
        return UDPrice;
```

![getPrice.png](Incorrect%20price%20calculation%20via%20balanceOf%2099765619eae247669bfc198efb96442f/getPrice.png)