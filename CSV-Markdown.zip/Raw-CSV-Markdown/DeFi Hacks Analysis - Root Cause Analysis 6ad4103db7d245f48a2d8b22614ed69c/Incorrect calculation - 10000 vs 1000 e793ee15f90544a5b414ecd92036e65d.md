# Incorrect calculation - 10000 vs 1000

Type: Dex/AMM, ERC20, Miscalculation
Date: 20210428
Lost: $50 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210428-uranium---miscalculation
Title: Uranium

Root cause:  Incorrect calculation

Vulnerable code snippet: same Nimbus’s issue

[https://bscscan.com/address/0xA943eA143cd7E79806d670f4a7cf08F8922a454F#code#F3#L180](https://bscscan.com/address/0xA943eA143cd7E79806d670f4a7cf08F8922a454F#code#F3#L180)

inconsistent value in the code, 10000 vs 1000

```solidity
function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external lock {
        require(amount0Out > 0 || amount1Out > 0, 'UraniumSwap: INSUFFICIENT_OUTPUT_AMOUNT');
        (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
        require(amount0Out < _reserve0 && amount1Out < _reserve1, 'UraniumSwap: INSUFFICIENT_LIQUIDITY');

        uint balance0;
        uint balance1;
        { // scope for _token{0,1}, avoids stack too deep errors
        address _token0 = token0;
        address _token1 = token1;
        require(to != _token0 && to != _token1, 'UraniumSwap: INVALID_TO');
        if (amount0Out > 0) _safeTransfer(_token0, to, amount0Out); // optimistically transfer tokens
        if (amount1Out > 0) _safeTransfer(_token1, to, amount1Out); // optimistically transfer tokens
        if (data.length > 0) IUraniumCallee(to).pancakeCall(msg.sender, amount0Out, amount1Out, data);
        balance0 = IERC20(_token0).balanceOf(address(this));
        balance1 = IERC20(_token1).balanceOf(address(this));
        }
        uint amount0In = balance0 > _reserve0 - amount0Out ? balance0 - (_reserve0 - amount0Out) : 0;
        uint amount1In = balance1 > _reserve1 - amount1Out ? balance1 - (_reserve1 - amount1Out) : 0;
        require(amount0In > 0 || amount1In > 0, 'UraniumSwap: INSUFFICIENT_INPUT_AMOUNT');
        { // scope for reserve{0,1}Adjusted, avoids stack too deep errors
        uint balance0Adjusted = balance0.mul(10000).sub(amount0In.mul(16)); **//vulnerable point**
        uint balance1Adjusted = balance1.mul(10000).sub(amount1In.mul(16)); **//vulnerable point**
        require(balance0Adjusted.mul(balance1Adjusted) >= uint(_reserve0).mul(_reserve1).mul(1000**2), 'UraniumSwap: K'); //vulnerable
        }
```