# Incorrect reward calculation

Type: Dex/AMM, Flashloans, Reward, lending
Date: 20220421
Lost: $1 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220421-zeed-finance---reward-distribution-flaw
Title: Zeed Finance

Root cause: incorrect reward calculation.

Vulnerable code snippet:

[https://bscscan.com/address/0xe7748fce1d1e2f2fd2dddb5074bd074745dda8ea#code#L857](https://bscscan.com/address/0xe7748fce1d1e2f2fd2dddb5074bd074745dda8ea#code#L857)

Initially, 5% fee in a selling order were divided into three parts for rewarding liquidity providers. However, based on the token contract loopholes, that part of tokens hadn’t been divided by the system so the LP reward was two times greater than the previous one, leading to extra token distribution.

```solidity
function _takeReward(
        address sender,
        uint256 rewardFee
    ) private {
        if (rewardFee == 0) return;
        uint256 zeedReward = rewardFee.div(2);
        uint256 hoReward = rewardFee.div(2).div(2);
        uint256 usdtReward = rewardFee.sub(zeedReward).sub(hoReward);

        _balances[swapPair] = _balances[swapPair].add(rewardFee); **//vulnerable point**
        emit Transfer(sender, swapPair, usdtReward);

        _balances[swapPairZeed] = _balances[swapPairZeed].add(rewardFee); **//vulnerable point**
        emit Transfer(sender, swapPairZeed, zeedReward);

        _balances[swapPairHo] = _balances[swapPairHo].add(rewardFee); **//vulnerable point**
        emit Transfer(sender, swapPairHo, hoReward);
    }
```