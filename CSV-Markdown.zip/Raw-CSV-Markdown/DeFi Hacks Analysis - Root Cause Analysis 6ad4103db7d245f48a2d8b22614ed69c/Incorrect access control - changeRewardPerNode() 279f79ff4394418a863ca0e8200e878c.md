# Incorrect access control -  changeRewardPerNode()

Type: Access Control
Date: 20221122
Lost: $13k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/AUR_exp.sol
Title: AurumNodePool (AUR)

**Root cause:** 

Incorrect access control.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x70678291bDDfd95498d1214BE368e19e882f7614#code#L578](https://bscscan.com/address/0x70678291bDDfd95498d1214BE368e19e882f7614#code#L578)

The **`changeRewardPerNode`** function lacks proper access control validation, which allows an attacker to call this function and set any value. The attacker first calls the **`changeRewardPerNode`** function to set the daily reward value to an extremely large number. Subsequently, the attacker calls the **`claimNodeReward`** function to extract the node reward, which is calculated based on the **`rewardPerDay`** value that the attacker has set.

```solidity
```
function changeRewardPerNode(uint256 _rewardPerDay) external { //vulnerable point - Incorrect access control
    rewardPerDay = _rewardPerDay;
}
```
```

**Attack tx:**

[https://phalcon.blocksec.com/tx/bsc/0xb3bc6ca257387eae1cea3b997eb489c1a9c208d09ec4d117198029277468e25d](https://phalcon.blocksec.com/tx/bsc/0xb3bc6ca257387eae1cea3b997eb489c1a9c208d09ec4d117198029277468e25d)
[https://phalcon.blocksec.com/tx/bsc/0x7f031e8543e75bd5c85168558be89d2e08b7c02a32d07d76517cdbb10e279782](https://phalcon.blocksec.com/tx/bsc/0x7f031e8543e75bd5c85168558be89d2e08b7c02a32d07d76517cdbb10e279782)

**Analysis:**

[https://twitter.com/AnciliaInc/status/1595142246570958848](https://twitter.com/AnciliaInc/status/1595142246570958848)

[https://quillaudits.medium.com/hackers-steal-42m-from-fenbushi-capital-founders-wallet-dcce2b0a4e5b](https://quillaudits.medium.com/hackers-steal-42m-from-fenbushi-capital-founders-wallet-dcce2b0a4e5b)