# Insufficient validation

Type: Bridge, CrossChain, Insufficient validation
Date: 20220118
Lost: $1.4 million
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220118-multichain-anyswap---insufficient-token-validation
Title: Multichain (Anyswap)

Root cause:  insufficient validation

Vulnerable code snippet:

[https://etherscan.io/address/0x6b7a87899490ece95443e979ca9485cbe7e71522#code#L265](https://etherscan.io/address/0x6b7a87899490ece95443e979ca9485cbe7e71522#code#L265)

Use costom contract to trick contract of Multichain V4Router. without any allowed v, r and s.

```solidity
function anySwapOutUnderlyingWithPermit(
        address from,
        address token, // without validation
        address to,
        uint amount,
        uint deadline,
        uint8 v,
        bytes32 r,
        bytes32 s,
        uint toChainID
    ) external {
        address _underlying = AnyswapV1ERC20(token).underlying();
        IERC20(_underlying).permit(from, address(this), amount, deadline, v, r, s); **//vulnerable point**
        TransferHelper.safeTransferFrom(_underlying, from, token, amount);
        AnyswapV1ERC20(token).depositVault(amount, from);
        _anySwapOut(from, token, to, amount, toChainID);
    }
```