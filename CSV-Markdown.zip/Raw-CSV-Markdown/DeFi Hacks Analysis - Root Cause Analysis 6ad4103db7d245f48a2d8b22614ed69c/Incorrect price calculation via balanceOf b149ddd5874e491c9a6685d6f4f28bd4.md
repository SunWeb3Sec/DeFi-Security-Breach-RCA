# Incorrect price calculation via balanceOf

Type: ERC20, Flashloans, Reward
Date: 20220909
Lost: $742,286
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220909-YYDS---pair-manipulate
Title: YYDS

Root cause: Calculation of reward being too simple and only depends on the pool reserve by balanceOf.

Vulnerable contract (unverified): 0xe70cdd37667cddf52cabf3edabe377c58fae99e9

![Untitled](Incorrect%20price%20calculation%20via%20balanceOf%20b149ddd5874e491c9a6685d6f4f28bd4/Untitled.png)