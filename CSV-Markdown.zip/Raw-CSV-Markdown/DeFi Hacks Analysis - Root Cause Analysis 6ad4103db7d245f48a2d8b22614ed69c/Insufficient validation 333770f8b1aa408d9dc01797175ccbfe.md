# Insufficient validation

Type: DAO, Flashloans, MaliciosProposal, Stablecoin
Date: 20220416
Lost: $182 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220416-beanstalkfarms---dao--flashloan
Title: BeanstalkFarms
fixed?: fixed

Root cause: insufficient validation

Vulnerable code snippet:

As the BIP18 proposal was created one day ago, validation one will be bypassed. By flashloan, the BIP18 proposal gained more than 78% of the vote, which is more than 67%. So proposal executed.

![Untitled](Insufficient%20validation%20333770f8b1aa408d9dc01797175ccbfe/Untitled.png)