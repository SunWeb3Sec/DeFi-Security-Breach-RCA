# delegateCallSwap() function lack of access control

Type: Access Control, Flashloans
Date: 20230307
Lost: $100k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Phoenix_exp.sol
Title: Phoenix

**Root cause:**

PhxProxy contract delegateCallSwap() function lack of access control and can be passed in any parameter

// The lost money is mainly USDC in the d028 contract which the attacker converts into WETH in the 65ba contract through the buyLeverage() function

and then swaps it into his own tokens by the delegateCallSwap() function, making a profit from it

**Vulnerable code snippet:**

```solidity
function delegateCallSwap(bytes memory data) public returns (bytes memory) { //vulnerable point Access control
        (bool success, bytes memory returnData) = phxSwapLib.delegatecall(data);
        assembly {
            if eq(success, 0) {
                revert(add(returnData, 0x20), returndatasize)
            }
        }
        return returnData;
    }
```

**Attack tx:**

[https://polygonscan.com/tx/0x6fa6374d43df083679cdab97149af8207cda2471620a06d3f28b115136b8e2c4](https://polygonscan.com/tx/0x6fa6374d43df083679cdab97149af8207cda2471620a06d3f28b115136b8e2c4)

**Analysis:**

[https://twitter.com/HypernativeLabs/status/1633090456157401088](https://twitter.com/HypernativeLabs/status/1633090456157401088)