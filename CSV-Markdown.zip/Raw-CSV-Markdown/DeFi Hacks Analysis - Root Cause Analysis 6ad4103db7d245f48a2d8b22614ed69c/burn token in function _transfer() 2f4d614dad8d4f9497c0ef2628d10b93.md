# burn token in function _transfer()

Type: Incorrect logic, Sandwich
Date: 20230118
Lost: 22 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Upswing_exp.sol
Title: UPS

**Root cause:**

The attacker transfers zero UPStkn to himself for triggering the internal function releasePressure that further burns the pool's 573,300.39 $UPStkn, which lifts the UPStkn's price.

**Vulnerable code snippet:**

[https://etherscan.io/token/0x35a254223960c18b69c0526c46b013d022e93902#code#F6#L133](https://etherscan.io/token/0x35a254223960c18b69c0526c46b013d022e93902#code#F6#L133)

```jsx
function releasePressure(address _address) internal {
        uint256 amount = myPressure(_address);
        
        if(amount < balanceOf(UNIv2)) {
            require(_totalSupply.sub(amount) >= _initialSupply.div(1000), "There is less than 0.1% of the Maximum Supply remaining, unfortunately, kabooming is over");
            
            sellPressure[_address] = 0;
            addToSteam(_address, amount);
            
            ERC20._burn(UNIv2, amount); **//vulnerable point**

            _UPSBurned = _UPSBurned.add(amount);
            emit BurnedFromLiquidityPool(_address, amount);
            
            _generateSteamFromUPSBurn(_address);
            emit SteamGenerated(_address, amount);
            
            txCount[_address] = 0;
        } else if (amount > 0) {
            sellPressure[_address] = sellPressure[_address].div(2);
        }
```

**Attack tx:**

[https://etherscan.io/tx/0x4b3df6e9c68ae482c71a02832f7f599ff58ff877ec05fed0abd95b31d2d7d912](https://etherscan.io/tx/0x4b3df6e9c68ae482c71a02832f7f599ff58ff877ec05fed0abd95b31d2d7d912)

**Analysis:**

[https://twitter.com/QuillAudits/status/1615634917802807297](https://twitter.com/QuillAudits/status/1615634917802807297)