# Incorrect logic

Type: Bridge, CrossChain, Incorrect logic
Date: 20210710
Lost: $8 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210710-chainswap---bridge-logic-flaw
Title: Chainswap
fixed?: fixed

Root cause:  incorrect logic

Check

[https://medium.com/wilder-world/important-update-chainswap-hack-cf2153480887](https://medium.com/wilder-world/important-update-chainswap-hack-cf2153480887)

[https://rekt.news/chainswap-rekt/](https://rekt.news/chainswap-rekt/)