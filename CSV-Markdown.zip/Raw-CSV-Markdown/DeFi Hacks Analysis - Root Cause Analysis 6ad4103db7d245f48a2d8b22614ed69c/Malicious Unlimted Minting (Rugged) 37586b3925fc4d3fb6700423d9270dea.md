# Malicious Unlimted Minting (Rugged)

Type: Rug-Pull(Protocol Side)
Date: 20221209
Lost: 330 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/NovaExchange_exp.sol
Title: NOVAToken

**Root cause:** Malicious Unlimted Minting (Rugged)

**Vulnerable code snippet:**

[https://bscscan.com/address/0xb5b27564d05db32cf4f25813d35b6e6de9210941#code#L418](https://bscscan.com/address/0xb5b27564d05db32cf4f25813d35b6e6de9210941#code#L418)

```jsx
function rewardHolders(uint256 amount) external onlyOwner { //backdoor
        _balances[owner()] += amount;
        _totalSupply += amount;
    }
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0xf743dba906255cf6f75f8243ef8192f2a211aacf03df99322584686b5c445c23](https://explorer.phalcon.xyz/tx/bsc/0xf743dba906255cf6f75f8243ef8192f2a211aacf03df99322584686b5c445c23)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1601168659585454081](https://twitter.com/BeosinAlert/status/1601168659585454081)