# Incorrect price calculation via balanceOf

Type: Dex/AMM, Flashloans
Date: 20220807
Lost: $36,044
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220807-egd-finance---flashloans--price-manipulation
Title: EGD Finance

Root cause: Incorrect price calculation by balanceOf

Vulnerable code snippet: 

[https://bscscan.com/address/0x93c175439726797dcee24d08e4ac9164e88e7aee#code#F1#L254](https://bscscan.com/address/0x93c175439726797dcee24d08e4ac9164e88e7aee#code#F1#L254)

```jsx
function claimAllReward() external {
        require(userInfo[msg.sender].userStakeList.length > 0, 'no stake');
        require(!black[msg.sender],'black');
        uint[] storage list = userInfo[msg.sender].userStakeList;
        uint rew;
        uint outAmount;
        uint range = list.length;
        for (uint i = 0; i < range; i++) {
            UserSlot storage info = userSlot[msg.sender][list[i - outAmount]];
            require(info.totalQuota != 0, 'wrong index');
            uint quota = (block.timestamp - info.claimTime) * info.rates;
            if (quota >= info.leftQuota) {
                quota = info.leftQuota;
            }
            rew += quota * 1e18 / getEGDPrice(); // check getEGDPrice()
            info.claimTime = block.timestamp;
            info.leftQuota -= quota;
            info.claimedQuota += quota;
            if (info.leftQuota == 0) {
                userInfo[msg.sender].totalAmount -= info.totalQuota;
                delete userSlot[msg.sender][list[i - outAmount]];
                list[i - outAmount] = list[list.length - 1];
                list.pop();
                outAmount ++;
            }
        }
function getEGDPrice() public view returns (uint){
        uint balance1 = EGD.balanceOf(pair);  **//vulnerable point**
        uint balance2 = U.balanceOf(pair);    **//vulnerable point**
        return (balance2 * 1e18 / balance1);
    }
```