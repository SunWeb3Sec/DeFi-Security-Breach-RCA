# doubles reward the tax fee to the pancake pair

Type: ERC20, skim
Date: 20230110
Lost: $224K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BRA.exp.sol
Title: BRA

**Root cause:** 

The root cause is due to a logic flaw of the BRA contract, which doubles reward the tax fee to the pancake pair without invoking the sync() function after transferring.

**Vulnerable code snippet:**

```solidity
function _transfer(address sender, address recipient, uint amount) internal {
        require(sender != address(0), "BEP20: transfer from the zero address");

        bool recipientAllow = ConfigBRA(BRA).isAllow(recipient);
        bool senderAllowSell = ConfigBRA(BRA).isAllowSell(sender);

        uint BuyPer = ConfigBRA(BRA).BuyPer();
        uint SellPer = ConfigBRA(BRA).SellPer();

        address BuyTaxTo_ = address(0);
        address SellTaxTo_ = address(0);

        _balances[sender] = _balances[sender].sub(amount, "BEP20: transfer amount exceeds balance");

        uint256 finalAmount = amount;
        uint256 taxAmount = 0;
  
        if(sender==uniswapV2Pair&&!recipientAllow){
            taxAmount = amount.div(10000).mul(BuyPer);
            BuyTaxTo_ = ConfigBRA(BRA).BuyTaxTo();
        }

        if(recipient==uniswapV2Pair&&!senderAllowSell){
            taxAmount = amount.div(10000).mul(SellPer);
            SellTaxTo_ = ConfigBRA(BRA).SellTaxTo();
        }

        finalAmount = finalAmount - taxAmount;

        if(BuyTaxTo_ != address(0)){
            _balances[BuyTaxTo_] = _balances[BuyTaxTo_].add(taxAmount);
            emit Transfer(sender, BuyTaxTo_, taxAmount);
        }

        if(SellTaxTo_ != address(0)){
            _balances[SellTaxTo_] = _balances[SellTaxTo_].add(taxAmount);
            emit Transfer(sender, SellTaxTo_, taxAmount);
        }
        
        _balances[recipient] = _balances[recipient].add(finalAmount);
        
        if (recipient == address(0) ) {
            totalBurn = totalBurn.add(amount);
            _totalSupply = _totalSupply.sub(amount);
            emit Burn(sender, address(0), amount);
        }
        emit Transfer(sender, recipient, finalAmount);
  
    }

```

**Attack tx:** 

0x6759db55a4edec4f6bedb5691fc42cf024be3a1a534ddcc7edd471ef205d4047 (profit 675 WBNB)
0x4e5b2efa90c62f2b62925ebd7c10c953dc73c710ef06695eac3f36fe0f6b9348 (profit 144 WBNB)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1612701106982862849](https://twitter.com/BlockSecTeam/status/1612701106982862849)