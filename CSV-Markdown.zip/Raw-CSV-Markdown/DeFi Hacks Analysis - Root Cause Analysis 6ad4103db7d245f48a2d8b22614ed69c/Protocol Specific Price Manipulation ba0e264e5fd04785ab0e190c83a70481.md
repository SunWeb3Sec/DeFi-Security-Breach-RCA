# Protocol Specific Price Manipulation

Type: Price Manipulation
Date: 20230529
Lost: $8M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Jimbo_exp.sol
Title: Jimbo

**Root cause:**

This attack exploited a vulnerability in the JimboController contract, which allows anyone to use the shift() function to make the contract execute liquidity removal and addition operations. The shift() function takes the funds of the contract to add liquidity, resulting in all the WETH of the JimboController contract being added as liquidity.

Since the prices of WETH and JIMBO in the pool are not balanced, when adding liquidity, the required token quantity will be calculated based on the current price, allowing the attacker to obtain more WETH.

**Vulnerable code snippet:**

[https://arbiscan.io/address/0x271944d9D8CA831F7c0dBCb20C4ee482376d6DE7#code#F1#L308](https://arbiscan.io/address/0x271944d9D8CA831F7c0dBCb20C4ee482376d6DE7#code#F1#L308)

```jsx
function shift() public returns (bool) { **//vulnerable point**
        if (canShift()) {
            // Let the token know the protocol is rebalancing
            jimbo.setIsRebalancing(true);

            // Get the active bin
            uint24 activeBin = pair.getActiveId();

            // Remove all non-floor bin liquidity (max bin -> anchor bin)
            _removeNonFloorLiquidity();

            // Remove all floor bin liquidity
            _removeFloorLiquidity();

            // Count the total JIMBO and ETH in the contract after liquidity removal
            uint256 totalJimboInPool = jimbo.balanceOf(address(this));
            uint256 totalEthInContract = weth.balanceOf(address(this));

            // Floor is based on total eth / circulating supply
            uint256 totalCirculatingJimbo = jimbo.totalSupply() -
                jimbo.balanceOf(address(0)) -
                totalJimboInPool;

            // Calculate the new target floor bin
            uint24 newFloorBin = _calculateNewFloorBin(
                totalEthInContract,
                totalCirculatingJimbo
            );

            // Calculate new anchor bin id
            // Make sure you use the new floor bin and not the stale one
            uint24 newAnchorBin = activeBin - newFloorBin > NUM_ANCHOR_BINS
                ? activeBin - NUM_ANCHOR_BINS
                : activeBin - 1;

            // Set internal bin state
            _setBinState({
                floorBin_: newFloorBin,
                anchorBin_: newAnchorBin, // this is not always true
                triggerBin_: activeBin + NUM_ANCHOR_BINS,
                maxBin_: activeBin + NUM_LIQ_BINS - 1 // decrement because we are adding inclusive of active bin
            });

            // Deploy all the JIMBO liquidity first
            _deployJimboLiquidity();  **//vulnerable point**

            // Deploy floor bin liquidity with 90% of all ETH in the contract
            _deployFloorLiquidity((weth.balanceOf(address(this)) * 90) / 100); **//vulnerable point**

            // Use entire remaining weth balance in the contract to deploy anchors
            _deployAnchorLiquidity(weth.balanceOf(address(this))); **//vulnerable point**

            // Let the token know we are done rebalancing to apply taxes
            jimbo.setIsRebalancing(false);
            return true;
        } else return false;
    }
```

**Attack tx:**

[https://arbiscan.io/tx/0xf9baf8cee8973cf9700ae1b1f41c625d7a2abdbcbc222582d24a8f2f790d0b5a](https://arbiscan.io/tx/0xf9baf8cee8973cf9700ae1b1f41c625d7a2abdbcbc222582d24a8f2f790d0b5a)
[https://arbiscan.io/tx/0xfda5464e97043a2d0093cbed6d0a64f6a86049f5e9608c014396a7390188670e](https://arbiscan.io/tx/0xfda5464e97043a2d0093cbed6d0a64f6a86049f5e9608c014396a7390188670e)
[https://arbiscan.io/tx/0x3c6e053faecd331883641c1d23c9d9d37d065e4f9c4086e94a3c34bf8702618a](https://arbiscan.io/tx/0x3c6e053faecd331883641c1d23c9d9d37d065e4f9c4086e94a3c34bf8702618a)
[https://arbiscan.io/tx/0x44a0f5650a038ab522087c02f734b80e6c748afb207995e757ed67ca037a5eda](https://arbiscan.io/tx/0x44a0f5650a038ab522087c02f734b80e6c748afb207995e757ed67ca037a5eda)

**Analysis:**

[https://twitter.com/cryptofishx/status/1662888991446941697](https://twitter.com/cryptofishx/status/1662888991446941697)
[https://twitter.com/yicunhui2/status/1663793958781353985](https://twitter.com/yicunhui2/status/1663793958781353985)