# Arbitrary call via write()

Type: Arbitrary call, Yield
Date: 20220326
Lost: $726 K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220326-auctus
Title: Auctus

Root cause: arbitrary call via write().

Vulnerable code snippet:

[https://etherscan.io/address/0xE7597F774fD0a15A617894dc39d45A28B97AFa4f#code#F1#L101](https://etherscan.io/address/0xE7597F774fD0a15A617894dc39d45A28B97AFa4f#code#F1#L101)

exchangeData is controllable and without any input validation. 

Vulnerable point: [https://etherscan.io/address/0xE7597F774fD0a15A617894dc39d45A28B97AFa4f#code#F1#L135](https://etherscan.io/address/0xE7597F774fD0a15A617894dc39d45A28B97AFa4f#code#F1#L135)

```solidity
function write(
        address acoToken, 
        uint256 collateralAmount, 
        address exchangeAddress, 
        bytes memory exchangeData 
    ) 
        nonReentrant 
        setExchange(exchangeAddress) 
        public 
        payable 
    {
        require(msg.value > 0,  "ACOWriter::write: Invalid msg value");
        require(collateralAmount > 0,  "ACOWriter::write: Invalid collateral amount");
        
        address _collateral = IACOToken(acoToken).collateral();
        if (_isEther(_collateral)) {
            IACOToken(acoToken).mintToPayable{value: collateralAmount}(msg.sender);
        } else {
            _transferFromERC20(_collateral, msg.sender, address(this), collateralAmount);
            _approveERC20(_collateral, acoToken, collateralAmount);
            IACOToken(acoToken).mintTo(msg.sender, collateralAmount);
        }
        
        _sellACOTokens(acoToken, exchangeData);
    }
/**
     * @dev Internal function to sell the ACO tokens and transfer the premium to the transaction sender.
     * @param acoToken Address of the ACO token.
     * @param exchangeData Data to be sent to the exchange.
     */
    function _sellACOTokens(address acoToken, bytes memory exchangeData) internal {
        uint256 acoBalance = _balanceOfERC20(acoToken, address(this));
        _approveERC20(acoToken, erc20proxy, acoBalance);
        (bool success,) = _exchange.call{value: address(this).balance}(exchangeData); **//vulnerable point**
        require(success, "ACOWriter::_sellACOTokens: Error on call the exchange");
```