# Incorrect access control

Type: Access Control, Dex/AMM
Date: 20200618
Lost: $545,000
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20200618-bancor-protocol---access-control
Title: Bancor Protocol
fixed?: fixed

Root cause:  incorrect access control

Vulnerable code snippet: 

[https://etherscan.io/address/0x5f58058c0ec971492166763c8c22632b583f667f#code#L551](https://etherscan.io/address/0x5f58058c0ec971492166763c8c22632b583f667f#code#L551)

```solidity
function safeTransferFrom(IERC20Token _token, address _from, address _to, uint256 _value) public { **//vulnerable point**
       execute(_token, abi.encodeWithSelector(TRANSFER_FROM_FUNC_SELECTOR, _from, _to, _value));
    }
```

fixed

```solidity
function safeTransferFrom(IERC20Token _token, address _from, address _to, uint256 _value) internal {
       execute(_token, abi.encodeWithSelector(TRANSFER_FROM_FUNC_SELECTOR, _from, _to, _value));
    }
```