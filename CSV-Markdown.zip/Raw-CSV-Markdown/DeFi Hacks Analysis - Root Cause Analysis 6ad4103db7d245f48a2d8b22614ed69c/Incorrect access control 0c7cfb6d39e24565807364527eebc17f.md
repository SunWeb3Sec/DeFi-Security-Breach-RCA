# Incorrect access control

Type: Access Control, Dex/AMM
Date: 20210308
Lost: $700,000
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210308-dodo---flashloan-attack
Title: DODO

Root cause:  Incorrect access control

Vulnerable code snippet:

[https://etherscan.io/address/0x051ebd717311350f1684f89335bed4abd083a2b6#code#L1419](https://etherscan.io/address/0x051ebd717311350f1684f89335bed4abd083a2b6#code#L1419)

The init() function in the pool creation contract could be called multiple times, leading to repeated initializations. The attackers took advantage of this and borrowed out the tokens in the liquidity pools using flash loans. The pool contract was then initialized again and counterfeit tokens created by the attackers were returned in lieu of the original tokens, bypassing the flash loan return check logic.

```solidity
function init(   
        address maintainer,
        address baseTokenAddress,
        address quoteTokenAddress,
        uint256 lpFeeRate,
        address mtFeeRateModel,
        uint256 i,
        uint256 k,
        bool isOpenTWAP
    ) external { **//vulnerable point**
        require(baseTokenAddress != quoteTokenAddress, "BASE_QUOTE_CAN_NOT_BE_SAME");
        _BASE_TOKEN_ = IERC20(baseTokenAddress);
        _QUOTE_TOKEN_ = IERC20(quoteTokenAddress);

        require(i > 0 && i <= 10**36);
        _I_ = i;

        require(k <= 10**18);
        _K_ = k;

        _LP_FEE_RATE_ = lpFeeRate;
        _MT_FEE_RATE_MODEL_ = IFeeRateModel(mtFeeRateModel);
        _MAINTAINER_ = maintainer;

        _IS_OPEN_TWAP_ = isOpenTWAP;
        if(isOpenTWAP) _BLOCK_TIMESTAMP_LAST_ = uint32(block.timestamp % 2**32);

        string memory connect = "_";
        string memory suffix = "DLP";

        name = string(abi.encodePacked(suffix, connect, addressToShortString(address(this))));
        symbol = "DLP";
        decimals = _BASE_TOKEN_.decimals();

        // ============================== Permit ====================================
        uint256 chainId;
        assembly {
            chainId := chainid()
        }
        DOMAIN_SEPARATOR = keccak256(
            abi.encode(
                // keccak256('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)'),
                0x8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f,
                keccak256(bytes(name)),
                keccak256(bytes("1")),
                chainId,
                address(this)
            )
        );
        // ==========================================================================
    }
```