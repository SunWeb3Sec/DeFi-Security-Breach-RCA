# Insufficient validation

Type: ERC721, Insufficient validation
Date: 20220626
Lost: $3.87M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220626-xcarnival---infinite-number-of-loans
Title: XCarnival

Root cause:  call XToken contract's borrow(), there is no judgment that the NFT has been withdrawn.

Vulnerable code snippet:

[https://etherscan.io/address/0x39360ac1239a0b98cb8076d4135d0f72b7fd9909#code#F1#L108](https://etherscan.io/address/0x39360ac1239a0b98cb8076d4135d0f72b7fd9909#code#F1#L108)

Parameter xToken can control, attakcer can withdraw pledged NFT.

```solidity
function pledgeAndBorrow(address _collection, uint256 _tokenId, uint256 _nftType, address xToken, uint256 borrowAmount) external nonReentrant {
        uint256 orderId = pledgeInternal(_collection, _tokenId, _nftType);
        IXToken(xToken).borrow(orderId, payable(msg.sender), borrowAmount); **//vulnerable point**
    }
```