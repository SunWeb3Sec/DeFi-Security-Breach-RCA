# Lack Slippage Protection

Type: Slippage
Date: 20230529
Lost: $135k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BabyDogeCoin_exp.sol
Title: BabyDogeCoin

**Root cause:**

smhkptking: FarmZAP contract enjoys 0 tax of babydoge buy/sell, attacker manipulated pancake pair price.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x451583b6da479eaa04366443262848e27706f762#code#F1#L184](https://bscscan.com/address/0x451583b6da479eaa04366443262848e27706f762#code#F1#L184)

```jsx
/*
     * @notice Swaps input token to ERC20 token and deposits on behalf of msg.sender to specified farm
     * @param farm Farm address, where tokens should be deposited
     * @param amountIn Amount of input tokens
     * @param amountOutMin Minimum amount of tokens to receive
     * @param path Address path to swap input token
     * @return Received token amount
     * @dev Last element of path must be stake token
     * @dev First element of path must be input token
     */
    function buyTokensAndDepositOnBehalf(
        IFarm farm,
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path
    ) external payable returns(uint256) {
        if (msg.value > 0) {
            require(address(WBNB) == path[0], "Input token != WBNB");
            require(amountIn == msg.value, "Invalid msg.value");
            WBNB.deposit{value: amountIn}();
        } else {
            IERC20(path[0]).transferFrom(msg.sender, address(this), amountIn);
        }
        address tokenOut = path[path.length - 1];
        require(tokenOut == farm.stakeToken(), "Not a stake token");

        _approveIfRequired(path[0], address(router), amountIn);
        router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
            amountIn,
            amountOutMin,
            path,
            address(this),
            block.timestamp + 1200
        );
        uint256 received = IERC20(tokenOut).balanceOf(address(this));

        _approveIfRequired(tokenOut, address(farm), received);
        farm.depositOnBehalf(received, msg.sender);

        emit TokensBoughtAndDeposited (
            address(farm),
            msg.sender,
            path[0],
            tokenOut,
            amountIn,
            received
        );

        return received;
    }
```

**Attack tx:**

[https://bscscan.com/tx/0x098e7394a1733320e0887f0de22b18f5c71ee18d48a0f6d30c76890fb5c85375](https://bscscan.com/tx/0x098e7394a1733320e0887f0de22b18f5c71ee18d48a0f6d30c76890fb5c85375)

**Analysis:**

[https://twitter.com/Phalcon_xyz/status/1662744426475831298](https://twitter.com/Phalcon_xyz/status/1662744426475831298)