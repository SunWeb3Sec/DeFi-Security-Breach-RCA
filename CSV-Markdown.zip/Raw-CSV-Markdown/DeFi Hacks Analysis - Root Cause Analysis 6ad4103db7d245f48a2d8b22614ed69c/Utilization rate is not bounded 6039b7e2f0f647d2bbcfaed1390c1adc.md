# Utilization rate is not bounded

Type: Donate, Math, Under/Overflow
Date: 20230427
Lost: -
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/silo_finance.t.sol
Title: Silo finance

**Root cause:** 

dump utilization ratio by borrowing donated token

Fix: bound utilizationRate to be < 100

**Vulnerable code snippet:**

```jsx
    function calculateCurrentInterestRate(
        Config memory _c,
        uint256 _totalDeposits,
        uint256 _totalBorrowAmount,
        uint256 _interestRateTimestamp,
        uint256 _blockTimestamp
    ) public pure override returns (uint256 rcur) {
        if (_interestRateTimestamp > _blockTimestamp) revert InvalidTimestamps();

        // struct for local vars to avoid "Stack too deep"
        LocalVarsRCur memory _l = LocalVarsRCur(0,0,0,0,0,0,false);

        (,,,_l.overflow) = calculateCompoundInterestRateWithOverflowDetection(
            _c,
            _totalDeposits,
            _totalBorrowAmount,
            _interestRateTimestamp,
            _blockTimestamp
        );

        if (_l.overflow) {
            return 0;
        }

        // There can't be an underflow in the subtraction because of the previous check
        unchecked {
            // T := t1 - t0 # length of time period in seconds
            _l.T = (_blockTimestamp - _interestRateTimestamp).toInt256();
        }

        _l.u = EasyMath.calculateUtilization(DP, _totalDeposits, _totalBorrowAmount).toInt256();
        _l.DP = int256(DP);

        if (_l.u > _c.ucrit) {
            // rp := kcrit *(1 + Tcrit + beta *T)*( u0 - ucrit )
            _l.rp = _c.kcrit * (_l.DP + _c.Tcrit + _c.beta * _l.T) / _l.DP * (_l.u - _c.ucrit) / _l.DP;
        } else {
            // rp := min (0, klow * (u0 - ulow ))
            _l.rp = _min(0, _c.klow * (_l.u - _c.ulow) / _l.DP);
        }

        // rlin := klin * u0 # lower bound between t0 and t1
        _l.rlin = _c.klin * _l.u / _l.DP;
        // ri := max(ri , rlin )
        _l.ri = _max(_c.ri, _l.rlin);
        // ri := max(ri + ki * (u0 - uopt ) * T, rlin )
        _l.ri = _max(_l.ri + _c.ki * (_l.u - _c.uopt) * _l.T / _l.DP, _l.rlin);
        // rcur := max (ri + rp , rlin ) # current per second interest rate
        rcur = (_max(_l.ri + _l.rp, _l.rlin)).toUint256();
        rcur *= 365 days;
    }
```

**Attack tx:**

[https://github.com/silo-finance/silo-core-v1/blob/master/contracts/InterestRateModel.sol#L134](https://github.com/silo-finance/silo-core-v1/blob/master/contracts/InterestRateModel.sol#L134)

**Analysis:**

[https://medium.com/immunefi/silo-finance-logic-error-bugfix-review-35de29bd934a](https://medium.com/immunefi/silo-finance-logic-error-bugfix-review-35de29bd934a)