# Incorrect access control

Type: Access Control, lending
Date: 20220415
Lost: $1.1 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220415-rikkei-finance---access-control--price-oracle-manipulation
Title: Rikkei Finance

Root cause: incorrect access control

Vulnerable code snippet:

[https://bscscan.com/address/0xd55f01b4b51b7f48912cd8ca3cdd8070a1a9dba5#code#F1#L29](https://bscscan.com/address/0xd55f01b4b51b7f48912cd8ca3cdd8070a1a9dba5#code#F1#L29)

SetOracleData() function whose visibility is public and can be called externally. Anyone can call SetOracleData to manipulate price.

```solidity
function setOracleData(address rToken, oracleChainlink _oracle) external { **//vulnerable point**
        oracleData[rToken] = _oracle;
    }
```