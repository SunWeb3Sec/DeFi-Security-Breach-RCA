# Incorrect Oracle Implementation

Type: Insufficient validation, Oracle
Date: 20230202
Lost: $88M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BonqDAO_exp.sol
Title: BonqDAO

**Root cause:** 

Price Oracle manipulation due to incorrect integration of the Tellor Oracle. 

**Vulnerable code snippet:**

[https://polygonscan.com/address/0x8f55d884cad66b79e1a131f6bcb0e66f4fd84d5b#code#F2#L282](https://polygonscan.com/address/0x8f55d884cad66b79e1a131f6bcb0e66f4fd84d5b#code#F2#L282)

```solidity
function submitValue(
        bytes32 _queryId,
        bytes calldata _value,
        uint256 _nonce,
        bytes calldata _queryData
    ) external {
        require(keccak256(_value) != keccak256(""), "value must be submitted");
        Report storage _report = reports[_queryId];
        require(
            _nonce == _report.timestamps.length || _nonce == 0,
            "nonce must match timestamp index"
        );
        StakeInfo storage _staker = stakerDetails[msg.sender];
        require(
            _staker.stakedBalance >= stakeAmount, // Its checks if the staker balance is more than stakeAmount i.e. 10 TRB
            "balance must be greater than stake amount"
        ); 

        require(
            (block.timestamp - _staker.reporterLastTimestamp) * 1000 >
                (reportingLock * 1000) / (_staker.stakedBalance / stakeAmount),
            "still in reporter time lock, please wait!"
        );
				....
				....
        _report.timestampIndex[block.timestamp] = _report.timestamps.length;
        _report.timestamps.push(block.timestamp);
        _report.timestampToBlockNum[block.timestamp] = block.number;
        _report.valueByTimestamp[block.timestamp] = _value; // Vulnerable Point: The value is assigned here. Anyone who has staked 10TRB can submit the balance. 
        _report.reporterByTimestamp[block.timestamp] = msg.sender;
        // Disperse Time Based Reward
        uint256 _reward = ((block.timestamp - timeOfLastNewValue) * timeBasedReward) / 300; //.5 TRB per 5 minutes
```

**Attack tx:**

1st Txn: [0x31957ecc43774d19f54d9968e95c69c882468b46860f921668f2c55fadd51b19](https://polygonscan.com/tx/0x31957ecc43774d19f54d9968e95c69c882468b46860f921668f2c55fadd51b19)

2nd Txn: ****[0xa02d0c3d16d6ee0e0b6a42c3cc91997c2b40c87d777136dedebe8ee0f47f32b1](https://polygonscan.com/tx/0xa02d0c3d16d6ee0e0b6a42c3cc91997c2b40c87d777136dedebe8ee0f47f32b1)

**Analysis:**

[https://quillaudits.medium.com/decoding-bonq-daos-120-million-exploit-quillaudits-bd8e50eec4ac](https://quillaudits.medium.com/decoding-bonq-daos-120-million-exploit-quillaudits-bd8e50eec4ac)

[https://twitter.com/BlockSecTeam/status/1621043757390123008](https://twitter.com/BlockSecTeam/status/1621043757390123008)