# Incorrect access control

Type: Access Control, ERC721
Date: 20210607
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210607-88mph-nft---access-control
Title: 88mph
fixed?: fixed

Root cause:  incorrect access control

Vulnerable code snippet: 

[https://etherscan.io/address/0xF0b7DE03134857391d8D43Ed48e20EDF21461097#code#F14#L39](https://etherscan.io/address/0xF0b7DE03134857391d8D43Ed48e20EDF21461097#code#F14#L39)

Contract init function without modifier check and there was also no initializer modifier to prevent a re-initialization. Anyone could have taken ownership of the NFT contract.

```solidity
function init(  **//vulnerable point,** without modifier check
        address newOwner,
        string calldata tokenName,
        string calldata tokenSymbol
    ) external {
        _transferOwnership(newOwner);
        _tokenName = tokenName;
        _tokenSymbol = tokenSymbol;

        // register the supported interfaces to conform to ERC721 via ERC165
        _registerInterface(_INTERFACE_ID_ERC721_METADATA);

        // Derived contracts need only register support for their own interfaces,
        // we register support for ERC165 itself here
        _registerInterface(_INTERFACE_ID_ERC165);

        // register the supported interfaces to conform to ERC721 via ERC165
        _registerInterface(_INTERFACE_ID_ERC721);
    }
```