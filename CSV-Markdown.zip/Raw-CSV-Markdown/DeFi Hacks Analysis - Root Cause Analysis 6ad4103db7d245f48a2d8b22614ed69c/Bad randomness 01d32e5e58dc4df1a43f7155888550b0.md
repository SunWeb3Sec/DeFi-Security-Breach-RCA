# Bad randomness

Type: Bad randomness, NFT
Date: 20220824
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220824-luckeytiger-nft---predicting-random-numbers
Title: LuckeyTiger

Root cause: bad randomness.

Vulnerable code snippet: 

[https://etherscan.io/address/0x9c87a5726e98f2f404cdd8ac8968e9b2c80c0967#code#L1440](https://etherscan.io/address/0x9c87a5726e98f2f404cdd8ac8968e9b2c80c0967#code#L1440)

Due to bad randomness we can predict it for infinite minting.

```solidity
function _getRandom() private returns(bool) {
        uint256 random = uint256(keccak256(abi.encodePacked(block.difficulty, block.timestamp))); **//vulnerable point**
        uint256 rand = random%2;
        if(rand == 0){return lucky = false;}
        else         {return lucky = true;}
    }
```