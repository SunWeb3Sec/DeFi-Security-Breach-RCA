# Incorrect access control

Type: Access Control, ERC20
Date: 20221017
Lost: $2.4 K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221017-uerii-token---access-control
Title: Uerii

Root cause:  Incorrect access control

Vulnerable code snippet:

[https://etherscan.io/address/0x418c24191ae947a78c99fdc0e45a1f96afb254be#code#L493](https://etherscan.io/address/0x418c24191ae947a78c99fdc0e45a1f96afb254be#code#L493)

```solidity
function mint() public returns (bool) { **//vulnerable point**
        _mint( msg.sender, 100000000000000000 );
        return true;
    }
```