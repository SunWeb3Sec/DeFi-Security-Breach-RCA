# Incorrect calculation & Deflationary token uncompatible

Type: Deflationary token, Miscalculation, Stablecoin
Date: 20210628
Lost: $0.2 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210628-safedollar---deflationary-token-uncompatible
Title: SafeDollar

Root cause:  Incorrect calculation & Deflationary token uncompatible

Same ZABU finance incident

Vulnerable code snippet: 

[https://polygonscan.com/address/0xd4a7d5ca5232976ebf9c28b7231bfdbf4c4eee95#code#L1913](https://polygonscan.com/address/0xd4a7d5ca5232976ebf9c28b7231bfdbf4c4eee95#code#L1913)

[https://polygonscan.com/address/0x17684f4d5385fac79e75ceafc93f22d90066ed5c#code#L730](https://polygonscan.com/address/0x17684f4d5385fac79e75ceafc93f22d90066ed5c#code#L730)

Due to PLX is a deflationary token

1.Deposit PLX tokens to SdoRewardPOOL to deduct PLX token in SdoRewardPOOL contract.

2.Until lp token balance in contract is 2. Then calculate a big reward value in updatePool function.

```solidity
function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
        require(recipient != address(0), "ERC777: transfer to the zero address");

        address from = _msgSender();
        _callTokensToSend(from, from, recipient, amount, "", "");
        _move(from, from, recipient, amount, "", "");
        _callTokensReceived(from, from, recipient, amount, "", "", false);
        return true;
    }
function _move(
        address _operator,
        address from,
        address to,
        uint256 amount,
        bytes memory userData,
        bytes memory operatorData
    ) internal override returns (uint256 _amountSent) {
        _beforeTokenTransfer(_operator, from, to, amount);

        uint256 _amount = amount;

        if (!_isExcludedFromFee[from] && !_isExcludedToFee[to]) {
            {
                uint256 _jackpotRate = jackpotRate;
                if (_jackpotRate > 0) {
                    uint256 _jackpotAmount = amount.mul(_jackpotRate).div(10000);
                    address _jackpotFund = jackpotFund;
                    _balances[from] = _balances[from].sub(_jackpotAmount, "MTokenERC777: transfer amount exceeds balance");
                    _balances[_jackpotFund] = _balances[_jackpotFund].add(_jackpotAmount);
                    _amount = _amount.sub(_jackpotAmount);
                    _totalJackpotAdded = _totalJackpotAdded.add(_jackpotAmount);
                    emit Transfer(from, _jackpotFund, _jackpotAmount);
                }
            }
            {
                uint256 _burnAmount = 0;
                uint256 _burnRate = burnRate;
                if (_burnRate > 0) {
                    _burnAmount = amount.mul(_burnRate).div(10000);
                    _amount = _amount.sub(_burnAmount);
                }
                uint256 _addLiquidityRate = addLiquidityRate;
                if (_addLiquidityRate > 0) {
                    uint256 _addLiquidityAmount = amount.mul(_addLiquidityRate).div(10000);
                    _burnAmount = _burnAmount.add(_addLiquidityAmount);
                    _amount = _amount.sub(_addLiquidityAmount);
                    addLiquidityAccumulated = addLiquidityAccumulated.add(_addLiquidityAmount);
                    uint256 _addLiquidityAccumulated = addLiquidityAccumulated;
                    if (_addLiquidityAccumulated >= minAmountToAddLiquidity) {
                        _mint(liquidityFund, _addLiquidityAccumulated, "", "");
                        _totalLiquidityAdded = _totalLiquidityAdded.add(_addLiquidityAccumulated);
                        ILiquidityFund(liquidityFund).addLiquidity(_addLiquidityAccumulated);
                        emit AddLiquidity(_addLiquidityAccumulated);
                        addLiquidityAccumulated = 0;
                    }
                }
                if (_burnAmount > 0) {
                    **_burn(from, _burnAmount, "", "");** **//vulnerable point,** burn token
                }
            }
        }
```

```solidity
// Update reward variables of the given pool to be up-to-date.
    function updatePool(uint256 _pid) public {
        PoolInfo storage pool = poolInfo[_pid];
        if (now <= pool.lastRewardTime) {
            return;
        }
        uint256 lpSupply = pool.lpToken.balanceOf(address(this));
        if (lpSupply == 0) {
            pool.lastRewardTime = now;
            return;
        }
        if (!pool.isStarted) {
            pool.isStarted = true;
            totalAllocPoint = totalAllocPoint.add(pool.allocPoint);
        }
        if (totalAllocPoint > 0) {
            uint256 _time = now.sub(pool.lastRewardTime);
            uint256 _sdoReward = _time.mul(rewardPerSecond).mul(pool.allocPoint).div(totalAllocPoint);
            **pool.accSdoPerShare** = pool.accSdoPerShare.add(_sdoReward.mul(1e18).div(lpSupply)); // manipulate lpSupply to 2
        }
        pool.lastRewardTime = now;
    }

function _harvestReward(uint256 _pid, address _account) internal {
        UserInfo storage user = userInfo[_pid][_account];
        if (user.amount > 0) {
            PoolInfo storage pool = poolInfo[_pid];
            uint256 _claimableAmount = user.amount.mul(**pool.accSdoPerShare**).div(1e18).sub(user.rewardDebt);//miscalculation
            if (_claimableAmount > 0) {
                IBasisAsset(sdo).mint(_account, _claimableAmount);
                emit RewardPaid(_account, _pid, _claimableAmount);
            }
        }
    }
```