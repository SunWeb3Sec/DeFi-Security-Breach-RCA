# cToken.redeem() is rounded down

Type: Donate, Math, Under/Overflow
Date: 20230415
Lost: $7M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/HundredFinance_2_exp.sol
Title: HundredFinance

**Root cause:**

cToken.redeem() is rounded down - first deposit bug

**Vulnerable code snippet:**

[https://optimistic.etherscan.io/address/0x7100cbca885905f922a19006cf7fd5d0e1bbb26c#code#F8#L123](https://optimistic.etherscan.io/address/0x7100cbca885905f922a19006cf7fd5d0e1bbb26c#code#F8#L123)

```solidity
function redeemFresh(address redeemer, uint redeemTokensIn, uint redeemAmountIn) internal returns (uint) {
	...
	else
		(vars.mathErr, vars.redeemTokens) = divScalarByExpTruncate(redeemAmountIn, Exp(vars.exchangeRateMantissa));  // rounded down from 1.9999 -> 1 (should be rounded up to 2)

	uint256 allowed = comptroller.redeemAllowed(address(this), redeemer, vars.redeemTokens)
}
```

**Attack tx:**

[https://optimistic.etherscan.io/tx/0x6e9ebcdebbabda04fa9f2e3bc21ea8b2e4fb4bf4f4670cb8483e2f0b2604f451](https://optimistic.etherscan.io/tx/0x6e9ebcdebbabda04fa9f2e3bc21ea8b2e4fb4bf4f4670cb8483e2f0b2604f451)

**Analysis:**

[https://twitter.com/peckshield/status/1647307128267476992](https://twitter.com/peckshield/status/1647307128267476992)

[https://twitter.com/danielvf/status/1647329491788677121](https://twitter.com/danielvf/status/1647329491788677121)

[https://twitter.com/hexagate_/status/1647334970258608131](https://twitter.com/hexagate_/status/1647334970258608131)

[https://blog.hundred.finance/15-04-23-hundred-finance-hack-post-mortem-d895b618cf33](https://blog.hundred.finance/15-04-23-hundred-finance-hack-post-mortem-d895b618cf33)