# Insufficient validation

Type: Dex/AMM
Date: 20211130
Lost: $31 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20211130-monox-finance---price-manipulation
Title: MonoX Finance

Root cause:  Insufficient validation

Vulnerable code snippet:

[https://etherscan.io/address/0x66e7d7839333f502df355f5bd87aea24bac2ee63#code#F1#L471](https://etherscan.io/address/0x66e7d7839333f502df355f5bd87aea24bac2ee63#code#F1#L471)

(1)Due to to is controllable, attacker can remove anyone’s liquidity.

```solidity
// actually removes liquidity
  function removeLiquidity (address _token, uint256 liquidity, address to, 
    uint256 minVcashOut, 
    uint256 minTokenOut) external returns(uint256 vcashOut, uint256 tokenOut)  {
    (vcashOut, tokenOut) = _removeLiquidityHelper (_token, liquidity, to, minVcashOut, minTokenOut, false);
  }

// actually removes liquidity
  function _removeLiquidityHelper (address _token, uint256 liquidity, address to, 
    uint256 minVcashOut, 
    uint256 minTokenOut,
    bool isETH) lockToken(_token) internal returns(uint256 vcashOut, uint256 tokenOut)  {
    require (tokenPoolStatus[_token]==1, "MonoX:NO_TOKEN");
    PoolInfo memory pool = pools[_token];
    uint256 poolValue;
    uint256 liquidityIn;
    (poolValue, liquidityIn, vcashOut, tokenOut) = _removeLiquidity(_token, liquidity, to);**//vulnerable point**
    _mintFee(pool.pid, pool.lastPoolValue, poolValue);
    require (vcashOut>=minVcashOut, "MonoX:INSUFF_vCash");
    require (tokenOut>=minTokenOut, "MonoX:INSUFF_TOKEN");

    if (vcashOut>0){
      vCash.mint(to, vcashOut);
    }
    if (!isETH) {
      monoXPool.safeTransferERC20Token(_token, to, tokenOut);
    } else {
      monoXPool.withdrawWETH(tokenOut);
      monoXPool.safeTransferETH(to, tokenOut);
    }

    monoXPool.burn(to, pool.pid, liquidityIn);

    _syncPoolInfo(_token, 0, vcashOut);

    emit RemoveLiquidity(to, 
      pool.pid,
      _token,
      liquidityIn, 
      vcashOut, tokenOut, pool.price);
  }
```

(2)

[https://etherscan.io/address/0x66e7d7839333f502df355f5bd87aea24bac2ee63#code#F1#L824](https://etherscan.io/address/0x66e7d7839333f502df355f5bd87aea24bac2ee63#code#F1#L824)

Attack can input tokenIn and tokenOut with same token because of without any validation. so attacker can perform multiple swap to manipulate the token price.

```solidity
// swap from tokenIn to tokenOut with fixed tokenIn amount.
  function swapIn (address tokenIn, address tokenOut, address from, address to,
      uint256 amountIn) internal lockToken(tokenIn) returns(uint256 amountOut)  {
...
// trading in
    if(tokenIn==address(vCash)){
      vCash.burn(monoXPoolLocal, amountIn);
      // all fees go to the other side
      oneSideFeesInVcash = oneSideFeesInVcash.mul(2);
    }else{
      _updateTokenInfo(tokenIn, tokenInPrice, 0, tradeVcashValue.add(oneSideFeesInVcash), 0);
    }

    // trading out
    if(tokenOut==address(vCash)){
      vCash.mint(to, amountOut);
    }else{
      if (to != monoXPoolLocal) {
        IMonoXPool(monoXPoolLocal).safeTransferERC20Token(tokenOut, to, amountOut);
      }
      _updateTokenInfo(tokenOut, tokenOutPrice, tradeVcashValue.add(oneSideFeesInVcash), 0, 
        to == monoXPoolLocal ? amountOut : 0);
    }
```