# Business Logic Flaw & Access Control

Type: Access Control, Incorrect logic
Date: 20221129
Lost: $5.6k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/MBC_exp.sol
Title: MBC

**Root cause:** 

Business Logic Flaw & Access Control

The root cause of the issue is a flaw in the MBC contract's implementation. The contract incorrectly uses the addLiquidity() function and mistakenly exposes swapAndLiquifyStepv1() function, which uses the balance of the contract's address as the desired reserve amount for maintaining reserves.

So attacker can call swapAndLiquifyStepV1, which will add a certain amount of MBC and BUSD to the pool to manipulate MBC price.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x4e87880a72f6896e7e0a635a5838ffc89b13bd17#code#L1263](https://bscscan.com/address/0x4e87880a72f6896e7e0a635a5838ffc89b13bd17#code#L1263)

```jsx
function swapAndLiquifyStepv1() public {. //vulnerable point
        uint256 ethBalance = ETH.balanceOf(address(this));
        uint256 tokenBalance = balanceOf(address(this));
        addLiquidityUsdt(tokenBalance, ethBalance);
    }

    function addLiquidityUsdt(uint256 tokenAmount, uint256 usdtAmount) private {
        uniswapV2Router.addLiquidity(
            address(_baseToken),
			address(this),
            usdtAmount,
            tokenAmount,
            0,
            0,
            _tokenOwner,
            block.timestamp
        );
    }
```

![2.png](Business%20Logic%20Flaw%20&%20Access%20Control%2018e92ac2bcdd430e8f53a93ec8df198e/2.png)

**Attack tx:**

[https://phalcon.blocksec.com/tx/bsc/0xdc53a6b5bf8e2962cf0e0eada6451f10956f4c0845a3ce134ddb050365f15c86](https://phalcon.blocksec.com/tx/bsc/0xdc53a6b5bf8e2962cf0e0eada6451f10956f4c0845a3ce134ddb050365f15c86)

**Analysis:**

[https://twitter.com/AnciliaInc/status/1597742575623888896](https://twitter.com/AnciliaInc/status/1597742575623888896)
[https://twitter.com/CertiKAlert/status/1597639717096460288](https://twitter.com/CertiKAlert/status/1597639717096460288)