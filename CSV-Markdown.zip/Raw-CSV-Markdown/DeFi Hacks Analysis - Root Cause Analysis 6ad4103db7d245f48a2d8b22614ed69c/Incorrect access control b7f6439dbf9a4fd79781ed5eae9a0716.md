# Incorrect access control

Type: Access Control, ERC20
Date: 20220608
Lost: $2M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220608-gymnetwork---access-control
Title: GYMNetwork
fixed?: fixed

Root cause: Incorrect access control.

Vulnerable code snippet:

[https://bscscan.com/address/0x0288fba0bf19072d30490a0f3c81cd9b0634258a#code#F1#L291](https://bscscan.com/address/0x0288fba0bf19072d30490a0f3c81cd9b0634258a#code#F1#L291)

```solidity
/**
     * @notice Deposit in given pool
     * @param _depositAmount: Amount of want token that user wants to deposit
     */
    function depositFromOtherContract(
        uint256 _depositAmount,
        uint8 _periodId,
        bool isUnlocked,
        address _from
    ) external external {  **//vulnerable point**
        require(isPoolActive,'Contract is not running yet');
        _autoDeposit(_depositAmount,_periodId,isUnlocked,_from);
```

Bug fixed

[https://bscscan.com/address/0xb131c1cc89d209fb5c7250f68d31eff0fb5640d3#code#F1#L299](https://bscscan.com/address/0xb131c1cc89d209fb5c7250f68d31eff0fb5640d3#code#F1#L299)

```solidity
/**
     * @notice Deposit in given pool
     * @param _depositAmount: Amount of want token that user wants to deposit
     */
    function depositFromOtherContract(
        uint256 _depositAmount,
        uint8 _periodId,
        bool isUnlocked,
        address _from
    ) external onlyBank {
        require(isPoolActive,'Contract is not running yet');
        _autoDeposit(_depositAmount,_periodId,isUnlocked,_from);
```