# Insufficient validation

Type: Flashloans, Insufficient validation, MEV
Date: 20221014
Lost: $241 k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221014-mevbota47b---mevbot-a47b
Title: MEVBOTa47b

Root cause: insufficient validation.

MEVBot - Unverified contract: [https://etherscan.io/address/0x00000000000a47b1298f18cf67de547bbe0d723f](https://etherscan.io/address/0x00000000000a47b1298f18cf67de547bbe0d723f)

Check:

[https://twitter.com/BlockSecTeam/status/1580779311862190080](https://twitter.com/BlockSecTeam/status/1580779311862190080)

Attacker can input arbritary data combine in userDate.

![截圖_2022-10-20_上午9_59_29.png](Insufficient%20validation%206f79ccc79b664db3a2b87d7b830d5396/%25E6%2588%25AA%25E5%259C%2596_2022-10-20_%25E4%25B8%258A%25E5%258D%25889_59_29.png)

![截圖_2022-10-20_上午9_58_18.png](Insufficient%20validation%206f79ccc79b664db3a2b87d7b830d5396/%25E6%2588%25AA%25E5%259C%2596_2022-10-20_%25E4%25B8%258A%25E5%258D%25889_58_18.png)