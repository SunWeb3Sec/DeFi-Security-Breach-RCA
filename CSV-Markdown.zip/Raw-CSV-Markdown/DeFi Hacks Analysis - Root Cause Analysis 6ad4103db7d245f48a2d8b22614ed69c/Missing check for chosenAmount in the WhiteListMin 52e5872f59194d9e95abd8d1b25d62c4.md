# Missing check for "chosenAmount" in the WhiteListMint function

Type: Insufficient validation, NFT
Date: 20220902
Lost: 400 NFTs
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220902-bad-guys-by-rpf---business-logic-flaw--missing-check-for-number-of-nft-to-mint
Title: Bad Guys by RPF

Root cause: Insufficient validation

Vulnerable code snippet: 

[https://etherscan.io/address/0xb84cbaf116eb90fd445dd5aeadfab3e807d2cbac?utm_source=icy.tools#code#L1190](https://etherscan.io/address/0xb84cbaf116eb90fd445dd5aeadfab3e807d2cbac?utm_source=icy.tools#code#L1190)

Missing check for "chosenAmount" in the WhiteListMint function which allowed the attacker to pass the number of NFTs he/she wanted to mint.

```solidity
function WhiteListMint(bytes32[] calldata _merkleProof, uint256 chosenAmount)
        public
    {
        require(_numberMinted(msg.sender)<1, "Already Claimed");
        require(isPaused == false, "turn on minting");
        require(
            chosenAmount > 0,
            "Number Of Tokens Can Not Be Less Than Or Equal To 0"
        );
        require(
            totalSupply() + chosenAmount <= maxsupply - reserve,
            "all tokens have been minted"
        );
        bytes32 leaf = keccak256(abi.encodePacked(msg.sender));
        require(
            MerkleProof.verify(_merkleProof, rootHash, leaf),
            "Invalid Proof"
        );
        _safeMint(msg.sender, chosenAmount); **//vulnerable point**
    }
```

---