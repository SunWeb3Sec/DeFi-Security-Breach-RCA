# Incorrect Logic Check, get rewards over skim()

Type: Flashloans, Reward, Stablecoin
Date: 20220810
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220810-xstable-protocol---incorrect-logic-check
Title: XSTABLE Protocol

Root cause: Incorrect Logic Check, get rewards over skim()

Vulnerable code snippet: 

[https://etherscan.io/address/0xb276647e70cb3b81a1ca302cf8de280ff0ce5799#code#F5#L208](https://etherscan.io/address/0xb276647e70cb3b81a1ca302cf8de280ff0ce5799#code#F5#L208)

transfer more XST token to pair, to get more XST token.

```jsx
function _getTxType(address sender, address recipient, bool lpBurn) private returns(uint256) {
        uint256 txType = 2;
        if (isSupportedPool(sender)) {
            if (lpBurn) {
                txType = 3;
            } else {
                **txType = 1;   //**return 
            }
        } else if (sender == Constants.getRouterAdd()) {
            txType = 3;
        }
        return txType;
    }

function _transfer(address sender, address recipient, uint256 amount) private pausable {
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");
        require(amount > 0, "Amount must be greater than zero");
        require(amount <= balanceOf(sender),"Amount exceeds balance");
        require(amount <= unlockedBalanceOf(sender),"Amount exceeds unlocked balance");
        require(isPresaleDone(),"Presale yet to close");
        if (now > getCurrentEpoch().add(Constants.getEpochLength())) updateEpoch();
        uint256 currentFactor = getFactor();
        uint256 largeAmount = amount.mul(currentFactor);
        uint256 txType;
        if (isTaxLess()) {
            txType = 3;
        } else {
            bool lpBurn;
            if (isSupportedPool(sender)) {
                lpBurn = syncPair(sender);
            } else if (isSupportedPool(recipient)){
                silentSyncPair(recipient);
            } else {
                silentSyncPair(_mainPool);
            }
            txType = _getTxType(sender, recipient, lpBurn);
        }
        // Buy Transaction from supported pools - requires mint, no utility fee
        if (txType == 1) {
            _implementBuy(sender, recipient, amount, largeAmount, currentFactor);  **//vulnerable point**
        }
        // Sells to supported pools or unsupported transfer - requires exit burn and utility fee
        else if (txType == 2) {
            _implementSell(sender, recipient, amount, largeAmount, currentFactor);
        } 
        // Add Liquidity via interface or Remove Liquidity Transaction to supported pools - no fee of any sort
        else if (txType == 3) {
            _largeBalances[sender] = _largeBalances[sender].sub(largeAmount);
            _largeBalances[recipient] = _largeBalances[recipient].add(largeAmount);
            emit Transfer(sender, recipient, amount);
        }
    }
```

---