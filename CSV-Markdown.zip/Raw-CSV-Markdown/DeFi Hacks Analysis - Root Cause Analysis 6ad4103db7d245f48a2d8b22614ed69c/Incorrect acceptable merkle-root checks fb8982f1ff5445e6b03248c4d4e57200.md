# Incorrect acceptable merkle-root checks

Type: Bridge, Insufficient validation, uninitialized
Date: 20220802
Lost: $152M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220802-nomad-bridge---business-logic-flaw--incorrect-acceptable-merkle-root-checks
Title: Nomad Bridge
fixed?: fixed

Root cause: business Logic Flaw, Incorrect acceptable merkle-root checks

Nomad team initialized the trusted root to be 0x00.

Vulnerable code snippet: 

[https://etherscan.io/address/0xb92336759618f55bd0f8313bd843604592e27bd8#code](https://etherscan.io/address/0xb92336759618f55bd0f8313bd843604592e27bd8#code)

Replica.sol

```jsx

function initialize(
        uint32 _remoteDomain,
        address _updater,
        bytes32 _committedRoot,
        uint256 _optimisticSeconds
    ) public initializer {
        __NomadBase_initialize(_updater);
        // set storage variables
        entered = 1;
        remoteDomain = _remoteDomain;
        committedRoot = _committedRoot;
        // pre-approve the committed root.
        **confirmAt[_committedRoot] = 1;** 
        _setOptimisticTimeout(_optimisticSeconds);
    }
function process(bytes memory _message) public returns (bool _success) {
        // ensure message was meant for this domain
        bytes29 _m = _message.ref(0);
        require(_m.destination() == localDomain, "!destination");
        // ensure message has been proven
        bytes32 _messageHash = _m.keccak();
				// **messages[_messageHash] 0x00 by default //vulnerable point**
        **require(acceptableRoot(messages[_messageHash]), "!proven");**

```

---