# Incorrect Accounting of deposit time

Type: Flashloans, Miscalculation, staking
Date: 20230222
Lost: $21k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/DYNA_exp.sol
Title: DYNA

**Root cause:** 

StakingDYNA contract does not handle the deposit time correctly.

**Vulnerable code snippet:**

[https://bscscan.com/address/0xa7b5eabc3ee82c585f5f4ccc26b81c3bd62ff3a9#code#F1#L79](https://bscscan.com/address/0xa7b5eabc3ee82c585f5f4ccc26b81c3bd62ff3a9#code#F1#L79)

```solidity
function deposit(uint256 _stakeAmount) external {
	require(enabled, “Staking is not enabled");
	require(
		_stakeanount > 0,
		“StakingDYlA: stake amount must be greater than 0"
	);
	token.transferfrom(msg.sender, address(this), _stakeAmount);
	StakeDetail storage stakeDetail = stakers[msg.sender];
	if (stakeDetail.firstStakeat == 0) {
			stakeDetail.principal = stakeDetail.principal.add(_stakeAmount);
			stakeDetail.firstStakeAt = stakeDetail.firstStakedt == 0
				? block.timestamp
				: stakeDetail.FirstStakeAt;
	StakeDetail.lastProcessat = block.timestamp;
	} else {
		StakeDetail.principal = stakeDetail.principal.add(_stakeAmount); **// Vulnerable Point: Does not update lastProcessAt.**
	}
	emit Deposit(msg.sender, _stakeAmount);
}
```

In the Contract, Users can deposit [**$DYNA**](https://twitter.com/search?q=%24DYNA&src=cashtag_click) to claim rewards, the interest is calculated based on the deposit duration. However, a vulnerability exists in the contract, as it fails to update the "lastProcessAt" parameter for any deposit. Consequently, the staking duration is miscalculated.

**Attack tx:**

[https://bscscan.com/tx/0x06bbe093d9b84783b8ca92abab5eb8590cb2321285660f9b2a529d665d3f18e4](https://bscscan.com/tx/0x06bbe093d9b84783b8ca92abab5eb8590cb2321285660f9b2a529d665d3f18e4)

[https://bscscan.com/tx/0xc09678fec49c643a30fc8e4dec36d0507dae7e9123c270e1f073d335deab6cf0](https://bscscan.com/tx/0xc09678fec49c643a30fc8e4dec36d0507dae7e9123c270e1f073d335deab6cf0)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1628301635834486784](https://twitter.com/BeosinAlert/status/1628301635834486784)

[https://twitter.com/BlockSecTeam/status/1628319536117153794](https://twitter.com/BlockSecTeam/status/1628319536117153794)