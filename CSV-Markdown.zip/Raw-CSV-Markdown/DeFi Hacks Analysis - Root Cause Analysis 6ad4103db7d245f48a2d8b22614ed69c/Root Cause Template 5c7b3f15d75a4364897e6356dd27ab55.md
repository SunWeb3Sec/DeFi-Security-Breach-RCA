# Root Cause Template

Root cause:

Vulnerable code snippet:

Attack tx:

Analysis: