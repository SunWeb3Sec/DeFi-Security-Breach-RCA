# Miscalculation on _spendAllowance

Type: ERC777, Insufficient validation
Date: 20220618
Lost: 104 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220618-snood---miscalculation-on-_spendallowance
Title: SNOOD

Root cause: miscalculation on _spendAllowance

Vulnerable code snippet:

[https://etherscan.io/address/0xeac2a259f3ebb8fd1097aeccaa62e73b6e43d5bf#code#F2#L58](https://etherscan.io/address/0xeac2a259f3ebb8fd1097aeccaa62e73b6e43d5bf#code#F2#L58)

Misuses `_getStandardAmount` and should be `_getReflectedAmount`

```solidity
function _spendAllowance(address owner, address spender, uint256 amount) internal override {
        super._spendAllowance(owner, spender, _getStandardAmount(amount)); **//vulnerable point**
    }
```