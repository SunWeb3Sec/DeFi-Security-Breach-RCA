# Insufficient validation

Type: Insufficient validation, lending
Date: 20220322
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220322-compoundtusdsweeptokenbypass
Title: Compound

Root cause: Insufficient validation.

Vulnerable code snippet:

[https://etherscan.io/address/0xa035b9e130f2b1aedc733eefb1c67ba4c503491f#code#F1#L120](https://etherscan.io/address/0xa035b9e130f2b1aedc733eefb1c67ba4c503491f#code#F1#L120)

if contract can make calls into arbitrary addresses, this can be abused. Attacker use legacy TUSD smart contract to trick compound.

```solidity
function sweepToken(EIP20NonStandardInterface token) override external {
    require(address(token) != underlying, "CErc20::sweepToken: can not sweep underlying token");
    uint256 balance = token.balanceOf(address(this));
    token.transfer(admin, balance);
}
```

Image from [OZ](https://blog.openzeppelin.com/compound-tusd-integration-issue-retrospective/)

![Untitled](Insufficient%20validation%20ac3fc54beece4fcb8d41038759977aa5/Untitled.png)