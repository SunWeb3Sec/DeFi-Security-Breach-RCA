# Not properly validate the input parameters

Type: Unchecked User Input
Date: 20230514
Lost: unclear
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SELLC02_exp.sol
Title: SellToken03

**Root cause:**

StakingRewards contract's Claim() function did not properly validate the input parameters, allowing the attacker to pass a fake token to obtain more rewards.

**Vulnerable code snippet:**

```solidity

function claim(address token,address token1) public    { **//vulnerable point: no token validation**

        require(listToken[token]);

        require(users[token][msg.sender].mnu > 0);

        require(block.timestamp > stakedOfTime[token][msg.sender]);

        uint minit=block.timestamp-stakedOfTime[token][msg.sender];

        uint coin;

        for(uint i=0;i< users[token][msg.sender].mnu;i++){

            if(stakedOfTimeSum[token][msg.sender][i+1] > minit && stakedOf[token][msg.sender][i+1] >0){

            uint banOf=stakedOf[token][msg.sender][i+1] / 100;

            uint send=getTokenPrice(token1,token,banOf) / RATE_DAY;

              coin+=minit*send;

              stakedOfTimeSum[token][msg.sender][i+1]-=minit;

            }

        }

        bool isok=IERC20(token).transfer(msg.sender,coin*50/100);

        require(isok);

        stakedOfTime[token][msg.sender]=block.timestamp;

        updateU(token,msg.sender,coin*50/100);

    }

```

**Attack tx:** 

[https://explorer.phalcon.xyz/tx/bsc/0xfe80df5d689137810df01e83b4bb51409f13c865e37b23059ecc6b3d32347136](https://explorer.phalcon.xyz/tx/bsc/0xfe80df5d689137810df01e83b4bb51409f13c865e37b23059ecc6b3d32347136)

**Analysis:**
[https://twitter.com/BlockSecTeam/status/1657715018908180480](https://twitter.com/BlockSecTeam/status/1657715018908180480)