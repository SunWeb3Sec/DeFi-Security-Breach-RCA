# Price manipulation attack

Type: Price Manipulation
Date: 20221105
Lost: 16WBNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BDEX_exp.sol
Title: BDEX

**Root cause:**

The underlying issue stems from the fact that the `convertDustToEarned` function within the `BvaultsStrategy` contract lacks price checks. This deficiency becomes particularly problematic for trading pairs with low liquidity, as they are more susceptible to experiencing significant price changes due to variations in trading volume.

**Vulnerable code snippet:**

[https://bscscan.com/address/0xB2B1DC3204ee8899d6575F419e72B53E370F6B20#code](https://bscscan.com/address/0xB2B1DC3204ee8899d6575F419e72B53E370F6B20#code)

```solidity
function convertDustToEarned() public whenNotPaused {
        require(isAutoComp, "!isAutoComp");

        // Converts dust tokens into earned tokens, which will be reinvested on the next earn().

        // Converts token0 dust (if any) to earned tokens
        uint256 _token0Amt = IERC20(token0Address).balanceOf(address(this));
        if (token0Address != earnedAddress && _token0Amt > 0) {
            _vswapSwapToken(token0Address, earnedAddress, _token0Amt);
        }

        // Converts token1 dust (if any) to earned tokens
        uint256 _token1Amt = IERC20(token1Address).balanceOf(address(this));
        if (token1Address != earnedAddress && _token1Amt > 0) {
            _vswapSwapToken(token1Address, earnedAddress, _token1Amt);
        }
    }
```

**Attack tx:**

[https://bscscan.com/tx/0xe7b7c974e51d8bca3617f927f86bf907a25991fe654f457991cbf656b190fe94](https://bscscan.com/tx/0xe7b7c974e51d8bca3617f927f86bf907a25991fe654f457991cbf656b190fe94)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1588579143830343683](https://twitter.com/BeosinAlert/status/1588579143830343683)