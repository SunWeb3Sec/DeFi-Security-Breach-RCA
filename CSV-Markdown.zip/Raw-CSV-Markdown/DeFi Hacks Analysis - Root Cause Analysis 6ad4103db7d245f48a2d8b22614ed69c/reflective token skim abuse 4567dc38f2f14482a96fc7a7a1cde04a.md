# reflective token skim abuse

Type: Flashloans, skim
Date: 20230126
Lost: 22 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/TINU_exp.t.sol
Title: TomInu Token

**Root cause:** 

reflective token skim abuse

**Vulnerable code snippet:**

[https://etherscan.io/address/0x2d0e64b6bf13660a4c0de42a0b88144a7c10991f#code#L919](https://etherscan.io/address/0x2d0e64b6bf13660a4c0de42a0b88144a7c10991f#code#L919)

```solidity
function deliver(uint256 tAmount) public {
            address sender = _msgSender();
            require(!_isExcluded[sender], "Excluded addresses cannot call this function");
            (uint256 rAmount,,,,,) = _getValues(tAmount);
            _rOwned[sender] = _rOwned[sender].sub(rAmount);
            _rTotal = _rTotal.sub(rAmount);
            _tFeeTotal = _tFeeTotal.add(tAmount);
        }
```

Tom Inu is a reflective token, aka each time a transfer happens holders will earn fees from it. 

1. The Attacker Flashloan many WETH
2. Swap many WETH -> Tom Inu tokens, giving Uniswapv2 Pair large fees
3. Call skim on the Pair (gets fee). The skim function will balance the supply of pair and send the excess funds to the specified address.
4. Swap Tom Inu to WETH for profit.
    
    ![Untitled](reflective%20token%20skim%20abuse%204567dc38f2f14482a96fc7a7a1cde04a/Untitled.png)
    

**Attack tx:**

[https://etherscan.io/tx/0x6200bf5c43c214caa1177c3676293442059b4f39eb5dbae6cfd4e6ad16305668](https://etherscan.io/tx/0x6200bf5c43c214caa1177c3676293442059b4f39eb5dbae6cfd4e6ad16305668)

**Analysis:**

[https://twitter.com/libevm/status/1618731761894309889](https://twitter.com/libevm/status/1618731761894309889)