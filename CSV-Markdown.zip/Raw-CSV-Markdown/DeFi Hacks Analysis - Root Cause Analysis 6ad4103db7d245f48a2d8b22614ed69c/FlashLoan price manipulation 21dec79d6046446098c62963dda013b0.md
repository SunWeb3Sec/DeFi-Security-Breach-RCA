# FlashLoan price manipulation

Type: Flashloans, Price Manipulation
Date: 20221210
Lost: $57k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/MUMUG_exp.sol
Title: MU&MUG

**Root cause:**

FlashLoan price manipulation.

**Vulnerable code snippet:**

[https://snowtrace.io/address/0x4aa679402c6afce1e0f7eb99ca4f09a30ce228ab#code#F9#L167](https://snowtrace.io/address/0x4aa679402c6afce1e0f7eb99ca4f09a30ce228ab#code#F9#L167)

```jsx
function mu_bond(address stable, uint256 amount) public nonReentrant { **//vulnerable point**
        require(is_approved_stable_coin(stable) ,"Only accepting approved stable coins for bonding");
        IERC20 _stable = IERC20(stable);
        Token token = Token(stable);
        uint8 _decimals = token.decimals();
        uint256 _adjusted_amount;
        if(18 - _decimals == 0)
            _adjusted_amount = amount;
        else {
            _adjusted_amount = (amount/(10**(18-_decimals)));
        }
        require(_stable.balanceOf(msg.sender) >= _adjusted_amount, "You don't have enough of that token to bond that amount");
        (uint256 mu_coin_swap_amount, uint256 mu_coin_amount) = _mu_bond_quote(amount);
        require(IERC20(_MuCoin).balanceOf(address(this)) >= mu_coin_amount, "This contract does not have enough Mu Coin");
        _stable.transferFrom(msg.sender, address(this), _adjusted_amount);
        IERC20(_MuCoin).transfer(msg.sender, mu_coin_amount);
        MuMoneyMinter(_MuMoney).mint(address(this), amount);    
    }

function mu_gold_bond(address stable, uint256 amount) public nonReentrant{ **//vulnerable point**
        require(is_approved_stable_coin(stable) ,"Only accepting approved stable coins for bonding");
        
        IERC20 _stable = IERC20(stable);
        Token token = Token(stable);
        uint8 _decimals = token.decimals();
        uint256 _adjusted_amount;
        if(18 - _decimals == 0)
            _adjusted_amount = amount;
        else {
            _adjusted_amount = (amount/(10**(18-_decimals)));
        }
        require(_stable.balanceOf(msg.sender) >= _adjusted_amount, "You don't have enough of that token to bond that amount");
            (uint256 mu_gold_swap_amount, uint256 mu_gold_bond_amount)  = _get_mug_bond_quote(amount);
            require(IERC20(_MuGold).balanceOf(address(this)) >= mu_gold_bond_amount, "This contract does not have enough Mu Coin");
            _stable.transferFrom(msg.sender, address(this), _adjusted_amount);
            IERC20(_MuGold).transfer(msg.sender, mu_gold_bond_amount);
            MuMoneyMinter(_MuMoney).mint(address(this), amount);

    }
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/avax/0xab39a17cdc200c812ecbb05aead6e6f574712170eafbd73736b053b168555680](https://explorer.phalcon.xyz/tx/avax/0xab39a17cdc200c812ecbb05aead6e6f574712170eafbd73736b053b168555680)

**Analysis:**

[https://docs.mu.money/more-mu-info/mu-hack](https://docs.mu.money/more-mu-info/mu-hack)

[https://www.certik.com/resources/blog/3pdPXDWLvf0wKZ9yy3HeHz-mu-coin-incident-analysis](https://www.certik.com/resources/blog/3pdPXDWLvf0wKZ9yy3HeHz-mu-coin-incident-analysis)