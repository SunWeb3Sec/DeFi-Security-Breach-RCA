# doTransferOut() before updating variables

Type: Reentrancy
Date: 20230411
Lost: $100k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Paribus_exp.sol
Title: Paribus

**Root cause:**

Reentrancy, doTransferOut() before updating variables

**Vulnerable code snippet:**

```jsx
function redeemInternal(uint redeemTokens) internal nonReentrant returns (uint) { **// @audit: useless ReentrancyGuard since it was a cross-contract attack**
  accrueInterest();

  return redeemFresh(msg.sender, redeemTokens, 0);
}

function redeemFresh(address payable redeemer, uint redeemTokensIn, uint redeemAmountIn) internal returns (uint) {  
  ...
	vars.totalSupplyNew = sub_(totalSupply, vars.redeemTokens, 'REDEEM_TOO_MUCH');
	vars.accountTokensNew = sub_(accountTokens[redeemer], vars.redeemTokens, 'REDEEM_TOO_MUCH');

	doTransferOut(redeemer, vars.redeemAmount); **//vulnerable point**

  // @audit: vital variables are updated after interaction (doTransferOut)
	totalSupply = vars.totalSupplyNew;
	accountTokens[redeemer] = vars.accountTokensNew;

	comptroller.redeemVerify();
}
```

**Attack tx:**

[https://arbiscan.io/tx/0x0e29dcf4e9b211a811caf00fc8294024867bffe4ab2819cc1625d2e9d62390af](https://arbiscan.io/tx/0x0e29dcf4e9b211a811caf00fc8294024867bffe4ab2819cc1625d2e9d62390af)

**Analysis:**

[https://twitter.com/Phalcon_xyz/status/1645742620897955842](https://twitter.com/Phalcon_xyz/status/1645742620897955842)

[https://twitter.com/BlockSecTeam/status/1645744655357575170](https://twitter.com/BlockSecTeam/status/1645744655357575170)

[https://twitter.com/peckshield/status/1645742296904929280](https://twitter.com/peckshield/status/1645742296904929280)