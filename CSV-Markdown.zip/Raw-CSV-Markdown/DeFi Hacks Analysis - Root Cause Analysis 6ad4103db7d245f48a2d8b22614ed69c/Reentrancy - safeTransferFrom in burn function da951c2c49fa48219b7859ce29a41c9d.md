# Reentrancy - safeTransferFrom in burn function

Type: ERC721, Flashloans, Reentrancy
Date: 20220710
Lost: $1.4M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220710-omni-nft---reentrancy
Title: Omni NFT

Root cause: safeTransferFrom in burn function. project without nonReentrant protection.

Vulnerable code snippet:

[https://etherscan.io/address/0x50c7a557d408a5f5a7fdbe1091831728ae7eba45#code#F7#L280](https://etherscan.io/address/0x50c7a557d408a5f5a7fdbe1091831728ae7eba45#code#F7#L280)

executeWithdrawERC721 trigger burn function

```solidity
function executeWithdrawERC721(
        mapping(address => DataTypes.ReserveData) storage reservesData,
        mapping(uint256 => address) storage reservesList,
        DataTypes.UserConfigurationMap storage userConfig,
        DataTypes.ExecuteWithdrawERC721Params memory params
    ) external returns (uint256) {
        DataTypes.ReserveData storage reserve = reservesData[params.asset];
        DataTypes.ReserveCache memory reserveCache = reserve.cache();

        reserve.updateState(reserveCache);
        uint256 amountToWithdraw = params.tokenIds.length;

        bool withdrwingAllCollateral = INToken(reserveCache.xTokenAddress).burn(
            msg.sender,
            params.to,
            params.tokenIds,
            reserveCache.nextLiquidityIndex
        );
```

[https://etherscan.io/address/0x4e21f48add00e579b774cdad1656c6625c280381#code#F1#L106#116](https://etherscan.io/address/0x4e21f48add00e579b774cdad1656c6625c280381#code#F1#L106#116)

In burn function trigger safeTransferFrom. As we know this function will call external OnERC721Received. So we can control execution flow to do reentrancy here.

```solidity
/// @inheritdoc INToken
    function burn(
        address from,
        address receiverOfUnderlying,
        uint256[] calldata tokenIds,
        uint256 index
    ) external virtual override onlyPool returns (bool) {
        bool withdrawingAllTokens = _burnMultiple(from, tokenIds);

        if (receiverOfUnderlying != address(this)) {
            for (uint256 index = 0; index < tokenIds.length; index++) {
                IERC721(_underlyingAsset).safeTransferFrom( **//vulnerable point**
                    address(this),
                    receiverOfUnderlying,
                    tokenIds[index]
                );
            }
        }
```