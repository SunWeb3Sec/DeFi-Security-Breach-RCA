# flawed price calculation of a deflation token

Type: Flashloans, Insufficient validation, skim
Date: 20221230
Lost: $1450
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/DFS_exp.sol
Title: DFS

**Root cause:** 

Price Manipulation.

When the receiving address of the dFS token transfer is the pair, a certain percentage of the tokens at this address will be additionally destroyed, and the attacker manipulates the price by invoking the transfer() and skim() function to burn the dfs tokens in the pair.

**Vulnerable code snippet:**

```solidity
function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(amount > 0, "Transfer amount must be greater than zero");
        if (from == address(this) || to == address(this)) {
            return;
        }
        uint256 rate = 5;
        uint256 fee = 0;
        if (to == address(pair) || from == address(pair) ) { 
            if (takeFee && !exclusiveFromFee[from]) {
                fee = amount.mul(rate).div(1000);
                _balance[from] = _balance[from].sub(amount).sub(fee);
                _balance[destroyAddress] = _balance[destroyAddress].add(fee);
                emit Transfer(from, destroyAddress, fee);
            }
        } else {
            _balance[from] = _balance[from].sub(amount);
        }
        if (_balance[from] == 0 && holders.length != 0) {
            holders[holdersIndex[from]] = holders[holders.length-1];
            holdersIndex[holders[holders.length-1]] = holdersIndex[from];
            holders.pop();
            includeHolders[from] = false;
        }
        _balance[to] = _balance[to].add(amount);
        if (!includeHolders[to]) {
            holdersIndex[to] = holders.length;
            holders.push(to);
            includeHolders[to] = true;
        }
        emit Transfer(from, to, amount);
    }

```

**Attack tx:** 

[https://bscscan.com/tx/0xcddcb447d64c2ce4b3ac5ebaa6d42e26d3ed0ff3831c08923c53ea998f598a7c](https://bscscan.com/tx/0xcddcb447d64c2ce4b3ac5ebaa6d42e26d3ed0ff3831c08923c53ea998f598a7c)

**Analysis:**

[https://twitter.com/CertiKAlert/status/1608788290785665024](https://twitter.com/CertiKAlert/status/1608788290785665024)