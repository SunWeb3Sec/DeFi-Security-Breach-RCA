# Price Manipulation of deflationary tokens via flashloan

Type: Deflationary token, Flashloans, Miscalculation
Date: 20230207
Lost: 16 WBNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/FDP_exp.t.sol
Title: FDP Token

**Root cause:** 

Price Manipulation of deflationary tokens via flashloan

**Vulnerable code snippet:**

[https://bscscan.com/address/0x1954b6bd198c29c3ecf2d6f6bc70a4d41ea1cc07#code#L575](https://bscscan.com/address/0x1954b6bd198c29c3ecf2d6f6bc70a4d41ea1cc07#code#L575)

```solidity
function deliver(uint256 tAmount) public {
        address sender = _msgSender();
        require(!_isExcluded[sender], "Excluded addresses cannot call this function");
        (uint256 rAmount,,,,,) = _getValues(tAmount);
        _rOwned[sender] = _rOwned[sender].sub(rAmount);
        _rTotal = _rTotal.sub(rAmount);
        _tFeeTotal = _tFeeTotal.add(tAmount);
    }
```

The attacker uses the tAmount to call deliver function, which is to reduce the user-specified tAmount and add it to the fee. After calling deliver, _getRate becomes smaller when _rTotal is 28% less and _tTotal remains the same.
Since transaction pair is not a deflation excluded address, the balance obtained becomes larger. The attacker can directly withdraw the increased FDP and swap into WBNB

**Attack tx:**

[https://bscscan.com/tx/0x09925028ce5d6a54801d04ff8f39e79af6c24289e84b301ddcdb6adfa51e901b](https://bscscan.com/tx/0x09925028ce5d6a54801d04ff8f39e79af6c24289e84b301ddcdb6adfa51e901b)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1622806011269771266](https://twitter.com/BeosinAlert/status/1622806011269771266)