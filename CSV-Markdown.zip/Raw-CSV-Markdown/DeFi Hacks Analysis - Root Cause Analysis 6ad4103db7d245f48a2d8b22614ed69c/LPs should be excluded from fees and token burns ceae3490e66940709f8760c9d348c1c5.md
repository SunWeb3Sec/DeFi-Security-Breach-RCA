# LPs should be excluded from fees and token burns.

Type: Deflationary token, Flashloans
Date: 20220424
Lost: 78 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220424-wiener-doge---flashloan
Title: Wiener DOGE

Root cause: LPs should be excluded from fees and token burns.

Vulnerable code snippet:

[https://www.bscscan.com/address/0x46ba8a59f4863bd20a066fd985b163235425b5f9#code#L206](https://www.bscscan.com/address/0x46ba8a59f4863bd20a066fd985b163235425b5f9#code#L206)

if an LP sends 100 WDOGE, its balance will decrease by 104 WDOGE, attacker exhaust the deflationary tokens in the LP pair; LPs should be excluded from fees and token burns.

```solidity
function _transfer(address sender, address recipient, uint256 amount) internal virtual returns (bool) {
        require(_balances[sender].amount >= amount, "ERC20: transfer amount exceeds balance");
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");

        if(block.timestamp >=  openingTime && block.timestamp <= closingTime)
        {
            _balances[sender].amount -= amount;
            _balances[recipient].amount += amount;
            emit Transfer(sender, recipient, amount);
        }
        else
        {
            uint256 onePercent = findOnePercent(amount);
            uint256 tokensToBurn = onePercent *4;   // deflationary
            uint256 tokensToRedistribute = onePercent * 4;
            uint256 toFeeWallet = onePercent*1;
            uint256 todev = onePercent* 1;
            uint256 tokensToTransfer = amount - tokensToBurn - tokensToRedistribute - toFeeWallet-todev;

            _balances[sender].amount -= amount;
            _balances[recipient].amount += tokensToTransfer;
            _balances[feeWallet].amount += toFeeWallet;
            _balances[dev].amount  += todev;
            if (!_balances[recipient].exists){
                _balanceOwners.push(recipient);
                _balances[recipient].exists = true;
            }

            redistribute(sender, tokensToRedistribute);
            _burn(sender, tokensToBurn);  // burn
            emit Transfer(sender, recipient, tokensToTransfer);
        }
        return true;
```