# Manipulation of the price oracle.

Type: Oracle, lending
Date: 20230112
Lost: $80k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/RoeFinance_exp.sol
Title: RoeFinance

**Root cause:** 

The root cause is the limited liquidity of the pool, which resulted in the manipulation of the price oracle.

**Vulnerable code snippet:**  

[https://etherscan.io/address/0x574ff39184dee9e46f6c3229b95e0e0938e398d0#code](https://etherscan.io/address/0x574ff39184dee9e46f6c3229b95e0e0938e398d0#code)

```solidity
function borrow(
    address asset,
    uint256 amount,
    uint256 interestRateMode,
    uint16 referralCode,
    address onBehalfOf
  ) external override whenNotPaused {
    DataTypes.ReserveData storage reserve = _reserves[asset];

    _executeBorrow(
      ExecuteBorrowParams(
        asset,
        msg.sender,
        onBehalfOf,
        amount,
        interestRateMode,
        reserve.aTokenAddress,
        referralCode,
        true
      )
    );
  }
function _executeBorrow(ExecuteBorrowParams memory vars) internal {
    DataTypes.ReserveData storage reserve = _reserves[vars.asset];
    DataTypes.UserConfigurationMap storage userConfig = _usersConfig[vars.onBehalfOf];

    address oracle = _addressesProvider.getPriceOracle();

    uint256 amountInETH =
      IPriceOracleGetter(oracle).getAssetPrice(vars.asset).mul(vars.amount).div(
        10**reserve.configuration.getDecimals()
      );

    ValidationLogic.validateBorrow(
      vars.asset,
      reserve,
      vars.onBehalfOf,
      vars.amount,
      amountInETH,
      vars.interestRateMode,
      _maxStableRateBorrowSizePercent,
      _reserves,
      userConfig,
      _reservesList,
      _reservesCount,
      oracle
    );

    reserve.updateState();

    uint256 currentStableRate = 0;

    bool isFirstBorrowing = false;
    if (DataTypes.InterestRateMode(vars.interestRateMode) == DataTypes.InterestRateMode.STABLE) {
      currentStableRate = reserve.currentStableBorrowRate;

      isFirstBorrowing = IStableDebtToken(reserve.stableDebtTokenAddress).mint(
        vars.user,
        vars.onBehalfOf,
        vars.amount,
        currentStableRate
      );
    } else {
      isFirstBorrowing = IVariableDebtToken(reserve.variableDebtTokenAddress).mint(
        vars.user,
        vars.onBehalfOf,
        vars.amount,
        reserve.variableBorrowIndex
      );
    }

    if (isFirstBorrowing) {
      userConfig.setBorrowing(reserve.id, true);
    }

    reserve.updateInterestRates(
      vars.asset,
      vars.aTokenAddress,
      0,
      vars.releaseUnderlying ? vars.amount : 0
    );

    if (vars.releaseUnderlying) {
      IAToken(vars.aTokenAddress).transferUnderlyingTo(vars.user, vars.amount);
    }

    emit Borrow(
      vars.asset,
      vars.user,
      vars.onBehalfOf,
      vars.amount,
      vars.interestRateMode,
      DataTypes.InterestRateMode(vars.interestRateMode) == DataTypes.InterestRateMode.STABLE
        ? currentStableRate
        : reserve.currentVariableBorrowRate,
      vars.referralCode
    );
  }
```

**Attack tx:** 

[https://etherscan.io/tx/0x927b784148b60d5233e57287671cdf67d38e3e69e5b6d0ecacc7c1aeaa98985b](https://etherscan.io/tx/0x927b784148b60d5233e57287671cdf67d38e3e69e5b6d0ecacc7c1aeaa98985b)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1612701106982862849](https://twitter.com/BlockSecTeam/status/1613267000913960976)

[https://quillaudits.medium.com/decoding-roe-finances-flash-loan-exploit-quillaudits-df8494e2090f#:~:text=On the 11th of January,the loss of %2480K](https://quillaudits.medium.com/decoding-roe-finances-flash-loan-exploit-quillaudits-df8494e2090f#:~:text=On%20the%2011th%20of%20January,the%20loss%20of%20%2480K).

[https://blog.solidityscan.com/roe-finance-hack-analysis-price-manipulation-6993fbea0d7c](https://blog.solidityscan.com/roe-finance-hack-analysis-price-manipulation-6993fbea0d7c)