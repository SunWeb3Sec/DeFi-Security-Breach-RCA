# Incorrect access control

Type: Access Control, ERC20
Date: 20221018
Lost: 115 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221018-hpay---access-control
Title: HPAY
fixed?: fixed

Root cause:  Incorrect access control

Vulnerable code snippet:

[https://www.bscscan.com/address/0xe9bc03ef08e991a99f1bd095a8590499931dcc30#code#F1#L174](https://www.bscscan.com/address/0xe9bc03ef08e991a99f1bd095a8590499931dcc30#code#F1#L174)

Due _addre is controllable. Attacker can call setToken() to set fake token created by self.

1.setToken to faketoken

2.Deposit faketoken

3.setToken to HPAY

3.withdraw.  over

```solidity
function setToken(address _addr) public { **//vulnerable point**
        configuration.stakingToken = ERC20(_addr);
        configuration.rewardsToken = ERC20(_addr);
    }
```