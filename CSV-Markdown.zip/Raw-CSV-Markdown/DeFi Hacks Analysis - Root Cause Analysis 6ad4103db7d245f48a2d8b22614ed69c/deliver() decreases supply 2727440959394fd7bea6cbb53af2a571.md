# deliver() decreases supply

Type: Deflationary token
Date: 20230419
Lost: 32 WBNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/OLIFE_exp.sol
Title: OLIFE

**Root cause:**

The attacker called the `transfer()` and `deliver()` functions to reduce the number of rSupply and tSupply.
The value of rate is thus calculated less, increasing the number of reflected tokens in the pair,  Finally directly call swap to withdraw $WBNB from the pair.

**Vulnerable code snippet:**

[https://bscscan.com/address/0xb5a0Ce3Acd6eC557d39aFDcbC93B07a1e1a9e3fa#code](https://bscscan.com/address/0xb5a0Ce3Acd6eC557d39aFDcbC93B07a1e1a9e3fa#code)

```solidity
function deliver(uint256 tAmount) public {
    address sender = _msgSender();
    require(!_isExcluded[sender], "Excluded addresses cannot call this function");
    (uint256 rAmount,,,,,,) = _getValues(tAmount);
    _rOwned[sender] = _rOwned[sender].sub(rAmount);
    _rTotal = _rTotal.sub(rAmount);
    _tFeeTotal = _tFeeTotal.add(tAmount);
}
```

**Attack tx:**

[https://bscscan.com/tx/0xa21692ffb561767a74a4cbd1b78ad48151d710efab723b1efa5f1e0147caab0a](https://bscscan.com/tx/0xa21692ffb561767a74a4cbd1b78ad48151d710efab723b1efa5f1e0147caab0a)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1648520494516420608](https://twitter.com/BeosinAlert/status/1648520494516420608)