# Price Manipulation of deflationary tokens via flashloan

Type: Deflationary token, Miscalculation
Date: 20230210
Lost: $3K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Sheep_exp.sol
Title: Sheep Token

**Root cause:** 

The pool balance can be manipulated due to pair addresses not _isExcluded addresses.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x0025b42bfc22cbba6c02d23d4ec2abfcf6e014d4#code#L523](https://bscscan.com/address/0x0025b42bfc22cbba6c02d23d4ec2abfcf6e014d4#code#L523)

```solidity
function balanceOf(address account) public view override returns (uint256) {
        if (_isExcluded[account]) return _tOwned[account];
        return tokenFromReflection(_rOwned[account]);
    }
```

[https://bscscan.com/address/0x0025b42bfc22cbba6c02d23d4ec2abfcf6e014d4#code#L646](https://bscscan.com/address/0x0025b42bfc22cbba6c02d23d4ec2abfcf6e014d4#code#L646)

```solidity
function _burn(address _who, uint256 _value) internal {
		require(_value <= _rOwned[_who]);
		_rOwned[_who] = _rOwned[_who].sub(_value);
		_tTotal = _tTotal.sub(_value);
		emit Transfer(_who, address(0), _value);
	}
```

The attacker flash loaned some [$WBNB](https://twitter.com/search?q=%24WBNB&src=cashtag_click), bought some Sheep tokens, and burned the tokens in the attack contract by repeatedly calling the burn function.

This results in a decrease in _tTotal and a larger return value for _getrate, which led to a gradual decrease in the pool balance. The remaining tokens were then swapped for a large amount of WBNB at a high price.

![Untitled](Price%20Manipulation%20of%20deflationary%20tokens%20via%20flas%20bea3963adc1c4c53b2b879eb2c355b69/Untitled.png)

**Attack tx:**

[https://bscscan.com/tx/0x61293c6dd5211a98f1a26c9f6821146e12fb5e20c850ad3ed2528195c8d4c98e](https://bscscan.com/tx/0x61293c6dd5211a98f1a26c9f6821146e12fb5e20c850ad3ed2528195c8d4c98e)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1623999717482045440](https://twitter.com/BlockSecTeam/status/1623999717482045440)

[https://twitter.com/BlockSecTeam/status/1624077078852210691](https://twitter.com/BlockSecTeam/status/1624077078852210691)