# Incorrect access control

Type: Access Control, ERC4626
Date: 20220801
Lost: $1.7M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220801-reaper-farm---business-logic-flaw--lack-of-access-control-mechanism
Title: Reaper Farm
fixed?: fixed

Root cause: without proper access control, allowing anyone to withdraw anyone else’s funds.

Vulnerable code snippet: 

ReaperVaultV2.sol

[https://ftmscan.com/address/0xcdA5deA176F2dF95082f4daDb96255Bdb2bc7C7D#code#F1#L323](https://ftmscan.com/address/0xcdA5deA176F2dF95082f4daDb96255Bdb2bc7C7D#code#F1#L323)

```jsx
function _withdraw(uint256 assets, uint256 shares, address receiver, address owner) internal returns (uint256) { **//vulnerable point**
        _burn(owner, shares);
```