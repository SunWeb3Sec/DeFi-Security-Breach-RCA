# Lack of permission control

Type: Lack of permission control
Date: 20230514
Lost: 149,616 $BUSD
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/landNFT_exp.sol
Title: landNFT

**Root cause:**

Lack of permission control on mint.

**Vulnerable code snippet:**

```solidity

function mint(address player,uint256 amount) external whenNotPaused() onlyMiner{
            uint256 _tokenId = totalSupply();
            require(_tokenId.add(amount)<=MAX_SUPPLY,"MAX_SUPPLY err");
            _safeMint(player, amount);
        }
```

**Attack tx:**

[https://bscscan.com/tx/0xe4db1550e3aa78a05e93bfd8fbe21b6eba5cce50dc06688949ab479ebed18048](https://bscscan.com/tx/0xe4db1550e3aa78a05e93bfd8fbe21b6eba5cce50dc06688949ab479ebed18048)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1658002030953365505](https://twitter.com/BeosinAlert/status/1658002030953365505)