# Insufficient validation

Type: Bridge, CrossChain, Incorrect logic
Date: 20210702
Lost: $0.8 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210702-chainswap---bridge-logic-flaw
Title: Chainswap
fixed?: fixed

Root cause:  insufficient validation

Vulnerable code snippet:

[https://bscscan.com/address/0xc5185d2c68aAa7c5f0921948f8135d01510D647F#code#L2386](https://bscscan.com/address/0xc5185d2c68aAa7c5f0921948f8135d01510D647F#code#L2386)

Attacker only needs to generate a random address and generate the corresponding signature to trick ChainSwap.

```solidity
function receive(uint256 fromChainId, address to, uint256 nonce, uint256 volume, Signature[] memory signatures) virtual external payable {
        _chargeFee();
        require(received[fromChainId][to][nonce] == 0, 'withdrawn already');
        uint N = signatures.length;
        require(N >= Factory(factory).getConfig(_minSignatures_), 'too few signatures');
        for(uint i=0; i<N; i++) {
            for(uint j=0; j<i; j++)
                require(signatures[i].signatory != signatures[j].signatory, 'repetitive signatory');
            bytes32 structHash = keccak256(abi.encode(RECEIVE_TYPEHASH, fromChainId, to, nonce, volume, signatures[i].signatory));
            bytes32 digest = keccak256(abi.encodePacked("\x19\x01", _DOMAIN_SEPARATOR, structHash));
            address signatory = ecrecover(digest, signatures[i].v, signatures[i].r, signatures[i].s);
            require(signatory != address(0), "invalid signature");
            require(signatory == signatures[i].signatory, "unauthorized");
            _decreaseAuthQuota(signatures[i].signatory, volume);
            emit Authorize(fromChainId, to, nonce, volume, signatory);
        }
        received[fromChainId][to][nonce] = volume;
        _receive(to, volume);
        emit Receive(fromChainId, to, nonce, volume);
    }

function authQuotaOf(address signatory) virtual public view returns (uint quota) {
        quota = _authQuotas[signatory]; //vulnerable point, no validation
        uint ratio  = autoQuotaRatio  != 0 ? autoQuotaRatio  : Factory(factory).getConfig(_autoQuotaRatio_);
        uint period = autoQuotaPeriod != 0 ? autoQuotaPeriod : Factory(factory).getConfig(_autoQuotaPeriod_);
        if(ratio == 0 || period == 0 || period == uint(-1))
            return quota;
        uint quotaCap = cap().mul(ratio).div(1e18);
        uint delta = quotaCap.mul(now.sub(lasttimeUpdateQuotaOf[signatory])).div(period);
        return Math.max(quota, Math.min(quotaCap, quota.add(delta)));
    }
```