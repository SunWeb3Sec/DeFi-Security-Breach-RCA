# Storage Collision & Malicious Proposal

Type: ERC20, Governance, uninitialized
Date: 20220723
Lost: $6M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220723-audius---storage-collision--malicious-proposal
Title: Audius
fixed?: fixed

Root cause: Storage Collision & Malicious Proposal

Vulnerable code snippet:

AudiusAdminUpgradabilityProxy uses storage slot 0 for the address of the proxyAdmin:

[https://etherscan.io/address/0x4deca517d6817b6510798b7328f2314d3003abac#code](https://etherscan.io/address/0x4deca517d6817b6510798b7328f2314d3003abac#code)

Re-define voting on the Audius protocol and modify the governance contract’s guardian address via initialize().

_votingPeriod to 3 blocks.
_executionDelay to 0 block
_guardianAddress

```solidity
/**
   * @dev Modifier to use in the initializer function of a contract.
   */
  modifier initializer() {
    require(msg.sender == proxyAdmin, "Only proxy admin can initialize");
    require(initializing || isConstructor() || !initialized, "Contract instance has already been initialized");

    bool isTopLevelCall = !initializing;
    if (isTopLevelCall) {
      initializing = true;
      initialized = true;
    }

    _;

    if (isTopLevelCall) {
      initializing = false;
    }
  }
```