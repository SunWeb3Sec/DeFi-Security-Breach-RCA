# donateToReserves()   logical error

Type: Business Logic Flaw, Flashloans
Date: 20230313
Lost: $200M(returned)
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Euler_exp.sol
Title: EulerFinance

**Root cause:**

The primary problem here with Euler was its “donateToReserves” function. which allows the user to transfer tokens from their own balance to a protocol variable called “assetStorage.reserveBalance.”.This function allowed the attacker to [donate](https://medium.com/@omniscia.io/euler-finance-incident-post-mortem-1ce077c28454) their eDAI to Euler reserves, removing assets from their wallet without removing a corresponding amount of debt. Here borrower minted 195 million e-DAI and 200 million d-DAI tokens. A logical error in the `donateToReserve()` method resulted in the burning of e-DAI tokens but not d-DAI tokens, leading to unbacked “d-DAI” token debt that will never be repaid.

**Vulnerable code snippet:**

```solidity
function donateToReserves(uint subAccountId, uint amount) external nonReentrant {
        (address underlying, AssetStorage storage assetStorage, address proxyAddr, address msgSender) = CALLER();
        address account = getSubAccount(msgSender, subAccountId);

        updateAverageLiquidity(account);
        emit RequestDonate(account, amount);

        AssetCache memory assetCache = loadAssetCache(underlying, assetStorage);

        uint origBalance = assetStorage.users[account].balance;
        uint newBalance;

        if (amount == type(uint).max) {
            amount = origBalance;
            newBalance = 0;
        } else {
            require(origBalance >= amount, "e/insufficient-balance");
            unchecked { newBalance = origBalance - amount; }
        }

        assetStorage.users[account].balance = encodeAmount(newBalance);
        assetStorage.reserveBalance = assetCache.reserveBalance = encodeSmallAmount(assetCache.reserveBalance + amount);

        emit Withdraw(assetCache.underlying, account, amount);
        emitViaProxy_Transfer(proxyAddr, account, address(0), amount);

        logAssetStatus(assetCache);
    }
```

**Summary:** 
1) Flash loan tokens from Balancer/Aave v2 => 30M DAI
2) Deploy two contracts: violator and liquidator
3) Deposit 2/3 of funds to Euler using deposit() => sent 20M DAI to Euler and received 19.5M eDAI from Euler
4) Borrow 10x of deposited amount using mint() => received 195.6M eDAI and 200M dDAI from Euler
5) Repay part of debt using the remaining 1/3 of funds using repay() => sent 10M DAI and burned 10M dDAI
6) Repeat 4th step => received 195.6M eDAI and 200M dDAI from Euler
7) Donate 10x of repaid funds using donateToReserves() => sent 100M eDAI to Euler
 8)  Liquidate a violator’s account using liquidate() because eDAI < dDAI => received 310M eDAI and 259M dDAI of debt from the violator
9) Withdraw all token amount from Euler using withdraw() => withdrew 38.9M DAI from Euler
10) Repay flash loans

**Attack tx:**

[https://etherscan.io/tx/0xc310a0affe2169d1f6feec1c63dbc7f7c62a887fa48795d327d4d2da2d6b111d](https://etherscan.io/tx/0xc310a0affe2169d1f6feec1c63dbc7f7c62a887fa48795d327d4d2da2d6b111d)

**Analysis:**

[https://twitter.com/FrankResearcher/status/1635241475989721089](https://twitter.com/FrankResearcher/status/1635241475989721089)

[https://twitter.com/nomorebear/status/1635230621856600064](https://twitter.com/nomorebear/status/1635230621856600064)

[https://twitter.com/peckshield/status/1635229594596036608](https://twitter.com/peckshield/status/1635229594596036608)

[https://twitter.com/BlockSecTeam/status/1635262150624305153](https://twitter.com/BlockSecTeam/status/1635262150624305153)

[https://twitter.com/SlowMist_Team/status/1635288963580825606](https://twitter.com/SlowMist_Team/status/1635288963580825606)

[https://euler-xyz.github.io/euler-contracts-upgrade-diffs/eip14/EToken.html](https://euler-xyz.github.io/euler-contracts-upgrade-diffs/eip14/EToken.html)