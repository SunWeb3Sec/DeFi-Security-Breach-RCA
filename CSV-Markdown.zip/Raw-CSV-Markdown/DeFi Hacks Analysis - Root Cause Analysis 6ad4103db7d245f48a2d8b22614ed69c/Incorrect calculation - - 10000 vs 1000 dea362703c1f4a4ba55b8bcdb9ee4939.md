# Incorrect calculation -  - 10000 vs 1000

Type: Miscalculation, Yield
Date: 20210915
Lost: 1.45 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210915-nimbus-platform
Title: Nimbus Platform

Root cause:  Incorrect calculation

Vulnerable code snippet: same Uranium, NowSwap issue

[https://etherscan.io/address/0xc0A6B8c534FaD86dF8FA1AbB17084A70F86EDDc1#code#L409](https://etherscan.io/address/0xc0A6B8c534FaD86dF8FA1AbB17084A70F86EDDc1#code#L409)

inconsistent value in the code, 10000 vs 1000

```solidity
// this low-level function should be called from a contract which performs important safety checks
    function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external override lock {
        require(amount0Out > 0 || amount1Out > 0, 'Nimbus: INSUFFICIENT_OUTPUT_AMOUNT');
        (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
        require(amount0Out < _reserve0 && amount1Out < _reserve1, 'Nimbus: INSUFFICIENT_LIQUIDITY');

        uint balance0;
        uint balance1;
        { // scope for _token{0,1}, avoids stack too deep errors
        address _token0 = token0;
        address _token1 = token1;
        require(to != _token0 && to != _token1, 'Nimbus: INVALID_TO');
        if (amount0Out > 0) _safeTransfer(_token0, to, amount0Out); // optimistically transfer tokens
        if (amount1Out > 0) _safeTransfer(_token1, to, amount1Out); // optimistically transfer tokens
        if (data.length > 0) INimbusCallee(to).NimbusCall(msg.sender, amount0Out, amount1Out, data);
        balance0 = IERC20(_token0).balanceOf(address(this));
        balance1 = IERC20(_token1).balanceOf(address(this));
        }
        uint amount0In = balance0 > _reserve0 - amount0Out ? balance0 - (_reserve0 - amount0Out) : 0;
        uint amount1In = balance1 > _reserve1 - amount1Out ? balance1 - (_reserve1 - amount1Out) : 0;
        require(amount0In > 0 || amount1In > 0, 'Nimbus: INSUFFICIENT_INPUT_AMOUNT');

        {
        address referralProgram = INimbusFactory(factory).nimbusReferralProgram();
        if (amount0In > 0) {
            address _token0 = token0;
            uint refFee = amount0In.mul(3)/ 1994;
            _safeTransfer(_token0, referralProgram, refFee);
            INimbusReferralProgram(referralProgram).recordFee(_token0, to, refFee);
            balance0 = balance0.sub(refFee);
        } 
        if (amount1In > 0) {
            uint refFee = amount1In.mul(3) / 1994;
            address _token1 = token1;
            _safeTransfer(_token1, referralProgram, refFee);
            INimbusReferralProgram(referralProgram).recordFee(_token1, to, refFee);
            balance1 = balance1.sub(refFee);
        }
        }
        
        { // scope for reserve{0,1}Adjusted, avoids stack too deep errors
        uint balance0Adjusted = balance0.mul(10000).sub(amount0In.mul(15)); **//vulnerable point**
        uint balance1Adjusted = balance1.mul(10000).sub(amount1In.mul(15)); **//vulnerable point**
        require(balance0Adjusted.mul(balance1Adjusted) >= uint(_reserve0).mul(_reserve1).mul(1000**2), 'Nimbus: K'); //vulnerable
        }

        _update(balance0, balance1, _reserve0, _reserve1);
        emit Swap(msg.sender, amount0In, amount1In, amount0Out, amount1Out, to);
    }
```