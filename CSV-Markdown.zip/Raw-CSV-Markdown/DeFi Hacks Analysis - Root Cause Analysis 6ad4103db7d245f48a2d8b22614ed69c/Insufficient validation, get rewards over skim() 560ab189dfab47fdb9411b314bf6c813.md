# Insufficient validation, get rewards over skim()

Type: ERC20, Flashloans, Insufficient validation, Reward
Date: 20220809
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220809-anch---skim-token-balance
Title: ANCH

Root cause: insufficient validation , get rewards over skim()

Vulnerable code snippet: 

[https://www.bscscan.com/address/0xa4f5d4afd6b9226b3004dd276a9f778eb75f2e9e#code#L764](https://www.bscscan.com/address/0xa4f5d4afd6b9226b3004dd276a9f778eb75f2e9e#code#L764)

```jsx
//this method is responsible for taking all fee, if takeFee is true
    function _transfer( **//vulnerable point -** recipient and sender can the same
        address sender,
        address recipient,
        uint256 tAmount
    ) private {
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");
        require(tAmount > 0, "Transfer amount must be greater than zero");
        // Insufficient validation. sender and recipient can be same.
        
		if(sender == uniswapV2Pair) {
            _tokenBuyTransferReward(sender, recipient, tAmount);
        } else if(recipient == uniswapV2Pair) {
            _tokenSellTransferReward(sender, recipient, tAmount);
        } else{

            uint256 currentRate = _getRate();
            uint256 rAmount = tAmount.mul(currentRate);
            _rOwned[sender] = _rOwned[sender].sub(rAmount);
            _rOwned[recipient] = _rOwned[recipient].add(rAmount);
            
            emit Transfer(sender, recipient, tAmount);
        }
```

---

[https://twitter.com/AnciliaInc/status/1557527183966408706](https://twitter.com/AnciliaInc/status/1557527183966408706)

if it supports skim(), the token transfer does not check if recipient and sender are the same, any reward, factor and balance change in _transfer() function, then you are vulnerable for the attack.

The wild attack is on fire.

[$UPS](https://twitter.com/search?q=%24UPS&src=cashtag_click)

[$ANCH](https://twitter.com/search?q=%24ANCH&src=cashtag_click)

[$XST](https://twitter.com/search?q=%24XST&src=cashtag_click)