# Incorrect reward calculation

Type: ERC20, Flashloans, Reward
Date: 20220908
Lost: $125M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220908-newfreedao---flashloans-attack
Title: NewFreeDAO

Root cause: Incorrect reward calculation

Vulnerable code snippet: need to decompile

[https://bscscan.com/address/0x8b068e22e9a4a9bca3c321e0ec428abf32691d1e](https://bscscan.com/address/0x8b068e22e9a4a9bca3c321e0ec428abf32691d1e)

Reward calcuates by the caller's NFD token balance and transfers the reward to caller.

```solidity
function 0x6811e3b9() public nonPayable { 
    require(_isAirAddr.code.size);
    v0, v1 = _isAirAddr.balanceOf(msg.sender).gas(msg.gas);
    require(v0); // checks call status, propagates error data on error
    require(RETURNDATASIZE() >= 32);
    require(v1 > 0, 'Amount can not be Zero');
    if (owner_d[msg.sender] <= 0) {
        owner_d[msg.sender] = stor_6;
    }
    v2 = _SafeDiv(stor_8, block.timestamp - owner_d[msg.sender]);
    require(v2 > 0, 'The collection time was not reached');
    v3 = v4 = 0;
    if (block.timestamp > stor_7) { //vulnerable point
        if (v2 > 0) {
            v5 = 0x3182(stor_b, v1);
            v3 = v6 = _SafeDiv(0xf4240, v5);
        }
    } else if (v2 > 0) { **//vulnerable point**
        v7 = 0x3182(stor_b, v1);
        v8 = 0x3182(v2, v7);
        v3 = v9 = _SafeDiv(0xf4240, v8);
    }
    require(_isAirAddr.code.size);
    v10, v11 = _isAirAddr.transfer(msg.sender, v3).gas(msg.gas);
    require(v10); // checks call status, propagates error data on error
    require(RETURNDATASIZE() >= 32);
    owner_d[msg.sender] = block.timestamp;
}
```