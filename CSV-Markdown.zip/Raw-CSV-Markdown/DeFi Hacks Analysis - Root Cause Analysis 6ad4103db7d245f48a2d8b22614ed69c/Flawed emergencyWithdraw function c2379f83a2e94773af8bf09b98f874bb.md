# Flawed emergencyWithdraw function

Type: Incorrect logic, Miscalculation, lending
Date: 20230217
Lost: $8.5M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Platypus_exp.sol
Title: Platypusdefi

**Root cause:**

The emergencyWithdraw function incorrectly evaluates the insolvency before the collateral removal, resulting in an insolvent debt position after the emergency withdrawal.

**Vulnerable code snippet:**

[https://snowtrace.io/address/0xc007f27b757a782c833c568f5851ae1dfe0e6ec7#code#F1#L578](https://snowtrace.io/address/0xc007f27b757a782c833c568f5851ae1dfe0e6ec7#code#F1#L578)

```solidity
function emergencyWithdraw(uint256 _pid) public nonReentrant {
        PoolInfo storage pool = poolInfo[_pid];
        UserInfo storage user = userInfo[_pid][msg.sender];

        if (address(platypusTreasure) != address(0x00)) {
            (bool isSolvent, ) = platypusTreasure.isSolvent(msg.sender, address(poolInfo[_pid].lpToken), true); **//Vulnerable Point: No Check for Adjustment for borrowed funds**
            require(isSolvent, 'remaining amount exceeds collateral factor');
        }

        // reset rewarder before we update lpSupply and sumOfFactors
        IBoostedMultiRewarder rewarder = pool.rewarder;
        if (address(rewarder) != address(0)) {
            rewarder.onPtpReward(msg.sender, user.amount, 0, user.factor, 0);
        }

        // SafeERC20 is not needed as Asset will revert if transfer fails
        pool.lpToken.transfer(address(msg.sender), user.amount);

        // update non-dialuting factor
        pool.sumOfFactors -= user.factor;

        user.amount = 0;
        user.factor = 0;
        user.rewardDebt = 0;

        emit EmergencyWithdraw(msg.sender, _pid, user.amount);
    }
```

**Attack tx:**

[https://snowtrace.io/tx/0x1266a937c2ccd970e5d7929021eed3ec593a95c68a99b4920c2efa226679b430](https://snowtrace.io/tx/0x1266a937c2ccd970e5d7929021eed3ec593a95c68a99b4920c2efa226679b430)

**Analysis:**

[https://twitter.com/spreekaway/status/1626319585040338953](https://twitter.com/spreekaway/status/1626319585040338953)

[https://twitter.com/peckshield/status/1626367531480125440](https://twitter.com/peckshield/status/1626367531480125440)

[https://twitter.com/danielvf/status/1626340324103663617](https://twitter.com/danielvf/status/1626340324103663617)