# Fetch allowance of msg.sender for account instead of reverse

Type: Incorrect logic
Date: 20230505
Lost: $5.4M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/DEI_exp.sol
Title: DEI

**Root cause:**

Fetch allowance of msg.sender for account instead of reverse.

**Vulnerable code snippet:**

```solidity
function burnFrom(address account, uint256 amount) public virtual {
	uint256 currentAllowance = _allowances[_msgSender()][account];  // @audit: shoud be _allowances[account][_msgSender()]
	_approve(account, _msgSender(), currentAllowance - amount);
	_burn(account, amount);
}
```

**Attack tx:**

[https://arbiscan.io/tx/0xb1141785b7b94eb37c39c37f0272744c6e79ca1517529fec3f4af59d4c3c37ef](https://arbiscan.io/tx/0xb1141785b7b94eb37c39c37f0272744c6e79ca1517529fec3f4af59d4c3c37ef)

**Analysis:**

[https://twitter.com/eugenioclrc/status/1654576296507088906](https://twitter.com/eugenioclrc/status/1654576296507088906)