# Incorrect access control

Type: Access Control, wallet
Date: 20171106
Lost: 514k ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20171106-parity---accidentally-killed-it
Title: Parity

Root cause:  Incorrect access control

Vulnerable code snippet:

[https://etherscan.io/address/0x863df6bfa4469f3ead0be8f9f2aae51c91a907b4#code#L223](https://etherscan.io/address/0x863df6bfa4469f3ead0be8f9f2aae51c91a907b4#code#L223)

```solidity
// constructor - just pass on the owner array to the multiowned and
  // the limit to daylimit
  function initWallet(address[] _owners, uint _required, uint _daylimit) only_uninitialized { **//vulnerable point**
    initDaylimit(_daylimit);
    initMultiowned(_owners, _required);
  }
```