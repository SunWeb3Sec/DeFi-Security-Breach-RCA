# Flawed internal accounting systems

Type: Incorrect logic, Math
Date: 20230203
Lost: $309k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/USDs_exp.sol
Title: Spherax USDs

**Root cause:** 

Flawed internal accounting systems

USDS has three different accounting systems, two separate auto-migration systems, and all share the same variables, just interpret their meaning differently. Thus, all account variables have to be updated together in order to accurately calculate a user's balance.

However, due to improper implementation, these critical updates were not performed accurately, leading to the attack.

**Vulnerable code snippet:**

danielvf:

![Untitled](Flawed%20internal%20accounting%20systems%206ef2b3e88b8f42fdb3c8850047b41990/Untitled.png)

**Attack tx:**

[https://arbiscan.io/tx/0xfaf84cabc3e1b0cf1ff1738dace1b2810f42d98baeea17b146ae032f0bdf82d5](https://arbiscan.io/tx/0xfaf84cabc3e1b0cf1ff1738dace1b2810f42d98baeea17b146ae032f0bdf82d5)

**Analysis:**

[https://medium.com/sperax/usds-feb-3-exploit-report-from-engineering-team-9f0fd3cef00c](https://medium.com/sperax/usds-feb-3-exploit-report-from-engineering-team-9f0fd3cef00c)

[https://twitter.com/danielvf/status/1621965412832350208](https://twitter.com/danielvf/status/1621965412832350208)