# Logic issue with flashloan repayment judgment

Type: Flashloans, Incorrect logic
Date: 20221110
Lost: $4M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/DFX_exp.sol
Title: DFXFinance

**Root cause:**

The victim contract uses contract balance for the repayment judgment. As a result, the attacker uses deposit() to bypass the flashloan repayment. 

**Vulnerable code snippet:**

```solidity
function flash(
        address recipient,
        uint256 amount0,
        uint256 amount1,
        bytes calldata data
    ) external transactable noDelegateCall isNotEmergency {
        uint256 fee = curve.epsilon.mulu(1e18);
        
        require(IERC20(derivatives[0]).balanceOf(address(this)) > 0, 'Curve/token0-zero-liquidity-depth');
        require(IERC20(derivatives[1]).balanceOf(address(this)) > 0, 'Curve/token1-zero-liquidity-depth');
        
        uint256 fee0 = FullMath.mulDivRoundingUp(amount0, fee, 1e18);
        uint256 fee1 = FullMath.mulDivRoundingUp(amount1, fee, 1e18);
        uint256 balance0Before = IERC20(derivatives[0]).balanceOf(address(this));
        uint256 balance1Before = IERC20(derivatives[1]).balanceOf(address(this));

        if (amount0 > 0) IERC20(derivatives[0]).safeTransfer(recipient, amount0);
        if (amount1 > 0) IERC20(derivatives[1]).safeTransfer(recipient, amount1);

        IFlashCallback(msg.sender).flashCallback(fee0, fee1, data);

        uint256 balance0After = IERC20(derivatives[0]).balanceOf(address(this));
        uint256 balance1After = IERC20(derivatives[1]).balanceOf(address(this));

        require(balance0Before.add(fee0) <= balance0After, 'Curve/insufficient-token0-returned');
        require(balance1Before.add(fee1) <= balance1After, 'Curve/insufficient-token1-returned');

        // sub is safe because we know balanceAfter is gt balanceBefore by at least fee
        uint256 paid0 = balance0After - balance0Before;
        uint256 paid1 = balance1After - balance1Before;

        IERC20(derivatives[0]).safeTransfer(owner, paid0);        
        IERC20(derivatives[1]).safeTransfer(owner, paid1);        

        emit Flash(msg.sender, recipient, amount0, amount1, paid0, paid1);
    }
```

**Attack tx:**

[https://etherscan.io/tx/0x6bfd9e286e37061ed279e4f139fbc03c8bd707a2cdd15f7260549052cbba79b7](https://etherscan.io/tx/0x6bfd9e286e37061ed279e4f139fbc03c8bd707a2cdd15f7260549052cbba79b7)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1590960299246780417](https://twitter.com/BlockSecTeam/status/1590960299246780417)
[https://twitter.com/BeosinAlert/status/1591012525914861570](https://twitter.com/BeosinAlert/status/1591012525914861570)
[https://twitter.com/AnciliaInc/status/1590839104731684865](https://twitter.com/AnciliaInc/status/1590839104731684865)
[https://twitter.com/peckshield/status/1590831589004816384](https://twitter.com/peckshield/status/1590831589004816384)