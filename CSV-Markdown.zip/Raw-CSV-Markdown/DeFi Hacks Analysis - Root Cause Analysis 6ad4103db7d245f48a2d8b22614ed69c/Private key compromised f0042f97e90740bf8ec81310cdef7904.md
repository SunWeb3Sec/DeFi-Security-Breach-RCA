# Private key compromised

Type: Bridge, KeyCompromised
Date: 20220627
Lost: $100M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220624-harmonys-horizon-bridge---private-key-compromised
Title: Harmony's Horizon

Root cause: private key compromised

Attacker control ***2*** of 5 wallet can sign the transaction.

![sign.png](Private%20key%20compromised%20f0042f97e90740bf8ec81310cdef7904/sign.png)