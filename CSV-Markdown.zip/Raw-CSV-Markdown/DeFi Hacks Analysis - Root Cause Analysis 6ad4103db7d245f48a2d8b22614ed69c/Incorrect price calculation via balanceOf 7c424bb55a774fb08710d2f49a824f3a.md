# Incorrect price calculation via balanceOf

Type: Flashloans, lending
Date: 20220616
Lost: $1.26M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220616-inversefinance---flashloan--price-oracle-manipulation
Title: InverseFinance

Root cause: Incorrect LP price calculation via balanceOf.

Vulnerable code snippet:

[https://etherscan.io/address/0xe8b3bc58774857732c6c1147bfc9b9e5fb6f427c#code#L120](https://etherscan.io/address/0xe8b3bc58774857732c6c1147bfc9b9e5fb6f427c#code#L120)

Insecure way to calculation of LP price via balanceOf in the pool.

```solidity
function latestAnswer() public view returns (uint256) {
        uint256 crvPoolBtcVal = WBTC.balanceOf(address(CRV3CRYPTO)) * uint256(BTCFeed.latestAnswer()) * 1e2; **//vulnerable point**
        uint256 crvPoolWethVal = WETH.balanceOf(address(CRV3CRYPTO)) * uint256(ETHFeed.latestAnswer()) / 1e8; **//vulnerable point**
        uint256 crvPoolUsdtVal = USDT.balanceOf(address(CRV3CRYPTO)) * uint256(USDTFeed.latestAnswer()) * 1e4; **//vulnerable point**

        uint256 crvLPTokenPrice = (crvPoolBtcVal + crvPoolWethVal + crvPoolUsdtVal) * 1e18 / crv3CryptoLPToken.totalSupply();

        return (crvLPTokenPrice * vault.pricePerShare()) / 1e18;
    }
```