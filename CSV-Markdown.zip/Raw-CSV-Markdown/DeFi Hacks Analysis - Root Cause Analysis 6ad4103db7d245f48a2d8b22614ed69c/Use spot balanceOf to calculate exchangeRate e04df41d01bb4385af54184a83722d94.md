# Use spot balanceOf to calculate exchangeRate

Type: Donate, Oracle
Date: 20230428
Lost: $2M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/0vix_exp.sol
Title: 0vix

**Root cause:**

Incorrect use balanceOf. 

**Vulnerable code snippet:**

vGHSTOracle

```solidity
function totalGHST(address _user) public view returns (uint _totalGHST) {
	uint totalGHSTheld = GHST.balanceOf(_user);   **//vulnerable point**
	_totalGHST = totalGHSTheld + totalGHSTStaked + totalwapGHSTheld;
}

function convertVGHST(uint _share) public view returns (uint _ghst) {
	uint totalTokenLocked = totalGHST(address(this)); **//vulnerable point**
	_ghst = _share * totalTokenLocked / totalShares;
}
```

**Attack tx:**

[https://polygonscan.com/tx/0x10f2c28f5d6cd8d7b56210b4d5e0cece27e45a30808cd3d3443c05d4275bb008](https://polygonscan.com/tx/0x10f2c28f5d6cd8d7b56210b4d5e0cece27e45a30808cd3d3443c05d4275bb008)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1651932529874853888](https://twitter.com/BlockSecTeam/status/1651932529874853888)

[https://twitter.com/peckshield/status/1651923235603361793](https://twitter.com/peckshield/status/1651923235603361793)

[https://twitter.com/Mudit__Gupta/status/1651958883634536448](https://twitter.com/Mudit__Gupta/status/1651958883634536448)