# Incorrect recipient balance check

Type: ERC20, Flashloans, Insufficient validation
Date: 20220725
Lost: $45K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220725-lpc---business-logic-flaw--incorrect-recipient-balance-check-did-not-check-senderrecipient-in-transfer
Title: LPC
fixed?: unfixed

Root cause: Incorrect recipient balance check, did not check sender!=recipient in transfer.

Vulnerable code snippet:

[https://bscscan.com/address/0x1e813fa05739bf145c1f182cb950da7af046778d#code#L1240](https://bscscan.com/address/0x1e813fa05739bf145c1f182cb950da7af046778d#code#L1240)

Increase directly on the recipientAmount to recipient, deduct sender balance incorrectly.

```jsx
function _transfer(
...
totalHolders = totalHolders_;

        _balances[sender] = senderBalance.sub(amount);        
        ***_balances[recipient] = recipientBalance.add(recipientAmount);***
        emit Transfer(sender, recipient, recipientAmount);

        _afterTokenTransfer(sender, recipient, amount);
    }
```

Fixed:

[https://etherscan.io/address/0x1c91aF03A390b4c619B444425b3119e553B5B44b#code#L414](https://etherscan.io/address/0x1c91aF03A390b4c619B444425b3119e553B5B44b#code#L414)

Audius: The key difference in the patched Initialization contract is the two padding fields that disambiguate the proxyAdmin field used in the proxy contract from the initialized and initializing fields used in the implementation contract. This change prevents repetition of the initialization flow of the deployed contract.

```solidity
contract Initializable {
  address private proxyAdmin;
    
  uint256 private filler1;
  uint256 private filler2;
```