# Incorrect reward calculation

Type: ERC20, Flashloans
Date: 20221006
Lost: $290K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221006-RES-Token---pair-manipulate
Title: RES token

Root cause: thisAToB(), burn RES token to increase exchange ratio.

 

Vulnerable code snippet:

[https://www.bscscan.com/address/0xecCD8B08Ac3B587B7175D40Fb9C60a20990F8D21#code#L683](https://www.bscscan.com/address/0xecCD8B08Ac3B587B7175D40Fb9C60a20990F8D21#code#L683)

Attacker did multiple swaps to get rewards ALL token and burn RES token to increase exchange ratio.

```solidity
function _transfer(address sender, address recipient, uint256 amount) internal {
        require(!_blacklist[tx.origin], "blacklist!");
        require(!isContract(recipient) || _whiteContract[recipient] || sender == owner() || recipient == owner(), "no white contract");
        require(sender != address(0), "BEP20: transfer from the zero address");
        require(recipient != address(0), "BEP20: transfer to the zero address");
        require(recipient != address(this), "transfer fail");
        require(_allToken != address(0), "no set allToken");
        if(sender != owner() && recipient != owner() && IPancakePair(_swapV2Pair).totalSupply() == 0) {
            require(recipient != _swapV2Pair,"no start");
        }
        _balances[sender] = _balances[sender].sub(amount, "BEP20: transfer amount exceeds balance");
        
        bool skip = _isSkip(sender, recipient);
        TransferType transferType = _transferType(sender, recipient);
        
        uint256 amountRecipient = amount;
        if (!_lockSwapFee && !skip && transferType != TransferType.TRANSFER){
            if (transferType == TransferType.SWAP_BUY){
                if (_isBuySwap(amount)){
                    amountRecipient = amount.mul(uint256(100).sub(_buyFee)).div(100);
                    _distBuyFee(recipient, amount.mul(_buyFee).div(100)); //Get ALLtoken reward
                }
            }else if(transferType == TransferType.SWAP_SELL){
                if (_isSellSwap(amount)){
                    amountRecipient = amount.mul(uint256(100).sub(_sellFee)).div(100);
                    _distSellFee(sender, amount.mul(_sellFee).div(100));
                }
            }
        }
        
        if (transferType == TransferType.TRANSFER){
            _thisAToB(); **//vulnerable point - burn RES**
        }

function _thisAToB() internal{
        if (_balances[address(this)] > _minAToB){
            uint256 burnNumber = _balances[address(this)];
            _approve(address(this),_pancakeRouterToken, _balances[address(this)]);
            IPancakeRouter(_pancakeRouterToken).swapExactTokensForTokensSupportingFeeOnTransferTokens(
                _balances[address(this)],
                0,
                _pathAToB,
                address(this),
                block.timestamp);
            _burn(_swapV2Pair, burnNumber);  **//vulnerable point**
            IPancakePair(_swapV2Pair).sync();
        }
    }
```