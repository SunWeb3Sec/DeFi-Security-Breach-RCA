# Public addLiquidity()

Type: Access Control
Date: 20230511
Lost: $95k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SELLC_exp.sol
Title: SellToken01

**Root cause:**

Ancilia: In the StakingRewards contract, the listToken[] can be set  in the addLiquidity() function. However, this operation *should*  be restricted to 'OwnerOnly'. By exploiting this vulnerability, a hacker can add their self-created token to listToken and subsequently call the sell function.

**Attack tx:**

[https://bscscan.com/address/0x274b3e185c9c8f4ddef79cb9a8dc0d94f73a7675#code](https://bscscan.com/address/0x274b3e185c9c8f4ddef79cb9a8dc0d94f73a7675#code)

**Vulnerable code snippet:**

```solidity
function addLiquidity(address _token, address token1, uint amount1) public {  // @audit: pass in fake _token 
        uint lp=IERC20(_token).totalSupply()*90/100;
        uint miner=IERC20(_token).totalSupply()*10/100;
        bool isok=IERC20(_token).transferFrom(msg.sender, address(this), IERC20(_token).totalSupply());
        isok=IERC20(token1).transferFrom(msg.sender, address(this), amount1);
        require(isok);
        IERC20(_token).approve(address(address(IRouters)), 2 ** 256 - 1);
        IRouters.addLiquidity(_token,token1,lp,amount1,0, 0,address(this),block.timestamp+100);
        address pair=ISwapFactory(IRouters.factory()).getPair(_token,token1);
        if(pairs(pair).IRouter()==address(0)){
         pairs(pair).setIRouter(0xBDDFA43dbBfb5120738C922fa0212ef1E4a0850B);
        }
        if(myReward[_token]== address(0)){
          myReward[_token]=token1;
        }
        listToken[_token]=true; **//vulnerable point**
        users[_token][0x2F98Fa813Ced7Aa9Fd6788aB624b2F3F292B9239].tz+= 100 ether;
  }
```

**Analysis:**

[https://twitter.com/AnciliaInc/status/1656341587054702598](https://twitter.com/AnciliaInc/status/1656341587054702598)