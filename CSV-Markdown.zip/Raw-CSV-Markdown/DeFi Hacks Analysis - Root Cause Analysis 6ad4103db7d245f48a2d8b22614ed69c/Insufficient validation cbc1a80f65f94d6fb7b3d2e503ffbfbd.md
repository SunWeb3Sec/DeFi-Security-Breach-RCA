# Insufficient validation

Type: Bridge, CrossChain, Insufficient validation
Date: 20210811
Lost: $611 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210811-poly-network---bridge-getting-around-modifier-through-cross-chain-message
Title: Poly Network
fixed?: fixed

Root cause:  Insufficient validation

Vulnerable code snippet:

brute-force a **_method** field that hashes to a 32-bit value that is exactly the ID for putCurEpochConPubKeyBytes!

[https://research.kudelskisecurity.com/2021/08/12/the-poly-network-hack-explained/](https://research.kudelskisecurity.com/2021/08/12/the-poly-network-hack-explained/)