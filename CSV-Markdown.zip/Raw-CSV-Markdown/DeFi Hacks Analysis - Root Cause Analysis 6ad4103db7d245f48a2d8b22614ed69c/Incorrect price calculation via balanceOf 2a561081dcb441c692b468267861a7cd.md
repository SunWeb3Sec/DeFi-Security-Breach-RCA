# Incorrect price calculation via balanceOf

Type: DAO, Flashloans
Date: 20220428
Lost: $13 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220428-deus-dao---flashloan--price-oracle-manipulation
Title: DEUS DAO

Root cause:  Incorrect price calculation via balanceOf.

Vulnerable code snippet:

```solidity
/// @notice returns on chain LP price
    function getOnChainPrice() public view returns (uint256) {
        return
            ((dei.balanceOf(address(pair)) * IBaseV1Pair(address(pair)).getAmountOut(1e18, address(dei)) * 1e12 / 1e18) + (usdc.balanceOf(address(pair)) * 1e12)) * 1e18 / pair.totalSupply();**//vulnerable point**
    }
```