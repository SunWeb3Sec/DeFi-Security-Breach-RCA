# Public mint()

Type: Access Control
Date: 20230506
Lost: $90k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Melo_exp.sol
Title: Melo

**Root cause:**

public mint bug

**Vulnerable code snippet:**

```solidity
function mint(address account, uint256 amount, string memory txId) public returns (bool) { **//vulnerable point**
	  _mint(acccount, amount);  ****
	  return true;
}
```

**Attack tx:**

[https://bscscan.com/tx/0x3f1973fe56de5ecd59a815d3b14741cf48385903b0ccfe248f7f10c2765061f7](https://bscscan.com/tx/0x3f1973fe56de5ecd59a815d3b14741cf48385903b0ccfe248f7f10c2765061f7)

**Analysis:**

[https://twitter.com/peckshield/status/1654667621139349505](https://twitter.com/peckshield/status/1654667621139349505)