# Incorrect access control

Type: Access Control, Metaverse
Date: 20220208
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220208-sandbox-land---access-control
Title: Sandbox LAND

Root cause:  incorrect access control.

Vulnerable code snippet:

[https://etherscan.io/address/0x50f5474724e0ee42d9a4e711ccfb275809fd6d4a#code#F9#L355](https://etherscan.io/address/0x50f5474724e0ee42d9a4e711ccfb275809fd6d4a#code#F9#L355)

```solidity
function _burn(address from, address owner, uint256 id) public { **//vulnerable point**
        require(from == owner, "not owner");
        _owners[id] = 2**160; // cannot mint it again
        _numNFTPerAddress[from]--;
        emit Transfer(from, address(0), id);
    }
```