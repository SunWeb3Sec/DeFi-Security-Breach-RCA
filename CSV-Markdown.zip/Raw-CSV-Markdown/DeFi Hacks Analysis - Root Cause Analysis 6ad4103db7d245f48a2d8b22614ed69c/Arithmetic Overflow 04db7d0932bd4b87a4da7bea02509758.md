# Arithmetic Overflow

Type: Oracle, Under/Overflow, staking
Date: 20220320
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220320-umbrella-network---underflow
Title: Umbrella Network

Root cause: Arithmetic Overflow

Vulnerable code snippet:

[https://etherscan.io/address/0xb3fb1d01b07a706736ca175f827e4f56021b85de#code#F1#L258](https://etherscan.io/address/0xb3fb1d01b07a706736ca175f827e4f56021b85de#code#F1#L258)

```solidity
/// @param amount tokens to withdraw
    /// @param user address
    /// @param recipient address, where to send tokens, if we migrating token address can be zero
    function _withdraw(uint256 amount, address user, address recipient) internal nonReentrant updateReward(user) {
        require(amount != 0, "Cannot withdraw 0");

        // not using safe math, because there is no way to overflow if stake tokens not overflow
        _totalSupply = _totalSupply - amount;
        _balances[user] = _balances[user] - amount;  **//vulnerable point**, overflow
        // not using safe transfer, because we working with trusted tokens
        require(stakingToken.transfer(recipient, amount), "token transfer failed");

        emit Withdrawn(user, amount);
    }
```