# No verification of token authenticity

Type: Flashloans, Insufficient validation
Date: 20220905
Lost: $61,160 USDT
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220905-zoomprofinance---flashloans--price-manipulation
Title: ZoomproFinance
fixed?: unfixed?

Root cause: Insufficient validation

Attacker uss fake usdt in zoom pair to trick protocol.

Vulnerable code snippet: 

unverified contract

[https://bscscan.com/address/0x47391071824569F29381DFEaf2f1b47A4004933B#code](https://bscscan.com/address/0x47391071824569F29381DFEaf2f1b47A4004933B#code)

---

Image from blocksec:

![Untitled](No%20verification%20of%20token%20authenticity%2076b418115aea496fbcddffda0d2351ab/Untitled.png)