# Insufficient validation

Type: Flashloans, Insufficient validation, Yield
Date: 20221014
Lost: 750 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221014-eflevervault---verify-flashloan-callback
Title: EFLeverVault

Root cause: insufficient validation.

Vulnerable code snippet:

[https://etherscan.io/address/0xe39fd820B58f83205Db1D9225f28105971c3D309#code#L310](https://etherscan.io/address/0xe39fd820B58f83205Db1D9225f28105971c3D309#code#L310)

[https://etherscan.io/address/0xe39fd820B58f83205Db1D9225f28105971c3D309#code#L429](https://etherscan.io/address/0xe39fd820B58f83205Db1D9225f28105971c3D309#code#L429)

Attacker can directly call Flashloan with userData “0x307832” which is bytes “0x2” from balancer and set EFLeverVault as recipient to trigger  _withdraw(loan_amount, fee_amount);  to make vault retain enough ETH. Then attacker can call withdraw to drain out the ETH in [L429](https://etherscan.io/address/0xe39fd820B58f83205Db1D9225f28105971c3D309#code#L429).

```solidity
function receiveFlashLoan(
        IERC20[] memory tokens,
        uint256[] memory amounts,
        uint256[] memory feeAmounts,
        bytes memory userData
    ) public payable {
        require(msg.sender == balancer, "only flashloan vault");
//insufficient validation
        uint256 loan_amount = amounts[0];
        uint256 fee_amount = feeAmounts[0];

        if (keccak256(userData) == keccak256("0x1")){
          _deposit(loan_amount, fee_amount);
        }
        if (keccak256(userData) == keccak256("0x2")){
          _withdraw(loan_amount, fee_amount);
        }
    }

  //1. rapay aave with flashloaned amount,    mx
  //2. withdraw steth with current ltv,  x
  //3. change all steths to eths,    x         
  //4. repay flashloan.   pay amx, left x-amx eth
  function _withdraw(uint256 amount, uint256 fee_amount) internal{
    uint256 steth_amount = amount.safeMul(IERC20(asteth).balanceOf(address(this))).safeDiv(getDebt());
    if (IERC20(weth).allowance(address(this), aave) != 0) {IERC20(weth).safeApprove(aave, 0);}
    IERC20(weth).safeApprove(aave, amount);

    IAAVE(aave).repay(weth, amount, 2, address(this));
    IAAVE(aave).withdraw(lido, steth_amount, address(this));

    if (IERC20(lido).allowance(address(this), curve_pool) != 0) {IERC20(lido).safeApprove(curve_pool, 0);}
    IERC20(lido).safeApprove(curve_pool, steth_amount);
    ICurve(curve_pool).exchange(1, 0, steth_amount, 0);

    (bool status, ) = weth.call.value(amount.safeAdd(fee_amount))("");
    require(status, "transfer eth failed");
    IERC20(weth).safeTransfer(balancer, amount.safeAdd(fee_amount));
  }
...
function withdraw(uint256 _amount) public nonReentrant{
    require(IERC20(ef_token).balanceOf(msg.sender) >= _amount, "not enough balance");
    if (is_paused){
      uint256 to_send = address(this).balance.safeMul(_amount).safeDiv(IERC20(ef_token).totalSupply());
      (bool status, ) = msg.sender.call.value(to_send)("");
      require(status, "transfer eth failed");
      TokenInterfaceERC20(ef_token).destroyTokens(msg.sender, _amount);
      return;
    }
_earnReward();

    uint256 loan_amount = getDebt().safeMul(_amount).safeDiv(IERC20(ef_token).totalSupply());
    
    address[] memory tokens = new address[](1);
    uint256[] memory amounts = new uint256[](1);
    bytes memory userData = "0x2";
    tokens[0] = weth;
    amounts[0] = loan_amount;
    //uint256 user_eth_before = msg.sender.balance;
    IBalancer(balancer).flashLoan(address(this), tokens, amounts, userData);
	   // call flashloan first to make vault retain enough ETH.
    uint256 to_send = address(this).balance;  //vulnerable point
    (bool status, ) = msg.sender.call.value(to_send)("");  **//vulnerable point**
    require(status, "transfer eth failed");

    TokenInterfaceERC20(ef_token).destroyTokens(msg.sender, _amount);
    emit CFFWithdraw(msg.sender, to_send, _amount, getVirtualPrice());
  }
```