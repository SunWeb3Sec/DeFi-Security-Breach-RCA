# Misconfiguration in "transfer" function

Type: Flashloans, Misconfiguration, skim
Date: 20230217
Lost: $12k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Starlink_exp.sol
Title: Starlink

**Root cause:** 

Misconfiguration in "transfer" function

**Vulnerable code snippet:**

[https://bscscan.com/address/0x518281f34dbf5b76e6cdd3908a6972e8ec49e345#code#L1135](https://bscscan.com/address/0x518281f34dbf5b76e6cdd3908a6972e8ec49e345#code#L1135)

```solidity
function _transfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal virtual override {
        if (
            botAddresses[sender] &&
            amount > antiBotAmount &&
            antiBotTime > block.timestamp
        ) {
            revert("Anti Bot");
        }

        uint256 contractTokenBalance = balanceOf(address(this)); 

        if(contractTokenBalance >= _maxTxAmount) { 
            contractTokenBalance = _maxTxAmount; 
        }
        
        bool overMinTokenBalance = contractTokenBalance >= numTokensSellToAddToLiquidity;

        bool buyLp = buyIndex >= buyIndexSellLiquify;

        if (
            overMinTokenBalance && 
            !inSwapAndLiquify && 
            sender != uniswapV2Pair && 
            swapAndLiquifyEnabled 
        ) {
            contractTokenBalance = numTokensSellToAddToLiquidity;
            swapAndLiquify(contractTokenBalance);
        }

        if(recipient == uniswapV2Pair){
            if (
                sender != address(this) &&
                recipient != address(this) &&
                !_isExcludedFromFee[sender]
            ) {
                if (
                    overMinTokenBalance && 
                    !inSwapAndLiquify && 
                    sender != uniswapV2Pair && 
                    swapSellLiquifyEnabled 
                ) {
                    contractTokenBalance = numTokensSellToAddToLiquidity;
                    swapAndLiquify(contractTokenBalance);
                }
                uint256 _fee = amount.mul(sellFeeRate).div(100);
                super._transfer(sender,mintContract, _fee.mul(LPSellFees).div(sellFeeRate));
                super._transfer(sender, addressForMarketing, _fee.mul(marketSellFees).div(sellFeeRate));
                super._transfer(sender, BurnAddr, _fee.mul(burnSellFees).div(sellFeeRate));
                amount = amount.sub(_fee);
            }
        }else if(sender == uniswapV2Pair){
            if (
                sender != address(this) &&
                recipient != address(this) &&
                !_isExcludedFromFee[sender]
            ) {
                if (
                    overMinTokenBalance && 
                    !inSwapAndLiquify && 
                    buyLp&&
                    swapBuyLiquifyEnabled 
                ) {
                    contractTokenBalance = numTokensSellToAddToLiquidity;
                    swapAndLiquify(contractTokenBalance);
                    buyIndex =0;

                }
                uint256 _fee = amount.mul(buyFeeRate).div(100);
                super._transfer(sender,mintContract, _fee.mul(LPBuyFees).div(buyFeeRate));
                super._transfer(sender,addressForMarketing, _fee.mul(marketBuyFees).div(buyFeeRate));
                super._transfer(sender, BurnAddr, _fee.mul(burnBuyFees).div(buyFeeRate));
                amount = amount.sub(_fee);
                buyIndex =buyIndex+1;
            }
        }
    
        super._transfer(sender, recipient, amount);
    }
```

StarlinkCoin contract used the "_transfer" function to transfer funds, which incurs a fee when funds come from the LP contract.

The attacker used the "skim" method to directly transfer funds to the LP contract, and the fee was also deducted, causing a change in the proportion of the two tokens in the trading pair contract.

The attacker then exchanged the tokens for a profit and left the contract.

![Untitled](Misconfiguration%20in%20transfer%20function%208748807738e7412981e0d1c76e22a231/Untitled.png)

**Attack tx:**

[https://bscscan.com/tx/0x146586f05a4513136deab3557ad15df8f77ffbcdbd0dd0724bc66dbeab98a962](https://bscscan.com/tx/0x146586f05a4513136deab3557ad15df8f77ffbcdbd0dd0724bc66dbeab98a962)

**Analysis:**

[https://twitter.com/NumenAlert/status/1626447469361102850](https://twitter.com/NumenAlert/status/1626447469361102850)

[https://twitter.com/bbbb/status/1626392605264351235](https://twitter.com/bbbb/status/1626392605264351235)