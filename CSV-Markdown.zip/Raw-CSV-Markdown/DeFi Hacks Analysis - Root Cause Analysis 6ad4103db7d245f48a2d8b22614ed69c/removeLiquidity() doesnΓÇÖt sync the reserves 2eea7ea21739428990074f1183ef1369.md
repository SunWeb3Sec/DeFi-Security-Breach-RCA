# removeLiquidity() doesn’t sync the reserves

Type: Incorrect logic
Date: 20221213
Lost: $845k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/ElasticSwap_exp.sol
Title: ElasticSwap

**Root cause:** 

Business Logic Flaw.

ElasticSwap is an AMM focused on elastic supply tokens. 
An elastic supply (or rebase) token works in a way that the circulating supply expands or contracts due to changes in token price. 
ElasticSwap adapts to the elastic supply changes without the need for someone to call a function on the pool itself after a change (rebase) happens.

**Vulnerable code snippet:**

```solidity
function addLiquidity(uint256 _baseTokenQtyDesired, uint256 _quoteTokenQtyDesired, uint256 _baseTokenQtyMin, uint256 _quoteTokenQtyMin, address _liquidityTokenRecipient){//vulnerable point
	MathLib.TokenQtys memory tokenQtys = MathLib.calculateAddLiquidityQuantities(, , , , IERC20(baseToken).balanceOf(address(this)), totalSupply, internalBalances);
	internalBalances.kLast = internalBalances.baseTokenReserveQty * internalBalances.quoteTokenReserveQty;
}

function removeLiquidity(uint256 _liquidityTokenQty, uint256 _baseTokenQtyMin, uint256 _quoteTokenQtyMin, address _tokenRecipient){//vulnerable point
	uint256 baseTokenReserveQty  = IERC20(baseToken).balanceOf(address(this));
	uint256 quoteTokenReserveQty = IERC20(quoteToken).balanceOf(address(this));
	
	uint256 baseTokenQtyToReturn  = (_liquidityTokenQty * baseTokenReserveQty) / totalSupplyOfLiquidityTokens;
	uint256 quoteTokenQtyToReturn = (_liquidityTokenQty * quoteTokenReserveQty) / totalSupplyOfLiquidityTokens;

	uint256 internalBaseTokenReserveQty = internalBalances.baseTokenReserveQty;
	uint256 baseTokenQtyToRemoveFromInternalAccounting = (_liquidityTokenQty * internalBaseTokenReserveQty) / totalSupplyOfLiquidityTokens;
	
	internalBalances.baseTokenReserveQty = internalBaseTokenReserveQty = internalBaseTokenReserveQty - baseTokenQtyToRemoveFromInternalAccounting;
	
	internalBalances.quoteTokenReserveQty = internalQuoteTokenReserveQty = internalQuoteTokenReserveQty - quoteTokenQtyToReturn;  // @audit: doesn't sync the reserves (as in UniswapPair.burn())
	
  IERC20(baseToken).safeTransfer(_tokenRecipient, baseTokenQtyToReturn);
  IERC20(quoteToken).safeTransfer(_tokenRecipient, quoteTokenQtyToReturn);
}
```

**Attack tx:** 

[https://explorer.phalcon.xyz/tx/eth/0xb36486f032a450782d5d2fac118ea90a6d3b08cac3409d949c59b43bcd6dbb8f](https://explorer.phalcon.xyz/tx/eth/0xb36486f032a450782d5d2fac118ea90a6d3b08cac3409d949c59b43bcd6dbb8f)

**Analysis:**

[https://quillaudits.medium.com/decoding-elastic-swaps-850k-exploit-quillaudits-9ceb7fcd8d1a](https://quillaudits.medium.com/decoding-elastic-swaps-850k-exploit-quillaudits-9ceb7fcd8d1a)