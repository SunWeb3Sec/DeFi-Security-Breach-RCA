# Incorrect access control

Type: Access Control, ERC20, Flashloans
Date: 20220713
Lost: $26,000
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220713-spacegodzilla---flashloans--price-manipulation
Title: SpaceGodzilla

Root cause: incorrect access control.

Vulnerable code snippet:

[https://bscscan.com/address/0x2287c04a15bb11ad1358ba5702c1c95e2d13a5e0#code#L1233](https://bscscan.com/address/0x2287c04a15bb11ad1358ba5702c1c95e2d13a5e0#code#L1233)

```solidity
function swapAndLiquifyStepv1() public {   **//vulnerable point**
        uint256 ethBalance = ETH.balanceOf(address(this));
        uint256 tokenBalance = balanceOf(address(this));
        addLiquidityUsdt(tokenBalance, ethBalance);
    }
```