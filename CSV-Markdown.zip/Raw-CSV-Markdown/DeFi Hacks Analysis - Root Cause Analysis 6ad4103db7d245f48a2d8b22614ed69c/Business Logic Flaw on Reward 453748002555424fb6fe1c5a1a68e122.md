# Business Logic Flaw on Reward

Type: Business Logic Flaw, Flashloans
Date: 20221027
Lost: $50k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/VTF_exp.sol
Title: VTF Token

**Root cause:**

The function `updateUserBalance` does not ascertain the duration for which a user has retained the token. Exploiting this, the attacker pre-deploys numerous malicious contracts, secures the initial $VTF via a flashloan, and subsequently transfers the VTF tokens to each attack contract sequentially. This maneuver enables the attacker to claim the rewards for holding.

**Vulnerable code snippet:**

[https://bscscan.com/address/0xc6548caf18e20f88cc437a52b6d388b0d54d830d#code](https://bscscan.com/address/0xc6548caf18e20f88cc437a52b6d388b0d54d830d#code)

```solidity
function updateUserBalance(address _user) public {
		uint256 totalAmountOver = super.totalSupply();
		if(maxTotal <= totalAmountOver){
			maxCanMint = false;
		}

        if(userBalanceTime[_user] > 0){
			uint256 canMint = getUserCanMint(_user);
			if(canMint > 0){
				userBalanceTime[_user] = block.timestamp;
				_mint(_user, canMint);
			}
		}else{
			userBalanceTime[_user] = block.timestamp;
		}
    }
```

**Attack tx:**

[https://bscscan.com/tx/0xeeaf7e9662a7488ea724223c5156e209b630cdc21c961b85868fe45b64d9b086](https://bscscan.com/tx/0xeeaf7e9662a7488ea724223c5156e209b630cdc21c961b85868fe45b64d9b086)
[https://bscscan.com/tx/0xc2d2d7164a9d3cfce1e1dac7dc328b350c693feb0a492a6989ceca7104eef9b7](https://bscscan.com/tx/0xc2d2d7164a9d3cfce1e1dac7dc328b350c693feb0a492a6989ceca7104eef9b7)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1585575129936977920](https://twitter.com/BlockSecTeam/status/1585575129936977920)

[https://twitter.com/peckshield/status/1585572694241988609](https://twitter.com/peckshield/status/1585572694241988609)

[https://twitter.com/BeosinAlert/status/1585587030981218305](https://twitter.com/BeosinAlert/status/1585587030981218305)