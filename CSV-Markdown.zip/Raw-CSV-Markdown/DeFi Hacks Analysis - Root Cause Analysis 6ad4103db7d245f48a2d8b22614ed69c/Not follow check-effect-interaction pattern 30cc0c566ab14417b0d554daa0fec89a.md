# Not follow check-effect-interaction pattern

Type: Flashloans, Payable, Reentrancy, lending
Date: 20220430
Lost: $80 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220430-rari-capitalfei-protocol---flashloan-attack--reentrancy
Title: Rari Capital

Root cause: Not follow check-effect-interaction pattern.

Vulnerable code snippet:

[https://etherscan.io/address/0xe16db319d9da7ce40b666dd2e365a4b8b3c18217#code#F13#L812](https://etherscan.io/address/0xe16db319d9da7ce40b666dd2e365a4b8b3c18217#code#F13#L812)

Do not follow check-effect-interaction pattern in function borrowFresh.

```solidity
function borrowFresh(address payable borrower, uint borrowAmount) internal returns (uint) {
...
/////////////////////////
        // EFFECTS & INTERACTIONS
        // (No safe failures beyond this point)

        /*
         * We invoke doTransferOut for the borrower and the borrowAmount.
         *  Note: The cToken must handle variations between ERC-20 and ETH underlying.
         *  On success, the cToken borrowAmount less of cash.
         *  doTransferOut reverts if anything goes wrong, since we can't be sure if side effects occurred.
         */
        doTransferOut(borrower, borrowAmount);  **//vulnerable point**

        /* We write the previously calculated values into storage */
        accountBorrows[borrower].principal = vars.accountBorrowsNew;
        accountBorrows[borrower].interestIndex = borrowIndex;
        totalBorrows = vars.totalBorrowsNew;

        /* We emit a Borrow event */
        emit Borrow(borrower, borrowAmount, vars.accountBorrowsNew, vars.totalBorrowsNew);
```

[https://etherscan.io/address/0xe16db319d9da7ce40b666dd2e365a4b8b3c18217#code#F6#L136](https://etherscan.io/address/0xe16db319d9da7ce40b666dd2e365a4b8b3c18217#code#F6#L136)

doTransferOut() function transfers ETH to the receiver via a low-level call, attacker can make a reentrant call in the fallback() function to “exitMarket()**.**

```solidity
function doTransferOut(address payable to, uint amount) internal {
        // Send the Ether and revert on failure
        (bool success, ) = to.call.value(amount)("");
        require(success, "doTransferOut failed");
    }
```