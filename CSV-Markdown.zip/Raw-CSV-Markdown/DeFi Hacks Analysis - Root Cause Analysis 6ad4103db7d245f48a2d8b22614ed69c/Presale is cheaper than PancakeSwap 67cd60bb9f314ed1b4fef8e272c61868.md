# Presale is cheaper than PancakeSwap

Type: Arbitrage
Date: 20230424
Lost: 21 WBNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Axioma_exp.sol
Title: Axioma

**Root cause:**

Presale is cheaper than PancakeSwap

**Vulnerable code snippet:**

[https://bscscan.com/address/0x2C25aEe99ED08A61e7407A5674BC2d1A72B5D8E3#code](https://bscscan.com/address/0x2C25aEe99ED08A61e7407A5674BC2d1A72B5D8E3#code)

```solidity
function buyToken() public payable {
      uint256 bnbAmountToBuy = msg.value;

      uint256 tokenAmount = bnbAmountToBuy.mul(rate).div(10**9);

      require(token.balanceOf(address(this)) >= tokenAmount, "INSUFFICIENT_BALANCE_IN_CONTRACT");

      payable(PresaleOwner).transfer(bnbAmountToBuy);

      uint256 taxAmount = tokenAmount.mul(buyTax).div(100);
      token.transfer(PresaleOwner, taxAmount);

      (bool sent) = token.transfer(msg.sender, tokenAmount.sub(taxAmount));
      require(sent, "FAILED_TO_TRANSFER_TOKENS_TO_BUYER");
}
```

**Attack tx:**

[https://bscscan.com/tx/0x05eabbb665a5b99490510d0b3f93565f394914294ab4d609895e525b43ff16f2](https://bscscan.com/tx/0x05eabbb665a5b99490510d0b3f93565f394914294ab4d609895e525b43ff16f2)

**Analysis:**

[https://twitter.com/HypernativeLabs/status/1650382589847302145](https://twitter.com/HypernativeLabs/status/1650382589847302145)