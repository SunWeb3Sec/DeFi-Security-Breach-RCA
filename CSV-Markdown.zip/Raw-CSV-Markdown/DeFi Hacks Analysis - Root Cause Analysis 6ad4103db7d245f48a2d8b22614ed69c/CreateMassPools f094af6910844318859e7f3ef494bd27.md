# CreateMassPools

Type: Under/Overflow
Date: 20230315
Lost: $390K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/poolz_exp.sol
Title: Poolz

**Root cause:**

The attacker called the vulnerable function ‘CreateMassPools’ and triggered an integer overflow vulnerability in the parameter _StartAmount.

**Vulnerable code snippet:**

```solidity
function CreateMassPools(
        address _Token,
        uint64[] calldata _FinishTime,
        uint256[] calldata _StartAmount,
        address[] calldata _Owner
    ) external isGreaterThanZero(_Owner.length) isBelowLimit(_Owner.length) returns(uint256, uint256) {
        require(_Owner.length == _FinishTime.length, "Date Array Invalid");
        require(_Owner.length == _StartAmount.length, "Amount Array Invalid");
        TransferInToken(_Token, msg.sender, getArraySum(_StartAmount)); **//vulnerable point**
        uint256 firstPoolId = Index;
        for(uint i=0 ; i < _Owner.length; i++){
            CreatePool(_Token, _FinishTime[i], _StartAmount[i], _Owner[i]);
        }
        uint256 lastPoolId = SafeMath.sub(Index, 1);
        return (firstPoolId, lastPoolId);
    }
```

**Attack tx:**

All TX within this contract : [https://bscscan.com/address/0x058bae36467a9fc5e1045dbdffc2fd65b91c2203](https://bscscan.com/address/0x058bae36467a9fc5e1045dbdffc2fd65b91c2203)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1635878098452492288](https://twitter.com/BeosinAlert/status/1635878098452492288)