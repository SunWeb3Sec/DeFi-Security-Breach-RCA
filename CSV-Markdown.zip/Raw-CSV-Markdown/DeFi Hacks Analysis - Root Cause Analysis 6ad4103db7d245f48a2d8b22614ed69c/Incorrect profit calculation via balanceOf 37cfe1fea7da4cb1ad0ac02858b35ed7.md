# Incorrect profit calculation via balanceOf

Type: Miscalculation, Yield
Date: 20210603
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210603-pancakehunny---incorrect-calculation
Title: PancakeHunny
fixed?: fixed

Root cause:  Incorrect profit calculation via balanceOf

Very similar PancakeBunny.

Vulnerable code snippet: 

[https://bscscan.com/address/0x109Ea28dbDea5E6ec126FbC8c33845DFe812a300#code#L4638](https://bscscan.com/address/0x109Ea28dbDea5E6ec126FbC8c33845DFe812a300#code#L4638)

```solidity
function getReward() override public nonReentrant updateReward(msg.sender) {
        uint256 reward = rewards[msg.sender];
        if (reward > 0) {
            rewards[msg.sender] = 0;
            rewardsToken.withdraw(reward);
            uint cakeBalance = IBEP20(CAKE).balanceOf(address(this));

            if (address(minter) != address(0) && minter.isMinter(address(this))) {
                uint performanceFee = minter.performanceFee(cakeBalance);
                minter.mintFor(CAKE, 0, performanceFee, msg.sender, depositedAt[msg.sender]); //check mintFor
                cakeBalance = cakeBalance.sub(performanceFee);
            }

            IBEP20(CAKE).safeTransfer(msg.sender, cakeBalance);
            emit RewardPaid(msg.sender, cakeBalance);
        }
    }
function mintFor(address flip, uint _withdrawalFee, uint _performanceFee, address to, uint) override external onlyMinter {
        uint feeSum = _performanceFee.add(_withdrawalFee);
        IBEP20(flip).safeTransferFrom(msg.sender, address(this), feeSum);

        uint hunnyBNBAmount = tokenToHunnyBNB(flip, IBEP20(flip).balanceOf(address(this))); **//vulnerable point**
        address flipToken = hunnyBNBFlipToken();
....
function tokenToHunnyBNB(address token, uint amount) internal returns(uint flipAmount) {
        if (token == cake) {
            flipAmount = _cakeToHunnyBNBFlip(amount);
        } else {
            // flip
            flipAmount = _flipToHunnyBNBFlip(token, amount);
        }
    }
function _cakeToHunnyBNBFlip(uint amount) private returns(uint flipAmount) {
        swapToken(cake, amount.div(2), _hunny);
        swapToken(cake, amount.sub(amount.div(2)), _wbnb);

        **flipAmount = generateFlipToken();**  
    }
function generateFlipToken() private returns(uint liquidity) {
        uint amountADesired = IBEP20(_hunny).balanceOf(address(this));
        uint amountBDesired = IBEP20(_wbnb).balanceOf(address(this));

        IBEP20(_hunny).safeApprove(address(ROUTER), 0);
        IBEP20(_hunny).safeApprove(address(ROUTER), amountADesired);
        IBEP20(_wbnb).safeApprove(address(ROUTER), 0);
        IBEP20(_wbnb).safeApprove(address(ROUTER), amountBDesired);

        (,,liquidity) = ROUTER.addLiquidity(_hunny, _wbnb, amountADesired, amountBDesired, 0, 0, address(this), block.timestamp);
```