# Front running

Type: ERC20, Flashloans
Date: 20220923
Lost: $94,304
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220923-RADT-DAO---pair-manipulate
Title: RADT-DAO

Root cause: front running

REF: [https://twitter.com/BlockSecTeam/status/1573252869322846209](https://twitter.com/BlockSecTeam/status/1573252869322846209)

1. Borrow USDT via flashloan
2. Partially swap USDT for RADT-DAO token in the Pancake pool
3. Trigger the fallback function of the RADT-DAO contract to transfer the remaining RADT-DAO in the Pancake pool
4. Swap RADT-DAO (from Step 2) for USDT
5. Return the flashloan