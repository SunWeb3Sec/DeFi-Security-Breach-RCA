# Read-only Reentrancy with Curve Oracle

Type: Flashloans, Reentrancy
Date: 20221024
Lost: $220k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/tree/main/past/2022#20221024-market---read-only-reentrancy
Title: Market

**Root cause:**

Market.xyz had been utilizing the Curve LP Oracle for their lending and borrowing markets. However, a price manipulation vulnerability arose because of the presence of Read-Only Reentrancy in the Curve LP Oracle.

**Vulnerable code snippet:**

```solidity
@external
@nonreentrant('lock')
def remove_liquidity(_amount: uint256, min_amounts: uint256[N_COINS],
                     use_eth: bool = False, receiver: address = msg.sender):
    """
    This withdrawal method is very safe, does no complex math
    """
    lp_token: address = self.token
    total_supply: uint256 = CurveToken(lp_token).totalSupply()
    CurveToken(lp_token).burnFrom(msg.sender, _amount)
    balances: uint256[N_COINS] = self.balances
    amount: uint256 = _amount - 1  # Make rounding errors favoring other LPs a tiny bit

    for i in range(N_COINS):
        d_balance: uint256 = balances[i] * amount / total_supply
        assert d_balance >= min_amounts[i]
        self.balances[i] = balances[i] - d_balance
        balances[i] = d_balance  # now it's the amounts going out
        coin: address = self.coins[i]
        if use_eth and coin == WETH20:
            raw_call(receiver, b"", value=d_balance)
        else:
            if coin == WETH20:
                WETH(WETH20).deposit(value=d_balance)
            response: Bytes[32] = raw_call(
                coin,
                _abi_encode(receiver, d_balance, method_id=method_id("transfer(address,uint256)")),
                max_outsize=32,
            )
            if len(response) != 0:
                assert convert(response, bool)

    D: uint256 = self.D
    self.D = D - D * amount / total_supply

    log RemoveLiquidity(msg.sender, balances, total_supply - _amount)
```

**Attack tx:**

[https://polygonscan.com/tx/0xb8efe839da0c89daa763f39f30577dc21937ae351c6f99336a0017e63d387558](https://polygonscan.com/tx/0xb8efe839da0c89daa763f39f30577dc21937ae351c6f99336a0017e63d387558)

[https://polygonscan.com/tx/0x303c770b81d8866693aa341774eaa2cd5dc3a5f1d2ad855b9d6f0c10b5c36d5d](https://polygonscan.com/tx/0x303c770b81d8866693aa341774eaa2cd5dc3a5f1d2ad855b9d6f0c10b5c36d5d)

**Analysis:**

The attack flow as follow:

1. Execute a flashloan of WMATIC and stMATIC tokens.
2. Provide liquidity to the WMATIC/stMATIC Curve pool and receive Curve LP tokens.
3. Utilize a portion of the Curve LP tokens as collateral on [**http://market.xyz**](http://market.xyz/).
4. **Increase** the collateral's value by removing liquidity from the Curve pool.
    1. when removing the liquidity, D value remain unchanged but total supply already updated.
    2. more: [https://chainsecurity.com/curve-lp-oracle-manipulation-post-mortem/](https://chainsecurity.com/curve-lp-oracle-manipulation-post-mortem/)
5. Use the expensive collateral to borrow MAI using a fallback function.
6. Initiate self-liquidation to acquire the collateral at a discounted price.
7. Repay the flashloan.

[https://quillaudits.medium.com/decoding-220k-read-only-reentrancy-exploit-quillaudits-30871d728ad5](https://quillaudits.medium.com/decoding-220k-read-only-reentrancy-exploit-quillaudits-30871d728ad5)