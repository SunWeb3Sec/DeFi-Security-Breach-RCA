# Signature replay

Type: Bridge, Signature
Date: 20220608
Lost: $3M OP
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220608-optimism---wintermute---signature-replay
Title: Wintermute
fixed?: fixed

Root cause: contract does not use eip155 to prevent replay attacks

Vulnerable code snippet:

[https://etherscan.io/address/0x76e2cfc1f5fa8f6a5b3fc4c8f4788f0116861f9b#code#L71](https://etherscan.io/address/0x76e2cfc1f5fa8f6a5b3fc4c8f4788f0116861f9b#code#L71)

To create a contract address on Optimism that is the same as the one on Ethereum, we just need to make sure that the two parameters, sender’s address and the nonce, are the same as the ones used in generating the valid address on Ethereum.

```solidity
/// @dev Allows to create new proxy contact and execute a message call to the new proxy within one transaction.
    /// @param masterCopy Address of master copy.
    /// @param data Payload for message call sent to new proxy contract.
    function createProxy(address masterCopy, bytes memory data)
        public
        returns (Proxy proxy)
    {
        proxy = new Proxy(masterCopy);
        if (data.length > 0)
            // solium-disable-next-line security/no-inline-assembly
            assembly {
                if eq(call(gas, proxy, 0, add(data, 0x20), mload(data), 0, 0), 0) { revert(0, 0) }
            }
        emit ProxyCreation(proxy);
    }
```