# Incorrect price calculation via getReverse

Type: Flashloans, Price Manipulation
Date: 20221201
Lost: $6k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/APC_exp.sol
Title: APC

**Root cause:** 

Incorrect price calculation via getReverse

APC price relies on the reserve balances of the corresponding PancakeSwap pair. You dump APC token price by flashloan.

**Vulnerable code snippet:**

![Untitled](Incorrect%20price%20calculation%20via%20getReverse%20f0e4a20b6e9b42a1ba26c627e105edec/Untitled.png)

![Untitled](Incorrect%20price%20calculation%20via%20getReverse%20f0e4a20b6e9b42a1ba26c627e105edec/Untitled%201.png)

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0xbcaecea2044101c80f186ce5327bec796cd9e054f0c240ddce93e2aead337370](https://explorer.phalcon.xyz/tx/bsc/0xbcaecea2044101c80f186ce5327bec796cd9e054f0c240ddce93e2aead337370)

[https://explorer.phalcon.xyz/tx/bsc/0xf2d4559aeb945fb8e4304da5320ce6a2a96415aa70286715c9fcaf5dbd9d7ed2](https://explorer.phalcon.xyz/tx/bsc/0xf2d4559aeb945fb8e4304da5320ce6a2a96415aa70286715c9fcaf5dbd9d7ed2)

**Analysis:**
[https://twitter.com/BlockSecTeam/status/1598262002010378241](https://twitter.com/BlockSecTeam/status/1598262002010378241)