# DaoModule misconfiguration

Type: Governance, MaliciosProposal
Date: 20221009
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221009-xave-finance---malicious-proposal-mint--transfer-ownership
Title: Xave Finance

Rroot cause: Gnosis Safe DAOModule compromised

DaoModule contract has the default config values set: the `questionCooldown` **and** `minimumBond` were set to 0.

[https://phalcon.blocksec.com/tx/eth/0xc18ec2eb7d41638d9982281e766945d0428aaeda6211b4ccb6626ea7cff31f4a](https://phalcon.blocksec.com/tx/eth/0xc18ec2eb7d41638d9982281e766945d0428aaeda6211b4ccb6626ea7cff31f4a)

Attacker call DaoModule.executeProposalWithIndex to mint() and transferOwnership()

```jsx
"function": "mint(address,uint256)",
      "params": [
        "0x0f44f3489D17e42ab13A6beb76E57813081fc1E2",
        "100000000000000000000000000000000"
      ]

{
      "function": "transferOwnership(address)",
      "params": [
        "0x0f44f3489D17e42ab13A6beb76E57813081fc1E2"
      ]
    }
```

![22.png](DaoModule%20misconfiguration%20b29d8fdd64034b1898fbdff9b7494ae3/22.png)