# Flashloan attack - reward mechanism

Type: Flashloans
Date: 20221107
Lost: $140k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/MooCAKECTX_exp.sol
Title: MooCAKECTX

**Root cause:**

The reward calculation on the victim contract is not time-related, and the attacker bypasses the `isContract` validation by performing an attack in the constructor. 

**Vulnerable code snippet:**

[https://bscscan.com/address/0x489afbaed0ea796712c9a6d366c16ca3876d8184#code](https://bscscan.com/address/0x489afbaed0ea796712c9a6d366c16ca3876d8184#code)

[https://bscscan.com/address/0xc2562dd7e4caee53df0f9cd7d4dddaa53bcd3d9b#code](https://bscscan.com/address/0xc2562dd7e4caee53df0f9cd7d4dddaa53bcd3d9b#code)

```solidity
/**
     * @dev Core function of the strat, in charge of collecting and re-investing rewards.
     * 1. It claims rewards from the MasterChef & SmartChef
     * 2. It swaps the {output} token for {cake}
     * 3. It charges the system fee and sends it to BIFI stakers.
     * 4. It re-invests the remaining profits.
     */
    function harvest() public {
        require(!Address.isContract(msg.sender), "!contract");
        IMasterChef(masterchef).leaveStaking(0);
        ISmartChef(smartchef).deposit(0);
        doswap();
        dosplit();
        deposit();
    }
```

**Attack tx:**

[https://bscscan.com/tx/0x03d363462519029cf9a544d44046cad0c7e64c5fb1f2adf5dd5438a9a0d2ec8e](https://bscscan.com/tx/0x03d363462519029cf9a544d44046cad0c7e64c5fb1f2adf5dd5438a9a0d2ec8e)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1589501207181393920](https://twitter.com/BeosinAlert/status/1589501207181393920)
[https://twitter.com/CertiKAlert/status/1589428153591615488](https://twitter.com/CertiKAlert/status/1589428153591615488)