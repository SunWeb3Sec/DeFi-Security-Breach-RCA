# Incorrect get price oracle replies on the balance

Type: Flashloans, Price Manipulation
Date: 20230308
Lost: $80K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/DKP_exp.sol
Title: DKP

**Root cause:**

QuillAudits: The contract was not verified. So, after decompiling it, we found that the vulnerability was present in the exchange() function, which was used to swap USDT for DKP tokens. The problem arises because the price Oracle relies on the balance ratio of the two tokens in the USDT-DKP pair, making it vulnerable to flash loan attacks that allow the attacker to manipulate the pool.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x89257A52Ad585Aacb1137fCc8abbD03a963B9683#code](https://bscscan.com/address/0x89257A52Ad585Aacb1137fCc8abbD03a963B9683#code)

[https://library.dedaub.com/decompile?md5=0795fc50f96b806a37007ea095b360de](https://library.dedaub.com/decompile?md5=0795fc50f96b806a37007ea095b360de)

![Untitled](Incorrect%20get%20price%20oracle%20replies%20on%20the%20balance%209e97375034ca4cdfbfe6c23b236ed09f/Untitled.png)

```jsx
function 0x1201() private { 
    require(stor_3_0_19.code.size);
    v0, v1 = stor_3_0_19.balanceOf(_lp).gas(msg.gas);
    require(v0); // checks call status, propagates error data on error
    MEM[64] = MEM[64] + (RETURNDATASIZE() + 31 & ~0x1f);
    require(MEM[64] + RETURNDATASIZE() - MEM[64] >= 32);
    0x2a44(v1);
    require(_usdt.code.size);
    v2, v3 = _usdt.balanceOf(_lp).gas(msg.gas);
    require(v2); // checks call status, propagates error data on error
    MEM[64] = MEM[64] + (RETURNDATASIZE() + 31 & ~0x1f);
    require(MEM[64] + RETURNDATASIZE() - MEM[64] >= 32);
    0x2a44(v3);
    v4 = 0x1af2(0xde0b6b3a7640000, v1);
    v5 = 0x1b6d(v3, v4);
    return v5;
}
```

**Attack tx:**

[https://bscscan.com/tx/0x0c850f54c1b497c077109b3d2ef13c042bb70f7f697201bcf2a4d0cb95e74271](https://bscscan.com/tx/0x0c850f54c1b497c077109b3d2ef13c042bb70f7f697201bcf2a4d0cb95e74271)

[https://bscscan.com/tx/0x2d31e45dce58572a99c51357164dc5283ff0c02d609250df1e6f4248bd62ee01](https://bscscan.com/tx/0x2d31e45dce58572a99c51357164dc5283ff0c02d609250df1e6f4248bd62ee01)

**Analysis:**

[https://twitter.com/CertiKAlert/status/1633421908996763648](https://twitter.com/CertiKAlert/status/1633421908996763648)

[https://blog.solidityscan.com/dkp-hack-analysis-improper-token-pair-ratio-calculation-282672cd0450](https://blog.solidityscan.com/dkp-hack-analysis-improper-token-pair-ratio-calculation-282672cd0450)

[https://medium.com/coinmonks/decoding-dkp-token-s-80k-exploit-quillaudits-45c67df973d6](https://medium.com/coinmonks/decoding-dkp-token-s-80k-exploit-quillaudits-45c67df973d6)