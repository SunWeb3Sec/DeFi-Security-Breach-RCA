# Incorrect reward calculation

Type: ERC20, Miscalculation
Date: 20220910
Lost: $1.4 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220910-dpc---Incorrect-Reward-calculation
Title: DPC

Root cause: Incorrect Reward calculation

Vulnerable code snippet:

[https://bscscan.com/address/0xB75cA3C3e99747d0e2F6e75A9fBD17F5Ac03cebE#code#L1232](https://bscscan.com/address/0xB75cA3C3e99747d0e2F6e75A9fBD17F5Ac03cebE#code#L1232)

To increase the reward by calling the claimStakeLp function in the contract. The reward calculated in the function claimStakeLp() is the accumulation of the previous reward and the reward calculated by getClaimQuota().

```solidity
function claimStakeLp(address _from ,uint256 Amountwei) public {
                require(Amountwei > 0,"Quantity error");
                require(_from==msg.sender,"error");
                require(dpcLp[_from] >= Amountwei ,"Insufficient authorization limit");
                IERC20(LpContract).transfer(_from,Amountwei);

                oldClaimQuota[_from] = oldClaimQuota[_from].add(getClaimQuota(_from)); **//vulnerable point**

                dpcLp[_from] = dpcLp[_from].sub(Amountwei);

                time=currTimeStamp();
                dpcLpTime[_from] = time;

                dpcLpTotal = dpcLpTotal.sub(Amountwei);
        
         }

function getClaimQuota(address addr) public view returns (uint256) {
                uint256 ClaimQuota;
               if(dpcAirdrop[addr] > 0 && dpcLp[addr]>0){
                    uint256 QuotastartTime;
                    uint256 limit = 50 * 10**18;
                    uint256 LpQuotaNum = dpcLp[addr].mul(getLpPrice()).mul(lpQuota).div(100);
                    uint256 secondQuota;
                    if(getDpcPrice()>0){
                        secondQuota = LpQuotaNum.div(24*60*60).div(getDpcPrice());
                    }

                    uint256 limitSecondQuota = limit.div(24*60*60);
                    if(secondQuota > limitSecondQuota){
                        secondQuota = limitSecondQuota;
                    }
                    uint256 nowTime = currTimeStamp();

                    if(dpcLpTime[addr]>ClaimQuotaTime[addr]){
                        QuotastartTime = dpcLpTime[addr];
                    }else{
                        QuotastartTime = ClaimQuotaTime[addr];
                    }
                    ClaimQuota = (nowTime.sub(QuotastartTime)).mul(secondQuota);
                    if(ClaimQuota > dpcAirdrop[addr]){
                        ClaimQuota = dpcAirdrop[addr];
                    }
               }else{
                    ClaimQuota = 0;
               }
               ClaimQuota = ClaimQuota.add(oldClaimQuota[addr]); **//vulnerable point**

               return ClaimQuota;
        
         }
```