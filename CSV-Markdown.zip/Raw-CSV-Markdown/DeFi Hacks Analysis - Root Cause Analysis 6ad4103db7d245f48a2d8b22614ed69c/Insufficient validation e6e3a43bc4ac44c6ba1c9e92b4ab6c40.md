# Insufficient validation

Type: DAO, Insufficient validation
Date: 20221021
Lost: $292 K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/README.md#20221021-bond-protocol---no-input-validation
Title: OlympusDAO

Root cause:  insufficient validation

Vulnerable code snippet:

[https://etherscan.io/address/0x007FE7c498A2Cf30971ad8f2cbC36bd14Ac51156#code#F1#L137](https://etherscan.io/address/0x007FE7c498A2Cf30971ad8f2cbC36bd14Ac51156#code#F1#L137)

Due to token_ is controllable and does not validate properly on BondFixedExpiryTeller, attacker can create a custom contract to drain out the fund on BondFixedExpiryTeller. 

```solidity
/// @inheritdoc IBondFixedExpiryTeller
    function redeem(ERC20BondToken token_, uint256 amount_) external override nonReentrant {**//vulnerable point,** insufficient validation
        if (uint48(block.timestamp) < token_.expiry())
            revert Teller_TokenNotMatured(token_.expiry());
        token_.burn(msg.sender, amount_);
        token_.underlying().transfer(msg.sender, amount_); **//vulnerable point, custom contract return OHM.**
    }
```

updated: funds are returned to OlympusDAO.

---

OlympusDAO confirmed the exploit on its Discord channel today. There, it stated that the attacker “was able to withdraw roughly 30K OHM ($300K)” but that most of the project’s other funds remained safe.