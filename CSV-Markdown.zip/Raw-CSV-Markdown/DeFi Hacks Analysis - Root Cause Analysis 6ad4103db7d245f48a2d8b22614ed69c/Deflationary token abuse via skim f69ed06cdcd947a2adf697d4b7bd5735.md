# Deflationary token abuse via skim

Type: Deflationary token, Flashloans, Incorrect logic
Date: 20221207
Lost: $60k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/AES_exp.sol
Title: AES

**Root cause:** 

Manipulate the price via the skim of the BNB-AES pool because AES is a deflationary token.

The attacker sends the AES to the BNB-AES pool and invokes the skim function repeatedly. In this process, the pool's balance is burned, and the swap fee in the AES contract is increased. After that, the attacker invokes the 'distributeFee' function in the AES contract to transfer the swap fee out of the pair directly, thereby increasing the price of the AES token.

**Vulnerable code snippet:**

[https://bscscan.com/address/0xddc0cff76bcc0ee14c3e73af630c029fe020f907#code#L1325](https://bscscan.com/address/0xddc0cff76bcc0ee14c3e73af630c029fe020f907#code#L1325)

```jsx
function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal override {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");

        if(from == address(this) && to == uniswapV2Pair){
            super._transfer(from, to, amount);
        } else {
            if(automatedMarketMakerPairs[from]) {
                buyTokenAndFees(from, to, amount);
            }else if (automatedMarketMakerPairs[to]){
                sellTokenAndFees(from, to, amount);  //vulnerable point
            }else {
                super._transfer(from, to, amount);
            }
        }

    }

function sellTokenAndFees(
        address from, 
        address to, 
        uint256 amount
    ) internal {
        uint256 burnAmount = amount.mul(3).div(100); 
        uint256 otherAmount = amount.mul(1).div(100); 

        amount = amount.sub(burnAmount);
        swapFeeTotal = swapFeeTotal.add(otherAmount);
        super._burn(from, burnAmount);
        super._transfer(from, to, amount);
    }
function distributeFee() public {
        uint256 mokeyFeeTotal = swapFeeTotal.mul(2);
        super._transfer(uniswapV2Pair, monkeyWallet, mokeyFeeTotal);
        super._transfer(uniswapV2Pair, birdWallet, swapFeeTotal);
        super._transfer(uniswapV2Pair, foundationWallet, swapFeeTotal);
        super._transfer(uniswapV2Pair, technologyWallet, swapFeeTotal);
        super._transfer(uniswapV2Pair, marketingWallet, swapFeeTotal);
        swapFeeTotal = 0;
    }
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0xca4d0d24aa448329b7d4eb81be653224a59e7b081fc7a1c9aad59c5a38d0ae19](https://explorer.phalcon.xyz/tx/bsc/0xca4d0d24aa448329b7d4eb81be653224a59e7b081fc7a1c9aad59c5a38d0ae19)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1600442137811689473](https://twitter.com/BlockSecTeam/status/1600442137811689473)

[https://twitter.com/peckshield/status/1600418002163625984](https://twitter.com/peckshield/status/1600418002163625984)