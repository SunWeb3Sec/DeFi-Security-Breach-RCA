# Business Logic Flaw

Type: Business Logic Flaw, Flashloans
Date: 20221121
Lost: $13k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SDAO_exp.sol
Title: SDAO

**Root cause:**

`sDAO` contract have the following pitfalls:

1. missing target token validation or access control on `withdrawTeam`, as the result, attacker may manipulate the reward output
2. logic flaw on reward generation, the user can get reward in the same block when `to == address(LPInstance)`

**Vulnerable code snippet:**

```solidity
function getPerTokenReward() public view returns(uint) {
        if ( LPInstance.balanceOf(address(this)) == 0) {
            return 0;
        }

        uint newPerTokenReward = (totalStakeReward - lastTotalStakeReward) * 1e18 / LPInstance.balanceOf(address(this));
        return PerTokenRewardLast + newPerTokenReward;
    }
```

```solidity
function transferFrom(
        address from,
        address to,
        uint amount
    ) public virtual override returns (bool) {
        address spender = _msgSender();
        if ( to == address(LPInstance) && tx.origin != address(0x547d834975279964b65F3eC685963fCc4978631E) ) {
            totalStakeReward += amount  * 7 / 100;
            _standardTransfer(from, address(this), amount * 7 / 100 );
            _standardTransfer(from, address(0x0294a4C3E85d57Eb3bE568aaC17C4243d9e78beA), amount  / 100 );
            _burn(from, amount / 50);
            amount = amount  * 90 / 100;
        }

        _spendAllowance(from, spender, amount);
        _transfer(from, to, amount);
        return true;
    }
```

```solidity
function withdrawTeam(address _token) external {
        IERC20(_token).transfer(TEAM, IERC20(_token).balanceOf(address(this)));
        payable(TEAM).transfer(address(this).balance);
    }
```

**Attack tx:**

[https://bscscan.com/tx/0xb3ac111d294ea9dedfd99349304a9606df0b572d05da8cedf47ba169d10791ed](https://bscscan.com/tx/0xb3ac111d294ea9dedfd99349304a9606df0b572d05da8cedf47ba169d10791ed)

**Analysis:**

1. The attacker borrowed $500 `USDT` from `DPPOracle` in a flash loan.
2. They converted half of the `USDT` into `sDAO`.
3. They added liquidity to the `sDAO/USDT` pool with half of the remaining `USDT` and the `sDAO` they had just converted.
4. They staked half of the LP tokens they received in the previous step.
5. They sent the remaining `sDAO` to the liquidity pool, which increased the `totalStakeReward.`
6. They called `sDAO.withdrawTeam` with LP tokens address as the target, which decreased the `LPInstance.balanceOf(address(this))` and increased the `getPerTokenReward`. They also sent a small amount of LP token to the pool to avoid division by zero.
7. They invoked `getReward` and repaid the flash loan.

[https://twitter.com/8olidity/status/1594693686398316544](https://twitter.com/8olidity/status/1594693686398316544)
[https://twitter.com/CertiKAlert/status/1594615286556393478](https://twitter.com/CertiKAlert/status/1594615286556393478)