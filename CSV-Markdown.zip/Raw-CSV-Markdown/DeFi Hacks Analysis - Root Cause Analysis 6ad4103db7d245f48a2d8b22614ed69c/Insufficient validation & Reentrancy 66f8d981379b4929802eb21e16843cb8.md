# Insufficient validation & Reentrancy

Type: Dex/AMM, Insufficient validation, Reentrancy
Date: 20211221
Lost: $8.2 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20211221-visor-finance---reentrancy
Title: Visor Finance

Root cause:  Insufficient validation & Reentrancy

Vulnerable code snippet:

[https://etherscan.io/address/0xc9f27a50f82571c1c8423a42970613b8dbda14ef#code#F1#L41](https://etherscan.io/address/0xc9f27a50f82571c1c8423a42970613b8dbda14ef#code#F1#L41)

Due to from is controllable, attacker can create a custom contract to return specific owner() to pass the check. Then reenter the deposit function via delegatedTransferERC20 function.

```solidity
// @param visr Amount of VISR transfered from sender to Hypervisor
    // @param to Address to which liquidity tokens are minted
    // @param from Address from which tokens are transferred 
    // @return shares Quantity of liquidity tokens minted as a result of deposit
    function deposit(
        uint256 visrDeposit,
        address payable from,
        address to
    ) external returns (uint256 shares) {
        require(visrDeposit > 0, "deposits must be nonzero");
        require(to != address(0) && to != address(this), "to");
        require(from != address(0) && from != address(this), "from");

        shares = visrDeposit;
        if (vvisr.totalSupply() != 0) {
          uint256 visrBalance = visr.balanceOf(address(this));
          shares = shares.mul(vvisr.totalSupply()).div(visrBalance);
        }

        if(isContract(from)) {
          require(IVisor(from).owner() == msg.sender);  **//vulnerable point**
          IVisor(from).delegatedTransferERC20(address(visr), address(this), visrDeposit);
        }
        else {
          visr.safeTransferFrom(from, address(this), visrDeposit);
        }

        vvisr.mint(to, shares);
    }
```