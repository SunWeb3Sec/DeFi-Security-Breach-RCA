# FlashLoan price manipulation - _transfer() will burn the BBOX token incorrectly.

Type: Flashloans, Price Manipulation
Date: 20221205
Lost: $12k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/BBOX_exp.sol
Title: BBOX

**Root cause:** 

FlashLoan price manipulation - _transfer() will burn the BBOX token incorrectly.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x5dfc7f3ebbb9cbfe89bc3fb70f750ee229a59f8c#code#L728](https://bscscan.com/address/0x5dfc7f3ebbb9cbfe89bc3fb70f750ee229a59f8c#code#L728)

```jsx
function _transfer(
        address from,
        address to,
        uint256 amount
    ) private {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(amount > 0, "Transfer amount must be greater than zero");

        if( 
            !_isContract(to) 
            && _recommerMapping[to] == address(0) 
            && amount >= recommeCondition){
            
            if( ammPairs[from]  ){
                addRelationEx(holder,to);
            }else{
                addRelationEx(from,to);
            }
        }

        bool isAddLiquidity;
        bool isDelLiquidity;
        ( isAddLiquidity, isDelLiquidity) = _isLiquidity(from,to);

        if( 
            pairAmountChange 
            && !isAddLiquidity
            && pairAmount > 0 
            && !ammPairs[from] 
            && pairAmount < balanceOf(uniswapV2Pair)){

            uint v = pairAmount;
            pairAmount = 0;
            _tOwned[uniswapV2Pair] =  _tOwned[uniswapV2Pair].sub(v); //vulnerable point
            _tOwned[address(0)] = _tOwned[address(0)].add(v);
            emit Transfer(uniswapV2Pair, address(0), v);

            IUniswapV2Pair(uniswapV2Pair).sync();
        }
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0xac57c78881a7c00dfbac0563e21b5ae3a8e3f9d1b07198a27313722a166cc0a3](https://explorer.phalcon.xyz/tx/bsc/0xac57c78881a7c00dfbac0563e21b5ae3a8e3f9d1b07198a27313722a166cc0a3)

**Analysis:**
[https://twitter.com/AnciliaInc/status/1599599614490877952](https://twitter.com/AnciliaInc/status/1599599614490877952)