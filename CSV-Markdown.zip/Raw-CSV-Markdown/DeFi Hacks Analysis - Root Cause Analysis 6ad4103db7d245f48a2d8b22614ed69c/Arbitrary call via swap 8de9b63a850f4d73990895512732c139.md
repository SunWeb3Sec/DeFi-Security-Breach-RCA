# Arbitrary call via swap

Type: Aggregation, Bridge, CrossChain
Date: 20220320
Lost: $570 K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220320-lifi---bridges
Title: Li.Fi

Root cause: Arbitrary call via swap

Vulnerable code snippet:

[https://etherscan.io/address/0x73a499e043b03fc047189ab1ba72eb595ff1fc8e#code#F7#L30](https://etherscan.io/address/0x73a499e043b03fc047189ab1ba72eb595ff1fc8e#code#F7#L30)

_swapData is controllable

```solidity
function swap(bytes32 transactionId, SwapData calldata _swapData) internal {
        uint256 fromAmount = _swapData.fromAmount;
        uint256 toAmount = LibAsset.getOwnBalance(_swapData.receivingAssetId);
        address fromAssetId = _swapData.sendingAssetId;
        if (!LibAsset.isNativeAsset(fromAssetId) && LibAsset.getOwnBalance(fromAssetId) < fromAmount) {
            LibAsset.transferFromERC20(_swapData.sendingAssetId, msg.sender, address(this), fromAmount);
        }

        if (!LibAsset.isNativeAsset(fromAssetId)) {
            LibAsset.approveERC20(IERC20(fromAssetId), _swapData.approveTo, fromAmount);
        }

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory res) = _swapData.callTo.call{ value: msg.value }(_swapData.callData); **//vulnerable point**
        if (!success) {
            string memory reason = LibUtil.getRevertMsg(res);
            revert(reason);
        }

        toAmount = LibAsset.getOwnBalance(_swapData.receivingAssetId) - toAmount;
        emit AssetSwapped(
            transactionId,
            _swapData.callTo,
            _swapData.sendingAssetId,
            _swapData.receivingAssetId,
            fromAmount,
            toAmount,
            block.timestamp
        );
    }
```