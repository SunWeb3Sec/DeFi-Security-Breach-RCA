# Incorrect use AMM getReserves to get price

Type: Price Manipulation
Date: 20230513
Lost: $197k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SellToken_exp.sol
Title: SellToken02

**Root cause:**

The flaw in the token price calculation allowed malicious actors to manipulate the price of the token, leading to significant losses for users and potentially creating an opportunity for the attackers to profit unfairly.

KALOS: This type of vulnerability occurs through the ShortStart() function of SellToken.Router, specifically due to an issue with the getToken2Price() function used internally. This function retrieves the token price from PancakeSwap’s Router and utilizes it. The attacker leveraged a flash loan to borrow a significant amount of funds and executed an Inflation Attack using this method.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x57db19127617b77c8abd9420b5a35502b59870d6#code](https://bscscan.com/address/0x57db19127617b77c8abd9420b5a35502b59870d6#code)

```solidity
function ShortStart(address coin,address addr,uint terrace)payable public {
        address bnbOrUsdt=mkt.getPair(coin);
        require(terraces[terrace]!=address(0) && tokenPrice[addr][coin] > 0);
        require(coin != address(0));
        require(bnbOrUsdt == _WBNB || bnbOrUsdt==_USDT);
        require(!getNewTokenPrice(addr,coin,bnbOrUsdt) && block.timestamp > tokenPriceTime[addr][coin]);
        uint bnb=msg.value;
        uint tos=getToken2Price(coin,bnbOrUsdt,mkt.balanceOf(coin))/10; **//vulnerable point**
        require(Short[addr][coin].bnb+bnb <= tos);
        Short[addr][coin].token=bnbOrUsdt;
        Short[addr][coin].coin=coin;
        Short[addr][coin].bnb+=bnb*98/100;
        tokenPrice[addr][coin]=0;
        uint newTokenValue=getTokenPrice(coin,bnbOrUsdt,bnb*98/100);
        Short[addr][coin].tokenPrice+=newTokenValue;
        Short[addr][coin].time=block.timestamp;
        address[] memory add=mySells[addr].coin;
        bool isCoin;
        for(uint i=0;i<add.length;i++){
             if(add[i]==coin){
               isCoin=true;
            }
        }
        if(!isCoin){
           mySells[addr].mnu++;
           mySells[addr].coin.push(coin);
        }
        sum+=bnb;
        payable(mkt).transfer(bnb*97/100);
        if(bnbOrUsdt ==_USDT){
           uint usdts=IERC20(_USDT).balanceOf(address(mkt));
           mkt.buy(_WBNB,_USDT,bnb*97/100);
          if(IERC20(_USDT).balanceOf(address(mkt))>usdts){
             uint ut=IERC20(_USDT).balanceOf(address(mkt))-usdts;
             mkt.buy(_USDT,coin,ut);
           }
        }else{
            mkt.buy(bnbOrUsdt,coin,bnb*97/100);
        }
        payable (owner()).transfer(bnb*2/100);
        payable (terraces[terrace]).transfer(bnb/100);
    }
function getToken2Price(address token,address bnbOrUsdt,uint bnb) view public returns(uint){
        if(token == address(0) || bnbOrUsdt == address(0)) return 0;
        address isbnb;
        if(bnbOrUsdt == _WBNB){
            isbnb=_WBNB;
            address[] memory routePath = new address[](2);
            routePath[0] = token;
            routePath[1] = isbnb;
            return IRouter(_router).getAmountsOut(bnb,routePath)[1]; **//vulnerable point**
        }else {
            isbnb=_USDT;
            address[] memory routePath = new address[](3);
            routePath[0] = token;
            routePath[1] = isbnb;
            routePath[2] = _WBNB;
            return IRouter(_router).getAmountsOut(bnb,routePath)[2]; **//vulnerable point**
        }
        
    }

/*
getAmountsOut
Given an input asset amount and an array of token addresses, 
calculates all subsequent maximum output token amounts by calling getReserves 
for each pair of token addresses in the path in turn, and using these to call getAmountOut.
*/
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0x7d04e953dad4c880ad72b655a9f56bc5638bf4908213ee9e74360e56fa8d7c6a](https://explorer.phalcon.xyz/tx/bsc/0x7d04e953dad4c880ad72b655a9f56bc5638bf4908213ee9e74360e56fa8d7c6a)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1657324561577435136](https://twitter.com/BlockSecTeam/status/1657324561577435136)

[https://twitter.com/kalos_security/status/1668092971483561985](https://twitter.com/kalos_security/status/1668092971483561985)