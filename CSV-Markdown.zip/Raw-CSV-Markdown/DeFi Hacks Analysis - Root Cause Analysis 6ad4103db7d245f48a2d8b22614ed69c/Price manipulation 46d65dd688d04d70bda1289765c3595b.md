# Price manipulation

Type: Price Manipulation
Date: 20230531
Lost: $111k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/ERC20TokenBank_exp.sol
Title: ERC20TokenBank

**Root cause:**

Attacker attempts price manipulation on Curve DEX using 'doExchange' function, exchanging USDC to USDT significantly.

![Untitled](Price%20manipulation%2046d65dd688d04d70bda1289765c3595b/Untitled.png)

image:blocksec

**Vulnerable code snippet:**

[https://etherscan.io/address/0x765b8d7cd8ff304f796f4b6fb1bcf78698333f6d#code#L234](https://etherscan.io/address/0x765b8d7cd8ff304f796f4b6fb1bcf78698333f6d#code#L234)

```jsx
function doExchange(uint256 amount) public returns(bool){
    require(amount >= minimum_amount, "invalid amount");
    require(amount <= ERC20TokenBankInterface(from_bank).balance(), "too much amount");

    ERC20TokenBankInterface(from_bank).issue(address(this), amount); **//vulnerable point**

    uint256 camount = usdc.balanceOf(address(this));
    usdc.safeApprove(address(curve), camount);
    curve.exchange_underlying(1, 2, camount, 0);

    uint256 namount = usdt.balanceOf(address(this));
    usdt.safeTransfer(to_bank, namount);

    return true;
  }

}
```

[https://etherscan.io/address/0x9Ab872A34139015Da07EE905529a8842a6142971#code#L130](https://etherscan.io/address/0x9Ab872A34139015Da07EE905529a8842a6142971#code#L130)

```jsx
function issue(address _to, uint _amount)
    public
    is_trusted(msg.sender)
    returns (bool success){
      require(_amount <= balance(), "not enough tokens");
      (bool status,) = erc20_token_addr.call(abi.encodeWithSignature("transfer(address,uint256)", _to, _amount));**//vulnerable point**
      require(status, "call failed");
      emit issue_token(_to, _amount);
      return true;
    }
```

**Attack tx:**

[https://etherscan.io/tx/0x578a195e05f04b19fd8af6358dc6407aa1add87c3167f053beb990d6b4735f26](https://etherscan.io/tx/0x578a195e05f04b19fd8af6358dc6407aa1add87c3167f053beb990d6b4735f26)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1663810037788311561](https://twitter.com/BlockSecTeam/status/1663810037788311561)