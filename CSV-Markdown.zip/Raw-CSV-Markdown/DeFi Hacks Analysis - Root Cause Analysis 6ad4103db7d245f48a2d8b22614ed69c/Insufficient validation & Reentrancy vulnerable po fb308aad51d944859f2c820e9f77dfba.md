# Insufficient validation & Reentrancy//vulnerable point

Type: Insufficient validation, Reentrancy, Yield
Date: 20211218
Lost: $30 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20211218-grim-finance---flashloan--reentrancy
Title: Grim Finance

Root cause:  Insufficient validation & Reentrancy

Vulnerable code snippet:

[https://ftmscan.com/address/0x660184ce8af80e0b1e5a1172a16168b15f4136bf#code#L1115](https://ftmscan.com/address/0x660184ce8af80e0b1e5a1172a16168b15f4136bf#code#L1115)

Due to token is controllable, the attacker can send fake tokens to the GrimBoostVault through the fake contract created by attacker. Then successful to mint protocol token.

```solidity
function depositFor(address token, uint _amount,address user ) public {

        uint256 _pool = balance();
        IERC20(token).safeTransferFrom(msg.sender, address(this), _amount); **//vulnerable point**
        earn();
        uint256 _after = balance();
        _amount = _after.sub(_pool); // Additional check for deflationary tokens
        uint256 shares = 0;
        if (totalSupply() == 0) {
            shares = _amount;
        } else {
            shares = (_amount.mul(totalSupply())).div(_pool);
        }
        _mint(user, shares);
    }
```