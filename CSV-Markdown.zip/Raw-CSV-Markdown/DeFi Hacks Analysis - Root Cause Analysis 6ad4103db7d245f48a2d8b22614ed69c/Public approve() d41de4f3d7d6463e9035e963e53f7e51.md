# Public approve()

Type: Access Control
Date: 20230412
Lost: $820k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/MetaPoint_exp.sol
Title: MetaPoint

**Root cause:**

Public approve()

This contract has a function called `approve` that grants the caller of the function access to the $META tokens without any restriction.

**Vulnerable code snippet:**

```solidity
function approve() public payable { 
    v0, /* bool */ v1 = address(0x3b5e381130673f794a5cf67fbba48688386bea86).approve(msg.sender, 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff).gas(msg.gas);
    require(bool(v0), 0, RETURNDATASIZE()); // checks call status, propagates error data on error
    require(MEM[64] + RETURNDATASIZE() - MEM[64] >= 32);
    require(v1 == bool(v1));
}
```

**Attack tx:**

invest
[https://bscscan.com/tx/0xdb01fa33bf5b79a3976ed149913ba0a18ddd444a072a2f34a0042bf32e4e7995](https://bscscan.com/tx/0xdb01fa33bf5b79a3976ed149913ba0a18ddd444a072a2f34a0042bf32e4e7995)
withdraw

[https://bscscan.com/tx/0x41853747231dcf01017cf419e6e4aa86757e59479964bafdce0921d3e616cc67](https://bscscan.com/tx/0x41853747231dcf01017cf419e6e4aa86757e59479964bafdce0921d3e616cc67)

**Analysis:**

[https://twitter.com/PeckShieldAlert/status/1645980197987192833](https://twitter.com/PeckShieldAlert/status/1645980197987192833)

[https://twitter.com/Phalcon_xyz/status/1645963327502204929](https://twitter.com/Phalcon_xyz/status/1645963327502204929)