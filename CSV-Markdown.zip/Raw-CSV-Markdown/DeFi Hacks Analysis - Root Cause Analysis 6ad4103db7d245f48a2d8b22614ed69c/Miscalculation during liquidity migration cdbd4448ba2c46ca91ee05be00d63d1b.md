# Miscalculation during liquidity migration

Type: Miscalculation
Date: 20230601
Lost: $76k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Cellframe_exp.sol
Title: Cellframenet

**Root cause:**

In liquidity migration function. The new pool had minimal BNB, while the old pool had scarce "old cell" tokens. Liquidity removal in the migration process led to increased BNB and decreased "old cell" tokens due to their limited presence in the old pool.

This process of liquidity migration was repeated multiple times. Each iteration further exploited the imbalanced state of pools, amplifying gains for the attacker. 

**Vulnerable code snippet:**

[https://bscscan.com/address/0xB4E47c13dB187D54839cd1E08422Af57E5348fc1#code#L84](https://bscscan.com/address/0xB4E47c13dB187D54839cd1E08422Af57E5348fc1#code#L84)

```jsx
function migrate(uint amountLP) external  {

        (uint token0,uint token1) = migrateLP(amountLP);
        (uint eth,uint cell, ) = IUniswapV2Router01(LP_NEW).getReserves();     

        uint resoult = cell/eth;              
        token1 = resoult * token0;

        IERC20(CELL).approve(ROUTER_V2,token1);
        IERC20(WETH).approve(ROUTER_V2,token0);

        (uint tokenA, , ) = IUniswapV2Router01(ROUTER_V2).addLiquidity(
            WETH,
            CELL,
            token0,
            token1,
            0,
            0,
            msg.sender,
            block.timestamp + 5000
        );

        uint balanceOldToken = IERC20(OLD_CELL).balanceOf(address(this));
        IERC20(OLD_CELL).transfer(marketingAddress,balanceOldToken);

        if (tokenA < token0) {
            uint256 refund0 = token0 - tokenA;
            IERC20(WETH).transfer(msg.sender,refund0);

        }

     }
function migrateLP(uint amountLP) internal returns(uint256 token0,uint256 token1) {

        IERC20(LP_OLD).transferFrom(msg.sender,address(this),amountLP);
        IERC20(LP_OLD).approve(ROUTER_V2,amountLP);

        return IUniswapV2Router01(ROUTER_V2).removeLiquidity(
            WETH,
            OLD_CELL,
            amountLP,
            0,
            0,
            address(this),
            block.timestamp + 5000
        );

    }
```

**Attack tx:**

[https://bscscan.com/tx/0x943c2a5f89bc0c17f3fe1520ec6215ed8c6b897ce7f22f1b207fea3f79ae09a6](https://bscscan.com/tx/0x943c2a5f89bc0c17f3fe1520ec6215ed8c6b897ce7f22f1b207fea3f79ae09a6)
Pre-Attack tx: [https://bscscan.com/tx/0xe2d496ccc3c5fd65a55048391662b8d40ddb5952dc26c715c702ba3929158cb9](https://bscscan.com/tx/0xe2d496ccc3c5fd65a55048391662b8d40ddb5952dc26c715c702ba3929158cb9)

**Analysis:**

[https://twitter.com/numencyber/status/1664132985883615235](https://twitter.com/numencyber/status/1664132985883615235?cxt=HHwWhoDTqceImJguAAAA)

[https://slowmist.medium.com/a-brief-analysis-on-the-cellframe-hack-b74b72b8e2e6](https://slowmist.medium.com/a-brief-analysis-on-the-cellframe-hack-b74b72b8e2e6)