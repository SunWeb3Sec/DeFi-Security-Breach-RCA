# Insufficient Validation

Type: Insufficient validation
Date: 20221119
Lost: $3k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Annex_exp.sol
Title: AnnexFinance

**Root cause:**

Missing validation on target token for the liquidator

**Vulnerable code snippet:**

```solidity
function pancakeCall(address sender, uint amount0, uint amount1, bytes calldata data) override external {
        // Unpack parameters sent from the `liquidate` function
        // NOTE: these are being passed in from some other contract, and cannot necessarily be trusted
        (address borrower, address repayAToken, address seizeAToken) = abi.decode(data, (address, address, address));

        address token0 = IPancakePair(msg.sender).token0();
        address token1 = IPancakePair(msg.sender).token1();
        require(msg.sender == IPancakeFactory(FACTORY).getPair(token0, token1));

        if (repayAToken == seizeAToken) {
            uint amount = amount0 != 0 ? amount0 : amount1; 
            address estuary = amount0 != 0 ? token0 : token1; //@note -> BNB

            // Perform the liquidation
            IERC20(estuary).safeApprove(repayAToken, amount);
            ABep20(repayAToken).liquidateBorrow(borrower, amount, seizeAToken);

            // Redeem aTokens for underlying ERC20
            ABep20(seizeAToken).redeem(IERC20(seizeAToken).balanceOf(address(this)));

            // Compute debt and pay back pair
            IERC20(estuary).transfer(msg.sender, (amount * 1000 / 997) + 1);
            return;
        }

        if (repayAToken == ABNB) {
            uint amount = amount0 != 0 ? amount0 : amount1;
            address estuary = amount0 != 0 ? token1 : token0;

            // Convert WBNB to BNB
            IWBNB(WBNB).withdraw(amount);

            // Perform the liquidation
            ABnb(repayAToken).liquidateBorrow{value: amount}(borrower, seizeAToken);

            // Redeem aTokens for underlying ERC20
            ABep20(seizeAToken).redeem(IERC20(seizeAToken).balanceOf(address(this)));

            // Compute debt and pay back pair
            (uint reserveOut, uint reserveIn) = PancakeLibrary.getReserves(FACTORY, WBNB, estuary);
            IERC20(estuary).transfer(msg.sender, PancakeLibrary.getAmountIn(amount, reserveIn, reserveOut));
            return;
        }

        if (seizeAToken == ABNB) {
            uint amount = amount0 != 0 ? amount0 : amount1;
            address source = amount0 != 0 ? token0 : token1;

            // Perform the liquidation
            IERC20(source).safeApprove(repayAToken, amount);
            ABep20(repayAToken).liquidateBorrow(borrower, amount, seizeAToken);

            // Redeem aTokens for underlying ERC20 or BNB
            ABep20(seizeAToken).redeem(IERC20(seizeAToken).balanceOf(address(this)));

            // Convert BNB to WBNB
            IWBNB(WBNB).deposit{value: address(this).balance}();

            // Compute debt and pay back pair
            (uint reserveOut, uint reserveIn) = PancakeLibrary.getReserves(FACTORY, source, WBNB);
            IERC20(WBNB).transfer(msg.sender, PancakeLibrary.getAmountIn(amount, reserveIn, reserveOut));
            return;
        }

        uint amount;
        address source;
        address estuary;
        if (amount0 != 0) {
            amount = amount0;
            source = token0;
            estuary = token1;
        } else {
            amount = amount1;
            source = token1;
            estuary = token0;
        }

        // Perform the liquidation
        IERC20(source).safeApprove(repayAToken, amount);
        ABep20(repayAToken).liquidateBorrow(borrower, amount, seizeAToken);

        // Redeem aTokens for underlying ERC20 or BNB
        uint seized_uUnits = ABep20(seizeAToken).balanceOfUnderlying(address(this));
        ABep20(seizeAToken).redeem(IERC20(seizeAToken).balanceOf(address(this)));
        address seizeUToken = ABep20Storage(seizeAToken).underlying();

        // Compute debt
        (uint reserveOut, uint reserveIn) = PancakeLibrary.getReserves(FACTORY, source, estuary);
        uint debt = PancakeLibrary.getAmountIn(amount, reserveIn, reserveOut);

        if (seizeUToken == estuary) {
            // Pay back pair
            IERC20(estuary).transfer(msg.sender, debt);
            return;
        }

        IERC20(seizeUToken).safeApprove(ROUTER, seized_uUnits);

        // Define swapping path
        address[] memory path = new address[](2);
        path[0] = seizeUToken;
        path[1] = estuary;

        uint256 minReceiveDebt = debt * 95 / 100;
        //                                                  sent, min desired, ,   path, recipient,     deadline
        IPancakeRouter(ROUTER).swapExactTokensForTokens(seized_uUnits, minReceiveDebt, path, address(this), now + 1 minutes);

        IERC20(seizeUToken).safeApprove(ROUTER, 0);

        // Pay back pair
        IERC20(estuary).transfer(msg.sender, debt);
    }
```

**Attack tx:**

[https://bscscan.com/tx/0x3757d177482171dcfad7066c5e88d6f0f0fe74b28f32e41dd77137cad859c777](https://bscscan.com/tx/0x3757d177482171dcfad7066c5e88d6f0f0fe74b28f32e41dd77137cad859c777)

**Analysis:**

1. The attacker prepares a new token and creates pool(add liquidity) for the new token
2.  Invoke the swap function with new pair and trigger the liquidating process
3. Since there is no limitation on the liquidate target, the attacker put the attack contract address for three times for the liquidate information:

```solidity
address borrower, address repayAToken, address seizeAToken) = abi.decode(data, (address, address, address));
```

1. Since the `repayAToken` is the attacker's address, it will not use the allowance in the `liquidateBorrow`
    
    ```solidity
    IERC20(estuary).safeApprove(repayAToken, amount);
    ```
    
2. The attacker utilizes the allowance to remove funds from the `liquidator`

[https://twitter.com/AnciliaInc/status/1593690338526273536](https://twitter.com/AnciliaInc/status/1593690338526273536)