# Business Logic Flaw

Type: Incorrect logic
Date: 20221129
Lost: $7k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SEAMAN_exp.sol
Title: SEAMAN

**Root cause:** 

Business Logic Flaw

In the SEAMAN project, the hacker exploited a vulnerability in the distribution mechanism of GVC tokens in the LP deposits. By calling the transfer function with the minimum unit of $SEAMAN, the attacker triggered a series of swaps. First, $SEAMAN was swapped for $BUSD in the BUSD-SEAMAN pair. Then, $BUSD was further swapped for $GVC in the BUSD-GVC pair. This caused a depletion of GVC tokens in the BUSD-GVC pair and resulted in an increase in the price of $GVC.

As a result of this flash loan attack, the attacker was able to make a profit of approximately $7,800.

**Vulnerable code snippet:**

```jsx
hToken = IERC20(0xDB95FBc5532eEb43DeEd56c8dc050c930e31017e);//GVC
lpToken = IERC20(0xDB95FBc5532eEb43DeEd56c8dc050c930e31017e);//GVC
function transfer(address recipient, uint256 amount)
    public
    virtual
    override
    returns (bool)
    {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal override {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");
        require(!_isBot[from],"the bot address");
        if(_isDelivers[from] || _isDelivers[to]){
            super._transfer(from, to, amount);
            return;
        }
         if( uniswapV2Pair.totalSupply() > 0 && balanceOf(address(this)) > balanceOf(address(uniswapV2Pair)).div(10000) && to == address(uniswapV2Pair)){
            if (
                !swapping &&
                _tokenOwner != from &&
                _tokenOwner != to &&
               !ammPairs[from] &&
                !(from == address(uniswapV2Router) && !ammPairs[to])&&
                swapAndLiquifyEnabled
            ) {
                swapping = true;
                swapAndLiquifyV3(); //vulnerable point
                swapAndLiquifyV1(); //vulnerable point
                swapping = false; 
            }
						...
function swapAndLiquifyV1() public {
        uint256 canlpAmount = lpAmount.sub(lpTokenAmount);
        uint256 amountT = balanceOf(address(uniswapV2Pair)).div(10000);
        if(balanceOf(address(this)) >= canlpAmount && canlpAmount >= amountT){
            if(canlpAmount >= amountT.mul(5))
                canlpAmount = amountT.mul(5);
            lpTokenAmount = lpTokenAmount.add(canlpAmount);
            uint256 beflpBal = lpToken.balanceOf(address(this));
            swapTokensFor(canlpAmount,address(lpToken),address(this));
            uint256 newlpBal = lpToken.balanceOf(address(this)).sub(beflpBal);
            lpDivTokenAmount = lpDivTokenAmount.add(newlpBal);
            isLpProc = true;  
        }
    }
function swapAndLiquifyV3() public {
        uint256 canhAmount = hAmount.sub(hTokenAmount);
        uint256 amountT = balanceOf(address(uniswapV2Pair)).div(10000);
        if(balanceOf(address(this)) >= canhAmount && canhAmount >= amountT){
            if(canhAmount >= amountT.mul(5))
                canhAmount = amountT.mul(5);
            hTokenAmount = hTokenAmount.add(canhAmount);
            uint256 befhBal = hToken.balanceOf(address(this));
            swapTokensFor(canhAmount,address(hToken),address(this));
            uint256 newhBal = hToken.balanceOf(address(this)).sub(befhBal);
            hDivTokenAmount = hDivTokenAmount.add(newhBal);
            isHProc = true;
        }
    }

    function swapTokensFor(uint256 tokenAmount,address token,address to) private{
         // generate the uniswap pair path of token -> weth
            address[] memory path = new address[](3);
            path[0] = address(this);
            path[1] = address(usdt);
            path[2] = address(token);
             // make the swap
            uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens( //vulnerable point
                tokenAmount,
                0, // accept any amount of ETH
                path,
                to,
                block.timestamp
            );
    }
```

![Untitled](Business%20Logic%20Flaw%207d804ce0276c401b9de6f9a92645be70/Untitled.png)

![Untitled](Business%20Logic%20Flaw%207d804ce0276c401b9de6f9a92645be70/Untitled%201.png)

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0x6f1af27d08b10caa7e96ec3d580bf39e29fd5ece00abda7d8955715403bf34a8](https://explorer.phalcon.xyz/tx/bsc/0x6f1af27d08b10caa7e96ec3d580bf39e29fd5ece00abda7d8955715403bf34a8)

**Analysis:**

[https://twitter.com/CertiKAlert/status/1597513374841044993](https://twitter.com/CertiKAlert/status/1597513374841044993)

[https://twitter.com/BeosinAlert/status/1597535796621631489](https://twitter.com/BeosinAlert/status/1597535796621631489)