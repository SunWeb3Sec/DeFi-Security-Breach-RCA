# Read-Only-Reentrancy

Type: Price Manipulation, Reentrancy
Date: 20230210
Lost: $3.65M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/dForce_exp.sol
Title: dForce

**Root cause:** 

Read-only Reentrancy in the get_virtual_price function of the Curve LP Oracle.

**Vulnerable code snippet:**

[https://arbiscan.io/address/0x6eb2dc694eb516b16dc9fbc678c60052bbdd7d80#code#L253](https://arbiscan.io/address/0x6eb2dc694eb516b16dc9fbc678c60052bbdd7d80#code#L253)

```solidity
@view
@external
def get_virtual_price() -> uint256:
    """
    @notice The current virtual price of the pool LP token
    @dev Useful for calculating profits
    @return LP token virtual price normalized to 1e18
    """
    D: uint256 = self.get_D(self._xp(self._stored_rates()), self._A())
    # D is in the units similar to DAI (e.g. converted to precision 1e18)
    # When balanced, D = n * x_u - total virtual value of the portfolio
    token_supply: uint256 = ERC20(self.lp_token).totalSupply()
    return D * PRECISION / token_supply
```

[https://arbiscan.io/address/0x6eb2dc694eb516b16dc9fbc678c60052bbdd7d80#code#L487](https://arbiscan.io/address/0x6eb2dc694eb516b16dc9fbc678c60052bbdd7d80#code#L487)

```solidity
@external
@nonreentrant('lock')
def remove_liquidity(_amount: uint256, min_amounts: uint256[N_COINS]) -> uint256[N_COINS]:
    """
    @notice Withdraw coins from the pool
    @dev Withdrawal amounts are based on current deposit ratios
    @param _amount Quantity of LP tokens to burn in the withdrawal
    @param min_amounts Minimum amounts of underlying coins to receive
    @return List of amounts of coins that were withdrawn
    """
    _lp_token: address = self.lp_token
    total_supply: uint256 = ERC20(_lp_token).totalSupply()
    amounts: uint256[N_COINS] = empty(uint256[N_COINS])

    for i in range(N_COINS):
        _balance: uint256 = self.balances[i]
        value: uint256 = _balance * _amount / total_supply
        assert value >= min_amounts[i], "Withdrawal resulted in fewer coins than expected"
        self.balances[i] = _balance - value
        amounts[i] = value
        if i == 0:
            raw_call(msg.sender, b"", value=value) **// @Vulnerable Point: Here, While Transferring ETH, LP tokens have not been burned. But the pool of ETH has been already reduced.**
        else:
            assert ERC20(self.coins[1]).transfer(msg.sender, value)

    CurveToken(_lp_token).burnFrom(msg.sender, _amount)  # Will raise if not enough

    log RemoveLiquidity(msg.sender, amounts, empty(uint256[N_COINS]), total_supply - _amount)

    return amounts
```

**Attack tx:**

[https://arbiscan.io/tx/0x5db5c2400ab56db697b3cc9aa02a05deab658e1438ce2f8692ca009cc45171dd](https://arbiscan.io/tx/0x5db5c2400ab56db697b3cc9aa02a05deab658e1438ce2f8692ca009cc45171dd)

[https://optimistic.etherscan.io/tx/0x6c19762186c9f32c81eb2a79420fc7ad4485aa916cab37ec278b216757bfba0d](https://optimistic.etherscan.io/tx/0x6c19762186c9f32c81eb2a79420fc7ad4485aa916cab37ec278b216757bfba0d)

**Analysis:**

[https://quillaudits.medium.com/decoding-dforce-protocol-read-only-reentrancy-exploit-quillaudits-c012aed4d666](https://quillaudits.medium.com/decoding-dforce-protocol-read-only-reentrancy-exploit-quillaudits-c012aed4d666)

[https://twitter.com/SlowMist_Team/status/1623956763598000129](https://twitter.com/SlowMist_Team/status/1623956763598000129)

[https://twitter.com/BlockSecTeam/status/1623901011680333824](https://twitter.com/BlockSecTeam/status/1623901011680333824)