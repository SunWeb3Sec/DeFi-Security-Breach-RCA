# Incorrect access control

Type: Access Control, Yield
Date: 20221011
Lost: $2.3 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221011-templedao---insufficient-access-control
Title: Templedao

Root cause: insufficient access control to the migrateStake function.

Vulnerable code snippet:

[https://etherscan.io/address/0xd2869042e12a3506100af1d192b5b04d65137941#code#F1#L241](https://etherscan.io/address/0xd2869042e12a3506100af1d192b5b04d65137941#code#F1#L241)

```solidity
/**
      * @notice For migrations to a new staking contract:
      *         1. User/DApp checks if the user has a balance in the `oldStakingContract`
      *         2. If yes, user calls this function `newStakingContract.migrateStake(oldStakingContract, balance)`
      *         3. Staking balances are migrated to the new contract, user will start to earn rewards in the new contract.
      *         4. Any claimable rewards in the old contract are sent directly to the user's wallet.
      * @param oldStaking The old staking contract funds are being migrated from.
      * @param amount The amount to migrate - generally this would be the staker's balance
      */
    function migrateStake(address oldStaking, uint256 amount) external {. **//vulnerable point**
        StaxLPStaking(oldStaking).migrateWithdraw(msg.sender, amount);
        _applyStake(msg.sender, amount);
    }
```