# Incorrect reward calculation

Type: Dex/AMM, Flashloans, lending
Date: 20220928
Lost: $40,305
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220928-bxh---flashloan--price-oracle-manipulation
Title: BXH

Root cause: ****Incorrect Reward calculation

Vulnerable code snippet:

[https://bscscan.com/address/0x27539b1dee647b38e1b987c41c5336b1a8dce663#code#L1606](https://bscscan.com/address/0x27539b1dee647b38e1b987c41c5336b1a8dce663#code#L1606)

Incorrect use of getReserves() to get amount of balance in the pool to calculate bonus via getAmountOut()

```solidity
function getITokenBonusAmount( uint256 _pid, uint256 _amountInToken ) public view returns (uint256){
        PoolInfo storage pool = poolInfo[_pid];

        (uint112 _reserve0, uint112 _reserve1, ) = IUniswapV2Pair(pool.swapPairAddress).getReserves(); **//vulnerable point**
        uint256 amountTokenOut = 0; 
        uint256 _fee = 0;
        if(IUniswapV2Pair(pool.swapPairAddress).token0() == address(iToken)){
            amountTokenOut = getAmountOut( _amountInToken , _reserve0, _reserve1, _fee); **//vulnerable point**
        } else {
            amountTokenOut = getAmountOut( _amountInToken , _reserve1, _reserve0, _fee); **//vulnerable point**
        }
        return amountTokenOut;
    }

    function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut, uint256 feeFactor) private pure returns (uint ) {
        require(amountIn > 0, 'UniswapV2Library: INSUFFICIENT_INPUT_AMOUNT');
        require(reserveIn > 0 && reserveOut > 0, 'UniswapV2Library: INSUFFICIENT_LIQUIDITY');

        uint256 feeBase = 10000;

        uint amountInWithFee = amountIn.mul(feeBase.sub(feeFactor));
        uint numerator = amountInWithFee.mul(reserveOut);
        uint denominator = reserveIn.mul(feeBase).add(amountInWithFee);
        uint amountOut = numerator / denominator;
        return amountOut;
    }
```