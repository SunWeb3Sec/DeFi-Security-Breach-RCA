# Incorrect price calculation via balanceOf

Type: ERC20, Flashloans
Date: 20220606
Lost: $49 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220606-discover---flashloan--price-oracle-manipulation
Title: Discover

Root cause: Incorrect price calculation via balanceOf.

Vulnerable code snippet:

[https://bscscan.com/address/0xe732a7bd6706cbd6834b300d7c56a8d2096723a7#code#L242](https://bscscan.com/address/0xe732a7bd6706cbd6834b300d7c56a8d2096723a7#code#L242)

```solidity
function getprice() public view returns (uint256 _price) {
        uint256 lpusdtamount=usdt.balanceOf(_lpaddr); **//vulnerable point** 
        uint256 lpotheramount=other.balanceOf(_lpaddr); **//vulnerable point**
       
        _price=lpusdtamount*10**18/lpotheramount;
        
    }
```