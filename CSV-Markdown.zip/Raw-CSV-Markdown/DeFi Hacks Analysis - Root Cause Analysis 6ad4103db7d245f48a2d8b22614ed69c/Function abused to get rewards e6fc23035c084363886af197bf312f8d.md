# Function abused to get rewards

Type: Business Logic Flaw
Date: 20230529
Lost: $600
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/FAPEN_exp.sol
Title: FAPEN

### Root cause: ****

It does not update the timestamp after the registration. In this case, the attacker can invoke the function register for multiple times.

### Vulnerable code snippet:

[SheepFarm | Address 0x4726010da871f4b57b5031E3EA48Bde961F122aA | BscScan](https://bscscan.com/address/0x4726010da871f4b57b5031E3EA48Bde961F122aA#code#107)

The `register()` function rewards the double gems token if you statisfy the `if` condition.

The hacker abuse the `register()` function to get extra GEM bonuse. 

```solidity
function register(address neighbor) external initialized {
		address user = msg.sender;
    require(villages[user].timestamp == 0, "just new users"); //vulnerable points
    uint256 gems;
    totalVillages++;
    if (villages[neighbor].sheeps[0] > 0 && neighbor != manager) {
        gems += GEM_BONUS * 2;
    } else{
        neighbor = manager;
        gems += GEM_BONUS;
    }
    villages[neighbor].neighbors++;
    villages[user].neighbor = neighbor;
    villages[user].gems += gems;
    emit Newbie(msg.sender, gems);
}
```

### Attack tx:

[https://bscscan.com/tx/0x5735026e5de6d1968ab5baef0cc436cc0a3f4de4ab735335c5b1bd31fa60c582](https://bscscan.com/tx/0x5735026e5de6d1968ab5baef0cc436cc0a3f4de4ab735335c5b1bd31fa60c582)

### Analysis:

- [https://twitter.com/AnciliaInc/status/1592658104394473472](https://twitter.com/AnciliaInc/status/1592658104394473472)
- [https://twitter.com/BlockSecTeam/status/1592734292727455744](https://twitter.com/BlockSecTeam/status/1592734292727455744)