# deliver() decreases supply

Type: Deflationary token, ERC20, Token-Transfer
Date: 20230118
Lost: 2 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/QTN_exp.sol
Title: QTN

**Root cause:**

Blocksec: QTN token has an inflation mechanism: all QTN holders' balanceOf will increase for each QTN's sale in Uniswap. However, the QTN's developer uses “from == UniswapPair” to judge if there is a QTN's sale. The incorrect condition is the root cause of this attack.

Uniswap pair has a function named
skim that can cheat QTN, so the attack contract increases his QTN's balance via 3 steps: 1) transfer x QTN to Uniswap pair; 2）invoke the skim function to a created contract; 3) transfer y QTN back to the attack contract (y > x).

**Vulnerable code snippet:**

[https://etherscan.io/address/0xc9fa8f4cfd11559b50c5c7f6672b9eea2757e1bd#code#L287](https://etherscan.io/address/0xc9fa8f4cfd11559b50c5c7f6672b9eea2757e1bd#code#L287)

```jsx
function balanceOf(address account) public view override returns (uint256) {
        if(account == uniswapV2Pair)
            return uniswapV2PairAmount;
        return _gonBalances[account].div(_gonsPerFragment); **//vulnerable point**
    }

function rebasePlus(uint256 _amount) private {
         _totalSupply = _totalSupply.add(_amount.div(5));
        _gonsPerFragment = TOTAL_GONS.div(_totalSupply);
    }

function _transfer(address from, address to, uint256 amount) private {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");
        require(amount > 0, "ERC20: Transfer amount must be greater than zero");
        
        if (from != owner() && to != owner()) {
            uint256 txLimitAmount = _totalSupply.mul(_percentForTxLimit).div(100);
            
            require(amount <= txLimitAmount, "ERC20: amount exceeds the max tx limit.");
            
            if(from != uniswapV2Pair) { **//vulnerable point**
                require(!blacklist[from] && !blacklist[to], 'ERC20: the transaction was blocked.');
                require(_buyInfo[from] == 0 || _buyInfo[from].add(_timeLimitFromLastBuy) < now, "ERC20: Tx not allowed yet.");
                
                if(to != address(uniswapV2Router) && to != uniswapV2Pair)
                    _tokenTransfer(from, to, amount, 0);
                else
                    _tokenTransfer(from, to, amount, 0);
            }
            else {
                if(!_live)
                    blacklist[to] = true;
                
                require(balanceOf(to) <= txLimitAmount, 'ERC20: current balance exceeds the max limit.');
                
                _buyInfo[to] = now;
                _tokenTransfer(from, to, amount, 0);

                uint256 rebaseLimitAmount = _totalSupply.mul(_percentForRebase).div(100);
                uint256 currentBalance = balanceOf(to);
                uint256 newBalance = currentBalance.add(amount);
                if(currentBalance < rebaseLimitAmount && newBalance < rebaseLimitAmount) {
                    rebasePlus(amount);
                }
            }
        } else {
            _tokenTransfer(from, to, amount, 0);
        }
    }
```

**Attack tx:**

[https://etherscan.io/tx/0x37cb8626e45f0749296ef080acb218e5ccc7efb2ae4d39c952566dc378ca1c4c](https://etherscan.io/tx/0x37cb8626e45f0749296ef080acb218e5ccc7efb2ae4d39c952566dc378ca1c4c)

[https://etherscan.io/tx/0xfde10ad92566f369b23ed5135289630b7a6453887c77088794552c2a3d1ce8b7](https://etherscan.io/tx/0xfde10ad92566f369b23ed5135289630b7a6453887c77088794552c2a3d1ce8b7)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1615625901739511809](https://twitter.com/BlockSecTeam/status/1615625901739511809)