# Arbitrary call via callFunction

Type: Arbitrary call, MEV
Date: 20220928
Lost: $94,304
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220928-MEVBOT---Badc0de
Title: MEVBOT - Badc0de

Root cause: Arbitrary call via callFunction.

Vulnerable code snippet:

In this case dYdX called "callFunction" on 0xbad.

Unfortunately for 0xbad, their code allowed for arbitrary execution.

Need to decompiled:

[https://etherscan.io/address/0xbadc0defafcf6d4239bdf0b66da4d7bd36fcf05a#code](https://etherscan.io/address/0xbadc0defafcf6d4239bdf0b66da4d7bd36fcf05a#code)

![Untitled](Arbitrary%20call%20via%20callFunction%2050369321f75c49269e0c1393a35233f0/Untitled.png)