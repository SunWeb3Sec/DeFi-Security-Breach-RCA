# Set bZxUSDC address instead of bZxUSDT

Type: Misconfiguration
Date: 20230413
Lost: $11.6M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/YearnFinance_exp.sol
Title: yearnFinance

**Root cause:**

Set bZxUSDC address instead of bZxUSDT

Sam: It seems like the iearn USDT token (yUSDT) has been broken since deploy, which was *checks notes* over 1000 days ago. It was misconfigured to use the Fulcrum iUSDC token instead of the Fulcrum iUSDT token.

**Vulnerable code snippet:**

```solidity
constructor() public ERC20Detailed("iearn USDT", "yUSDT", 6) {
	fulcrum = address(0xF013406A0B1d544238083DF0B93ad0d2cBE0f65f);  // misconfigured
}
```

**Attack tx:**

[https://etherscan.io/tx/0x055cec4fa4614836e54ea2e5cd3d14247ff3d61b85aa2a41f8cc876d131e0328](https://etherscan.io/tx/0x055cec4fa4614836e54ea2e5cd3d14247ff3d61b85aa2a41f8cc876d131e0328)

[https://etherscan.io/tx/0xd55e43c1602b28d4fd4667ee445d570c8f298f5401cf04e62ec329759ecda95d](https://etherscan.io/tx/0xd55e43c1602b28d4fd4667ee445d570c8f298f5401cf04e62ec329759ecda95d)

**Analysis:**

[https://twitter.com/cmichelio/status/1646422861219807233](https://twitter.com/cmichelio/status/1646422861219807233)

[https://twitter.com/BeosinAlert/status/1646481687445114881](https://twitter.com/BeosinAlert/status/1646481687445114881)