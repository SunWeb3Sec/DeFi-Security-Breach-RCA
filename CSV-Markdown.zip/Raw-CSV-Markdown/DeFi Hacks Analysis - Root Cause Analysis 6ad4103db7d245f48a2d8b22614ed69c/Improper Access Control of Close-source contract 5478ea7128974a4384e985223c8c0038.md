# Improper Access Control of Close-source contract

Type: Access Control
Date: 20230524
Lost: 384 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/LocalTrader2_exp.sol
Title: Local Trade LCT

**Root cause:** 

Improper Access Control of Close-source contract, involved modifying certain contract parameters and exploiting vulnerabilities in the getTokenPrice() function.

**Vulnerable code snippet:**

[https://library.dedaub.com/decompile?md5=eac769a0f6ce1325c4c553270fd17362](https://library.dedaub.com/decompile?md5=eac769a0f6ce1325c4c553270fd17362)

![Untitled](Improper%20Access%20Control%20of%20Close-source%20contract%205478ea7128974a4384e985223c8c0038/Untitled.jpeg)

![Untitled](Improper%20Access%20Control%20of%20Close-source%20contract%205478ea7128974a4384e985223c8c0038/Untitled%201.jpeg)

**Attack tx:**

1. [https://bscscan.com/tx/0x57b589f631f8ff20e2a89a649c4ec2e35be72eaecf155fdfde981c0fec2be5ba](https://bscscan.com/tx/0x57b589f631f8ff20e2a89a649c4ec2e35be72eaecf155fdfde981c0fec2be5ba)
2. [https://bscscan.com/tx/0xbea605b238c85aabe5edc636219155d8c4879d6b05c48091cf1f7286bd4702ba](https://bscscan.com/tx/0xbea605b238c85aabe5edc636219155d8c4879d6b05c48091cf1f7286bd4702ba)
3. [https://bscscan.com/tx/0x49a3038622bf6dc3672b1b7366382a2c513d713e06cb7c91ebb8e256ee300dfb](https://bscscan.com/tx/0x49a3038622bf6dc3672b1b7366382a2c513d713e06cb7c91ebb8e256ee300dfb)
4. [https://bscscan.com/tx/0x042b8dc879fa193acc79f55a02c08f276eaf1c4f7c66a33811fce2a4507cea63](https://bscscan.com/tx/0x042b8dc879fa193acc79f55a02c08f276eaf1c4f7c66a33811fce2a4507cea63)

**Analysis:**

[https://twitter.com/numencyber/status/1661213691893944320](https://twitter.com/numencyber/status/1661213691893944320)