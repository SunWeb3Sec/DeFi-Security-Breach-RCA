# getStaticIncome()

Type: Business Logic Flaw, Flashloans, Insufficient validation, Misconfiguration
Date: 20230325
Lost: $24k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/DBW_exp.sol
Title: DBW

**Root cause:**

The root cause is that the dividend awards are based on the percentage of LP currently owned by the user,
and does not take into account multiple dividends after the transfer of LP.

**Vulnerable code snippet:**

claim reward 

```solidity
function getStaticIncome() public {
        if(!hasRole(VIP_ROLE, msg.sender)&&!_is_static_dynamic){
            _staticIncome_(msg.sender); **//vulnerable point**
        }
    }
```

```solidity
function pledge_lp (uint256 count) public{
        require(!Address.isContract(msg.sender),"the address is contract");
        require(count > 0,"count > 0");
        uint256 _spend =IERC20(_lp).allowance(msg.sender,address(this));
        require(_spend>=count,"lp must be authorized first");
        uint256 _lpBalance =IERC20(_lp).balanceOf(msg.sender);
        require(_lpBalance>=count,"lp Insufficient balance");
        bool _isTransfer =IERC20(_lp).transferFrom(msg.sender,address(this),count);
        require(_isTransfer,"lp transfer err");
        _balances_lp[msg.sender]+=count;
        _user_convertLPToDBW[msg.sender]=convertLPToDBW(_balances_lp[msg.sender]);
        ff_handling_fee_user[msg.sender]=_handling_fee;
        
        if(!isHaveLPuser(msg.sender)){
            lpUserCount++;
            lpUsers.push(msg.sender);
        }
    }
```

redeem LP

```solidity
function redemption_lp (uint256 count) public{
        require(!Address.isContract(msg.sender),"the address is contract");
        require(count > 0,"count > 0");
        require(_balances_lp[msg.sender] >= count,"_balances_lp[msg.sender] >= count");
        
        bool _isTransfer = IERC20(_lp).transfer(msg.sender, count);
        require(_isTransfer,"not lp Transfer");
        _balances_lp[msg.sender]-=count;
        _user_convertLPToDBW[msg.sender]=convertLPToDBW(_balances_lp[msg.sender]);

        uint256 ff_count = getFFCount();
        if(ff_count>0){
            _transfer(address(this),msg.sender,ff_count);
            //_user_dbw_lp[msg.sender]+=ff_count;
            ff_handling_fee_user[msg.sender]=_handling_fee;
        }
    }
```

**Attack tx:**

[https://bscscan.com/tx/0x3b472f87431a52082bae7d8524b4e0af3cf930a105646259e1249f2218525607](https://bscscan.com/tx/0x3b472f87431a52082bae7d8524b4e0af3cf930a105646259e1249f2218525607)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1639655134232969216](https://twitter.com/BeosinAlert/status/1639655134232969216)

[https://twitter.com/AnciliaInc/status/1639289686937210880](https://twitter.com/AnciliaInc/status/1639289686937210880)