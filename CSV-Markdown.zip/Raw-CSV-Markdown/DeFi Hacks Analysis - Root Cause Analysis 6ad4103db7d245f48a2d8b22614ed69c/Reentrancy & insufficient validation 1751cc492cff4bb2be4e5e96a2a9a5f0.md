# Reentrancy & insufficient validation

Type: Dex/AMM, Flashloans, Insufficient validation, Reentrancy
Date: 20220313
Lost: $1.7 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220313-paraluni---flashloan--reentrancy
Title: Paraluni

Root cause: reentrancy & insufficient validation

Vulnerable code snippet:

[https://bscscan.com/address/0xa386f30853a7eb7e6a25ec8389337a5c6973421d#code#L2501](https://bscscan.com/address/0xa386f30853a7eb7e6a25ec8389337a5c6973421d#code#L2501)

From Halborn:

The depositByAddLiquidity function calls an internal 
depositByAddLiquidityInternal function that transfers the attacker’s 
deposit into the appropriate pool.  However the pool ID value (_pid) 
used to look up the appropriate pool [is not validated internally](https://netfreeman.com/2022/03/202203132332576318.html).

The attacker takes advantage of this by directing this to an attacker-controlled contract, [whose malicious transferFrom function is called](https://coincodecap.com/paraluni-hacked-reportedly-1-7m-lost). 
 This function then exploits the reentrancy vulnerability to call the 
Masterchef deposit function before the internal state is updated.  
Between the initial and malicious deposits, the attacker is credited 
with excess tokens and able to extract more value from the contract than
 they deposited.

```solidity
function depositByAddLiquidity(uint256 _pid, address[2] memory _tokens, uint256[2] memory _amounts) external{
        require(_amounts[0] > 0 && _amounts[1] > 0, "!0");
        address[2] memory tokens;
        uint256[2] memory amounts;
        (tokens[0], amounts[0]) = _doTransferIn(msg.sender, _tokens[0], _amounts[0]);
        (tokens[1], amounts[1]) = _doTransferIn(msg.sender, _tokens[1], _amounts[1]);
        depositByAddLiquidityInternal(msg.sender, _pid, tokens,amounts);
    }
function depositByAddLiquidityInternal(address _user, uint256 _pid, address[2] memory _tokens, uint256[2] memory _amounts) internal {
        PoolInfo memory pool = poolInfo[_pid];
        require(address(pool.ticket) == address(0), "T:E");
        uint liquidity = addLiquidityInternal(address(pool.lpToken), _user, _tokens, _amounts);
        _deposit(_pid, liquidity, _user);
    }
```