# Incorrect calculation - 10000 vs 1000

Type: Dex/AMM, Miscalculation
Date: 20210915
Lost: $1 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210915-nowswap-platform
Title: NowSwap

Root cause:  Incorrect calculation

Same Uranium, NowSwap and Nimbus issue

Vulnerable code snippet:

inconsistent value in the code, 10000 vs 1000

[https://etherscan.io/address/0xa14660a33cc608b902f5bb49c8213bd4c8a4f4ca#code](https://etherscan.io/address/0xa14660a33cc608b902f5bb49c8213bd4c8a4f4ca#code) unverified contract