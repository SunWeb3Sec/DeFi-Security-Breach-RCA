# Reentrancy

Type: Dex/AMM, Reentrancy
Date: 20221223
Lost: $170k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Defrost_exp.sol
Title: Defrost

**Root cause:** 

Reentrancy.

Lack of reentrancy lock for the flashloan()/deposit() functions, which was used by the hacker to manipulate the share price of LSWUSDC

**Vulnerable code snippet:**

```solidity
function flashLoan(
        IERC3156FlashBorrower receiver,
        address token,
        uint256 amount,
        bytes calldata data
    ) external virtual returns (bool) {
        require(token == address(asset),"flash borrow token Error!");
        uint256 fee = flashFee(token, amount);
        onWithdraw(address(receiver),amount);
        require(
            receiver.onFlashLoan(msg.sender, token, amount, fee, data) == _RETURN_VALUE,
            "invalid return value"
        );
        onDeposit(address(receiver),amount + fee,0);
        emit FlashLoan(msg.sender,address(receiver),token,amount);
        return true;
    }
function deposit(uint256 _amount, address receiver) external returns (uint256){
        uint256 amount = _deposit(msg.sender,_amount,receiver);
        emit Deposit(msg.sender,receiver,_amount,amount);
        return amount;
    }
```

**Attack tx:** 

[https://snowtrace.io/tx/0xc6fb8217e45870a93c25e2098f54f6e3b24674a3083c30664867de474bf0212d](https://snowtrace.io/tx/0xc6fb8217e45870a93c25e2098f54f6e3b24674a3083c30664867de474bf0212d)

**Analysis:**

[https://twitter.com/PeckShieldAlert/status/1606276020276891650](https://twitter.com/PeckShieldAlert/status/1606276020276891650)