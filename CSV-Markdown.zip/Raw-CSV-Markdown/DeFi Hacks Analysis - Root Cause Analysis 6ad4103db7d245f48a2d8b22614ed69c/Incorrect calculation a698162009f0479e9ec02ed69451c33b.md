# Incorrect calculation

Type: ERC20, Miscalculation
Date: 20221020
Lost: 16 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221020-health---transfer-logic-flaw
Title: HEALTH

Root cause:  incorrect calculation.

Vulnerable code snippet:

[https://bscscan.com/address/0x32B166e082993Af6598a89397E82e123ca44e74E#code#L799](https://bscscan.com/address/0x32B166e082993Af6598a89397E82e123ca44e74E#code#L799)

Attacker can perform price manipulation by transferring HEALTH token 999 times to reduce HEALTH token in uniswap pair.

```solidity
function _transfer(address from, address to, uint256 value) private {
        require(value <= _balances[from]);
        require(to != address(0));
        
        uint256 contractTokenBalance = balanceOf(address(this));

        bool overMinTokenBalance = contractTokenBalance >= numTokensSellToAddToLiquidity;
        if (
            overMinTokenBalance &&
            !inSwapAndLiquify &&
            to == uniswapV2Pair &&
            swapAndLiquifyEnabled
        ) {
            contractTokenBalance = numTokensSellToAddToLiquidity;
            //add liquidity
            swapAndLiquify(contractTokenBalance);
        }
        if (block.timestamp >= pairStartTime.add(jgTime) && pairStartTime != 0) {
            if (from != uniswapV2Pair) {
                uint256 burnValue = _balances[uniswapV2Pair].mul(burnFee).div(1000);  **//vulnerable point**
                _balances[uniswapV2Pair] = _balances[uniswapV2Pair].sub(burnValue);  **//vulnerable point**
                _balances[_burnAddress] = _balances[_burnAddress].add(burnValue);  **//vulnerable point**
                if (block.timestamp >= pairStartTime.add(jgTime)) {
                    pairStartTime += jgTime;
                }
                emit Transfer(uniswapV2Pair,_burnAddress, burnValue);
                IPancakePair(uniswapV2Pair).sync();
            }
```