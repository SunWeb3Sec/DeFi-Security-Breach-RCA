# Read-only reentrancy of Balancer

Type: Reentrancy
Date: 20230405
Lost: $1M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Sentiment_exp.sol
Title: Sentiment

**Root cause:** 

Attacker re enter Balancer Vaults execute malicious code before pool balances were updated and steal money using overpriced collateral. the `_joinOrExit` function is called whenever the `joinPool` or `exitPool` is called by an external protocol user.

**Vulnerable code snippet:**

```solidity

function joinPool(
        bytes32 poolId,
        address sender,
        address recipient,
        JoinPoolRequest memory request
    ) external payable override whenNotPaused {
        // This function doesn't have the nonReentrant modifier: it is applied to `_joinOrExit` instead.

        // Note that `recipient` is not actually payable in the context of a join - we cast it because we handle both
        // joins and exits at once.
        _joinOrExit(PoolBalanceChangeKind.JOIN, poolId, sender, payable(recipient), _toPoolBalanceChange(request)); **//vulnerable point**
    }
...

function _joinOrExit(
        PoolBalanceChangeKind kind,
        bytes32 poolId,
        address sender,
        address payable recipient,
        PoolBalanceChange memory change
    ) private nonReentrant withRegisteredPool(poolId) authenticateFor(sender) {  **//vulnerable point**
        // This function uses a large number of stack variables (poolId, sender and recipient, balances, amounts, fees,
        // etc.), which leads to 'stack too deep' issues. It relies on private functions with seemingly arbitrary
        // interfaces to work around this limitation.

        InputHelpers.ensureInputLengthMatch(change.assets.length, change.limits.length);

        // We first check that the caller passed the Pool's registered tokens in the correct order, and retrieve the
        // current balance for each.
        IERC20[] memory tokens = _translateToIERC20(change.assets);
        bytes32[] memory balances = _validateTokensAndGetBalances(poolId, tokens);
...
```

**Attack tx:**

[https://arbiscan.io/tx/0xa9ff2b587e2741575daf893864710a5cbb44bb64ccdc487a100fa20741e0f74d](https://arbiscan.io/tx/0xa9ff2b587e2741575daf893864710a5cbb44bb64ccdc487a100fa20741e0f74d)

**Analysis:**

[https://twitter.com/peckshield/status/1643417467879059456](https://twitter.com/peckshield/status/1643417467879059456)
[https://twitter.com/spreekaway/status/1643313471180644360](https://twitter.com/spreekaway/status/1643313471180644360)
[https://medium.com/coinmonks/theoretical-practical-balancer-and-read-only-reentrancy-part-1-d6a21792066c](https://medium.com/coinmonks/theoretical-practical-balancer-and-read-only-reentrancy-part-1-d6a21792066c)
[https://forum.balancer.fi/t/reentrancy-vulnerability-scope-expanded/4345](https://forum.balancer.fi/t/reentrancy-vulnerability-scope-expanded/4345)