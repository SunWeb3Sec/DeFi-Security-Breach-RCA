# Reentrancy in claimReward()

Type: ERC721, Reentrancy
Date: 20221001
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221001-thunder-brawl---reentrancy
Title: Thunder Brawl
fixed?: unfixed

Root cause: claimReward() - rewards are being drained due to a reentrancy bug.

Vulnerable code snippet:

[https://bscscan.com/address/0xae191Ca19F0f8E21d754c6CAb99107eD62B6fe53#code#L252](https://bscscan.com/address/0xae191Ca19F0f8E21d754c6CAb99107eD62B6fe53#code#L252)

[https://bscscan.com/address/0x72e901f1bb2bfa2339326dfb90c5cec911e2ba3c#code#L1536](https://bscscan.com/address/0x72e901f1bb2bfa2339326dfb90c5cec911e2ba3c#code#L1536)

---

```solidity
function claimReward(
        uint256 _ID,
        address payable _player,
        uint256 _amount,
        bool _rewardStatus,
        uint256 _x,
        string memory name,
        address _add
    ) external {
        require(gameMode);
        bool checkValidity = guess(_x, name, _add);

        if (checkValidity == true) {
            if (winners[_ID][_player] == _amount) {
                _player.transfer(_amount * 2);
                if (_rewardStatus == true) {
                    sendReward(); **//vulnerable point**
                }
                delete winners[_ID][_player];
            } else {
                if (_rewardStatus == true) {
                    sendRewardDys();
                }
            }
            rewardStatus = false;
        }
    }
function sendReward() public {
        thunderbrawlRoulette.reward(msg.sender, 1);
    }
```

```jsx
function reward(address to,uint256 _mintAmount) external {
        uint256 supply = totalSupply();
        uint256 rewardSupply = rewardTotal;
        require(rewardSupply <= rewardSize,"");
        for (uint256 i = 1; i <= _mintAmount; i++) {          
          _safeMint(to, supply + i); 
          rewardTotal++;         
        }
  }
/**
     * @dev Same as {xref-ERC721-_safeMint-address-uint256-}[`_safeMint`], with an additional `data` parameter which is
     * forwarded in {IERC721Receiver-onERC721Received} to contract recipients.
     */
    function _safeMint(
        address to,
        uint256 tokenId,
        bytes memory data
    ) internal virtual {
        _mint(to, tokenId);
        require(
            _checkOnERC721Received(address(0), to, tokenId, data), **//callback** 
            "ERC721: transfer to non ERC721Receiver implementer"
        );
    }
```

![1.png](Reentrancy%20in%20claimReward()%20329ed19af9324a549a958d27bfe4f801/1.png)