# No sender address validation.

Type: Deflationary token, Flashloans
Date: 20220529
Lost: 279 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220529-novo-protocol---flashloan--price-oracle-manipulation
Title: NOVO Protocol

Root cause:  No sender address validation.

Vulnerable code snippet:

[https://bscscan.com/address/0xa0787daad6062349f63b7c228cbfd5d8a3db08f1#code#L2941](https://bscscan.com/address/0xa0787daad6062349f63b7c228cbfd5d8a3db08f1#code#L2941)

There is no sender address validation in the overridden transferFrom function

```solidity
function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) public override returns (bool) {
        // locked the NOVO of staking holders
        uint256 lockedAmount = getLockedAmount(sender);
        if (lockedAmount > 0) {
            require(
                (balanceOf(sender) - amount) >= lockedAmount,
                "Your balance was locked"
            );
        }
// _approve(  **//vulnerable point - commented out**
        //     sender,
        //     _msgSender(),
        //     _allowances[sender][_msgSender()].sub(
        //         amount,
        //         "BEP20: transfer amount exceeds allowance"
        //     )
        // );
```