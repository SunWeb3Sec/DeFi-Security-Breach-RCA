# Incorrect logic flow

Type: Incorrect logic, Yield
Date: 20210622
Lost: $4.5 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210622-eleven-finance---doesnt-burn-shares
Title: Eleven Finance

Root cause:  Incorrect logic flow

Vulnerable code snippet: 

[https://bscscan.com/address/0x27dd6e51bf715cfc0e2fe96af26fc9ded89e4be8?a=0xa5c29d44817551aa499260ab9640584bf124d4b7#code#L1131](https://bscscan.com/address/0x27dd6e51bf715cfc0e2fe96af26fc9ded89e4be8?a=0xa5c29d44817551aa499260ab9640584bf124d4b7#code#L1131)

In emergencyBurn function, we can see incorrect logic, withdraw token but without burning token. So attacker can withdraw again after calling emergencyBurn.

```solidity
function emergencyBurn() public {  **//vulnerable point**
        uint balan = balanceOf(msg.sender);
        uint avai = available();
        if(avai<balan) IMasterMind(mastermind).withdraw(nrvPid, (balan.sub(avai)));
        token.safeTransfer(msg.sender, balan);
        emit Withdrawn(msg.sender, balan, block.number);
    }
```