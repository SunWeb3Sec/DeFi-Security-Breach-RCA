# FlashLoan price manipulation

Type: Flashloans, Price Manipulation
Date: 20221210
Lost: 87 WBNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/TIFI_exp.sol
Title: TIFIToken

**Root cause:** 

FlashLoan price manipulation.

**Vulnerable code snippet:**

Not open sourced.

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0x1c5272ce35338c57c6b9ea710a09766a17bbf14b61438940c3072ed49bfec402](https://explorer.phalcon.xyz/tx/bsc/0x1c5272ce35338c57c6b9ea710a09766a17bbf14b61438940c3072ed49bfec402)

**Analysis:**

[https://twitter.com/peckshield/status/1601492605535399936](https://twitter.com/peckshield/status/1601492605535399936)