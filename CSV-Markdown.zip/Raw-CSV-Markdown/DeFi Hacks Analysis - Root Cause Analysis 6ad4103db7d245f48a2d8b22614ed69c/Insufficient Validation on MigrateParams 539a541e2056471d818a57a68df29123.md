# Insufficient Validation on MigrateParams

Type: Insufficient validation
Date: 20221027
Lost: $15.8M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/TeamFinance.exp.sol
Title: Team Finance

**Root cause:**

In `migrate` function, the validation on `MigrateParams` is the function's input value.

**Vulnerable code snippet:**

[https://etherscan.io/address/0x48d118c9185e4dbafe7f3813f8f29ec8a6248359#code](https://etherscan.io/address/0x48d118c9185e4dbafe7f3813f8f29ec8a6248359#code%23L1535)

```solidity
/**
     * migrate liquidity from v2 to v3
    */
    function migrate(
        uint256 _id,
        IV3Migrator.MigrateParams calldata params,
        bool noLiquidity,
        uint160 sqrtPriceX96,
        bool _mintNFT
    )
    external
    payable
    whenNotPaused
    nonReentrant
    {
        require(address(nonfungiblePositionManager) != address(0), "NFT manager not set");
        require(address(v3Migrator) != address(0), "v3 migrator not set");
        Items memory lockedERC20 = lockedToken[_id];
        require(block.timestamp < lockedERC20.unlockTime, "Unlock time already reached");
        require(_msgSender() == lockedERC20.withdrawalAddress, "Unauthorised sender");
        require(!lockedERC20.withdrawn, "Already withdrawn");

        uint256 totalSupplyBeforeMigrate = nonfungiblePositionManager.totalSupply();
        
        //scope for solving stack too deep error
        {
            uint256 ethBalanceBefore = address(this).balance;
            uint256 token0BalanceBefore = IERC20(params.token0).balanceOf(address(this));
            uint256 token1BalanceBefore = IERC20(params.token1).balanceOf(address(this));
            
            //initialize the pool if not yet initialized
            if(noLiquidity) {
                v3Migrator.createAndInitializePoolIfNecessary(params.token0, params.token1, params.fee, sqrtPriceX96);
            }

            IERC20(params.pair).approve(address(v3Migrator), params.liquidityToMigrate);

            v3Migrator.migrate(params);

            //refund eth or tokens
            uint256 refundEth = address(this).balance - ethBalanceBefore;
            (bool refundSuccess,) = _msgSender().call.value(refundEth)("");
            require(refundSuccess, 'Refund ETH failed');

            uint256 token0BalanceAfter = IERC20(params.token0).balanceOf(address(this));
            uint256 refundToken0 = token0BalanceAfter - token0BalanceBefore;
            if( refundToken0 > 0 ) {
                require(IERC20(params.token0).transfer(_msgSender(), refundToken0));
            }

            uint256 token1BalanceAfter = IERC20(params.token1).balanceOf(address(this));
            uint256 refundToken1 = token1BalanceAfter - token1BalanceBefore;
            if( refundToken1 > 0 ) {
                require(IERC20(params.token1).transfer(_msgSender(), refundToken1));
            }
        }

        //remove old locked token details
        _removeERC20Deposit(_id);

        //Get the token id of newly generated nft for v3
        uint256 totalSupplyAfterMigrate = nonfungiblePositionManager.totalSupply();
        require(totalSupplyAfterMigrate == totalSupplyBeforeMigrate.add(1));
        uint256 tokenIndex = totalSupplyAfterMigrate.sub(1);
        uint256 tokenId = nonfungiblePositionManager.tokenByIndex(tokenIndex);

        //add new locked nft details ( received after migrating liquidity )
        uint256 newDepositId = ++depositId;
        _addNFTDeposit(_id, newDepositId, tokenId);

        listMigratedDepositIds[newDepositId] = _id;

        if (_mintNFT){
            require(NFT != address(0), 'NFT: Unintalized');
            nftMinted[newDepositId] = true;
        }

        if(nftMinted[_id])
        {
            nftMinted[_id] = false;
            IERC721Extended(NFT).burn(_id);
        }
        if (_mintNFT){
            IERC721Extended(NFT).mintLiquidityLockNFT(_msgSender(), newDepositId);
        }
        
        emit LiquidityMigrated(_msgSender(), _id, newDepositId, tokenId);
    }
```

**Attack tx:**

[https://etherscan.io/tx/0xb2e3ea72d353da43a2ac9a8f1670fd16463ab370e563b9b5b26119b2601277ce](https://etherscan.io/tx/0xb2e3ea72d353da43a2ac9a8f1670fd16463ab370e563b9b5b26119b2601277ce)

- Pre-work1: `lockToken()`
    [https://etherscan.io/tx/0xe8f17ee00906cd0cfb61671937f11bd3d26cdc47c1534fedc43163a7e89edc6f](https://etherscan.io/tx/0xe8f17ee00906cd0cfb61671937f11bd3d26cdc47c1534fedc43163a7e89edc6f)
- Pre-work2: `extendLockDuration()`
id 15324: [https://etherscan.io/tx/0x2972f75d5926f8f948ab6a0cabc517a05f0da5b53e20f670591afbaa501aa436](https://etherscan.io/tx/0x2972f75d5926f8f948ab6a0cabc517a05f0da5b53e20f670591afbaa501aa436)
id 15325: [https://etherscan.io/tx/0xec75bb553f50af37f8dd8f4b1e2bfe4703b27f586187741b91db770ad9b230cb](https://etherscan.io/tx/0xec75bb553f50af37f8dd8f4b1e2bfe4703b27f586187741b91db770ad9b230cb)
id 15326: [https://etherscan.io/tx/0x79ec728612867b3d82c0e7401e6ee1c533b240720c749b3968dea1464e59b2c4](https://etherscan.io/tx/0x79ec728612867b3d82c0e7401e6ee1c533b240720c749b3968dea1464e59b2c4)
id 15327: [https://etherscan.io/tx/0x51185fb580892706500d3b6eebb8698c27d900618021fb9b1797f4a774fffb04](https://etherscan.io/tx/0x51185fb580892706500d3b6eebb8698c27d900618021fb9b1797f4a774fffb04)

**Analysis:**

Team Finance Official : [https://twitter.com/TeamFinance_/status/1585770918873542656](https://twitter.com/TeamFinance_/status/1585770918873542656)
PeckShield : [https://twitter.com/peckshield/status/1585587858978623491](https://twitter.com/peckshield/status/1585587858978623491)
Solid Group : [https://twitter.com/solid_group_1/status/1585643249305518083](https://twitter.com/solid_group_1/status/1585643249305518083)
Beiosin Alert : [https://twitter.com/BeosinAlert/status/1585578499125178369](https://twitter.com/BeosinAlert/status/1585578499125178369)