# Use assign (=) instead of accumulate (+=)

Type: Incorrect logic
Date: 20230502
Lost: $1M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Level_exp.sol
Title: Level

**Root cause:**

Due to the lack of checks of repeated items for the array argument of the vulnerable function. 

**Vulnerable code snippet:**

```solidity
function claimMultiple(uint256[] calldata _epoches, address _to) external {
	uint256 totalReward;
	for (uint256 i; i < _epoches.length; ++i) {
		uint256 epoch = _epoches[i];
		if (epoch < currentEpoch) {
			uint256 reward = claimable(epoch, msg.sender);
			users[epoch][msg.sender].claimed = reward;  **// @audit: vulnerable, should be +=**
			totalReward += reward;
		}
	}
	LVL.safeTransfer(_to, totalReward);
}
```

**Attack tx:**

[https://bscscan.com/tx/0x6aef8bb501a53e290837d4398b34d5d4d881267512cfe78eb9ba7e59f41dad04](https://bscscan.com/tx/0x6aef8bb501a53e290837d4398b34d5d4d881267512cfe78eb9ba7e59f41dad04)

[https://bscscan.com/tx/0xe1f257041872c075cbe6a1212827bc346df3def6d01a07914e4006ec43027165](https://bscscan.com/tx/0xe1f257041872c075cbe6a1212827bc346df3def6d01a07914e4006ec43027165)

**Analysis:**

[https://twitter.com/peckshield/status/1653149493133729794](https://twitter.com/peckshield/status/1653149493133729794)

[https://twitter.com/BlockSecTeam/status/1653267431127920641](https://twitter.com/BlockSecTeam/status/1653267431127920641)

[https://twitter.com/kalos_security/status/1668092143167213569](https://twitter.com/kalos_security/status/1668092143167213569)