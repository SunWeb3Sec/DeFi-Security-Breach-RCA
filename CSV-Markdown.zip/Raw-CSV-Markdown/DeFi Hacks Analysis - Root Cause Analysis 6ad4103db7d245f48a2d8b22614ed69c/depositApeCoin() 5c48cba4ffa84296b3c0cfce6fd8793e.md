# depositApeCoin()

Type: Access Control, Business Logic Flaw
Date: 20230317
Lost: 2,909 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Paraspace_exp_2.sol
Title: ParaSpace NFT

**Root cause:**

There is a flawed logic in borrow() of the ParaProxy contract (0x638a98BBB92a7582d07C52ff407D49664DC8b3Ee
) of  ParaSpace NFT

. The attacker can borrow more tokens as his scaledBalance will be enlarged by depositing into the position of the proxy (0xC5c9fB6223A989208Df27dCEE33fC59ff5c26fFF), i.e., specifying the _recipient of depositApeCoin().

**Vulnerable code snippet:**

```solidity
function depositApeCoin(uint256 _amount, address _recipient) public { **//vulnerable point** _recipient
        if (_amount < MIN_DEPOSIT) revert DepositMoreThanOneAPE();
        updatePool(APECOIN_POOL_ID);

        Position storage position = addressPosition[_recipient]; **//vulnerable point**
        _deposit(APECOIN_POOL_ID, position, _amount);

        apeCoin.transferFrom(msg.sender, address(this), _amount);

        emit Deposit(msg.sender, _amount, _recipient);
    }
```

**Attack tx:**

[https://etherscan.io/tx/0xe3f0d14cfb6076cabdc9057001c3fafe28767a192e88005bc37bd7d385a1116a](https://etherscan.io/tx/0xe3f0d14cfb6076cabdc9057001c3fafe28767a192e88005bc37bd7d385a1116a)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1636650252844294144](https://twitter.com/BlockSecTeam/status/1636650252844294144)