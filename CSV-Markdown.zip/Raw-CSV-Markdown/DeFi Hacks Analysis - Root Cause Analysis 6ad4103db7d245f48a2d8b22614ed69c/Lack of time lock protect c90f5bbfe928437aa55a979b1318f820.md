# Lack of time lock protect

Type: Business Logic Flaw
Date: 20230523
Lost: 36K USD
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/LFI_exp.sol
Title: LFI Token

**Root cause:**

There is no time lock for the user 'staking' amount(balance).

**Vulnerable code snippet:**

```solidity

function claimRewards(address to) external {

        require(to != address(0), "HOUSEPOOL:to address can't be zero");

        cleanUserMapping();

        FarmInfo memory farm = updateFarm();

        UserInfo storage user = userInfo[msg.sender];

        int256 accumulatedReward = int256(   **//vulnerable point: no time lock check**

            (balance0f(msg.sender) * farm.accRewardsPerShare) /

                ACC_REWARD_PRECISION

        );

        uint256_pendingReward =uint256(accumulatedReward - user.rewardDebt

            pendingRewards [msg. sender];

        user. rewardDebt = accumulatedReward;

        pendingRewards [msg.sender] = 0;

        bool success = ILFIToken(STAKED_TOKEN).transfer(to, _pendingReward);

        if (success) [

            emit RewardsClaimed(msg.sender, to, _pendingReward);

        }else {

            revert();

        }

```

**Attack tx:**

[https://polygonscan.com/tx/0xa0480d0f7c8d8bf898cadde954e773ddc3740f1ffa31cdd98fe4c5f5d8266243](https://polygonscan.com/tx/0xa0480d0f7c8d8bf898cadde954e773ddc3740f1ffa31cdd98fe4c5f5d8266243)

**Analysis:**

[https://twitter.com/AnciliaInc/status/1660767088699666433](https://twitter.com/AnciliaInc/status/1660767088699666433)