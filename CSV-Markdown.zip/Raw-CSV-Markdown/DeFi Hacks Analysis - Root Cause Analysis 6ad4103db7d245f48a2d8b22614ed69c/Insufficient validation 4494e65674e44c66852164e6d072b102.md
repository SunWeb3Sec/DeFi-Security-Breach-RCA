# Insufficient validation

Type: Bridge, CrossChain, Insufficient validation
Date: 20220206
Lost: $4.3 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220206-meter---bridge
Title: Meter

Root cause:  insufficient validation

Vulnerable code snippet:

image from [peckshield](https://twitter.com/peckshield/status/1490121762847092736)

![截圖 2022-10-19 下午12.26.07.png](Insufficient%20validation%204494e65674e44c66852164e6d072b102/%25E6%2588%25AA%25E5%259C%2596_2022-10-19_%25E4%25B8%258B%25E5%258D%258812.26.07.png)