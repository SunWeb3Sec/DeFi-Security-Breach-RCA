# Incorrect airdrop calculation

Type: ERC20, Flashloans, claimTokens
Date: 20220517
Lost: $1.1 million
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220517-apecoin-ape---flashloan
Title: ApeCoin

Root cause: Incorrect airdrop calculation

Vulnerable code snippet:

[https://etherscan.io/address/0x025C6da5BD0e6A5dd1350fda9e3B6a614B205a1F#code#F1#L103](https://etherscan.io/address/0x025C6da5BD0e6A5dd1350fda9e3B6a614B205a1F#code#F1#L103)

function getClaimableTokenAmountAndGammaToClaim() to calculate the amount of ApeCoin to claim based on how many NFT the caller has and it doesn’t consider how long the caller owns those NFTs.

```solidity
function claimTokens() external whenNotPaused {
        require(block.timestamp >= claimStartTime && block.timestamp < claimStartTime + claimDuration, "Claimable period is finished");
        require((beta.balanceOf(msg.sender) > 0 || alpha.balanceOf(msg.sender) > 0), "Nothing to claim");

        uint256 tokensToClaim;
        uint256 gammaToBeClaim;

        (tokensToClaim, gammaToBeClaim) = getClaimableTokenAmountAndGammaToClaim(msg.sender); **//vulnerable point**, check reward

        for(uint256 i; i < alpha.balanceOf(msg.sender); ++i) {
            uint256 tokenId = alpha.tokenOfOwnerByIndex(msg.sender, i);
            if(!alphaClaimed[tokenId]) {
                alphaClaimed[tokenId] = true;
                emit AlphaClaimed(tokenId, msg.sender, block.timestamp);
            }
        }
function getClaimableTokenAmountAndGammaToClaim(address _account) private view returns (uint256, uint256)
    {
        uint256 unclaimedAlphaBalance;
        for(uint256 i; i < alpha.balanceOf(_account); ++i) {
            uint256 tokenId = alpha.tokenOfOwnerByIndex(_account, i);
            if(!alphaClaimed[tokenId]) {
                ++unclaimedAlphaBalance;
            }
```