# Insufficient validation

Type: Insufficient validation, Metaverse
Date: 20221020
Lost: 12BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221020-bego---incorrect-signature-verification
Title: BEGO

Root cause:  Insufficient validation

Vulnerable code snippet:

[https://www.bscscan.com/address/0xc342774492b54ce5f8ac662113ed702fc1b34972#code#L1232](https://www.bscscan.com/address/0xc342774492b54ce5f8ac662113ed702fc1b34972#code#L1232)

Attacker can input empty data into _r, _s and _v to bypass all checks to mint BEGO token.

```solidity
modifier isSigned(
        string memory _txHash,
        uint256 _amount,
        bytes32[] memory _r,
        bytes32[] memory _s,
        uint8[] memory _v
    ) {
        require(checkSignParams(_r, _s, _v), "bad-sign-params");
        bytes32 _hash = keccak256(abi.encodePacked(bsc, msg.sender, _txHash, _amount));
        address[] memory _signers = new address[](_r.length); **//vulnerable point**
        for (uint8 i = 0; i < _r.length; i++) {
            _signers[i] = ecrecover(_hash, _v[i], _r[i], _s[i]);
        }

        require(isSigners(_signers), "bad-signers");
        _;
    }

    function isSigners(address[] memory _signers) public view returns (bool){
        for (uint8 i = 0; i < _signers.length; i++) {  **//vulnerable point**
            if (!_containsSigner(_signers[i])) {
                return false;
            }
        }
        return true;  // null data will return true 
    }
function mint(
        uint256 _amount,
        string memory _txHash,
        address _receiver,
        bytes32[] memory _r,
        bytes32[] memory _s,
        uint8[] memory _v
    ) isSigned(_txHash, _amount, _r, _s, _v) external returns (bool){ **//trace** isSigned
        require(!txHashes[_txHash], "tx-hash-used");
        txHashes[_txHash] = true;

        _mint(_receiver, _amount);
        return true;
    }
```

![Untitled](Insufficient%20validation%200c6e595e09c3461687515c1b86715802/Untitled.png)