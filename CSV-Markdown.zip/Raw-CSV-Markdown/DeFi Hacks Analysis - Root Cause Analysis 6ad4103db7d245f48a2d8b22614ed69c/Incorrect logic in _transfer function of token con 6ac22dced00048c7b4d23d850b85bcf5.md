# Incorrect logic in _transfer  function of token contract

Type: DAO, Flashloans, skim
Date: 20220524
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220524-hackdao---skim-token-balance
Title: HackDao

Root cause: Incorrect logic in _transfer  function of token contract.

Vulnerable code snippet:

[https://bscscan.com/address/0x94e06c77b02ade8341489ab9a23451f68c13ec1c#code#L475](https://bscscan.com/address/0x94e06c77b02ade8341489ab9a23451f68c13ec1c#code#L475)

[https://bscscan.com/address/0x94e06c77b02ade8341489ab9a23451f68c13ec1c#code#L494](https://bscscan.com/address/0x94e06c77b02ade8341489ab9a23451f68c13ec1c#code#L494)

Cause Uniswap pair can be reduced without any swap, so attacker can do price manipulation. Once imbalance in the pair, attacker can call skim() to get profit.

```solidity
function _transfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal override virtual {
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");

        _beforeTokenTransfer(sender, recipient, amount);

        uint256 senderBalance = _balances[sender];

        require(senderBalance >= amount, "ERC20: transfer amount exceeds balance");
        unchecked {
            _balances[sender] = senderBalance - amount;
        }
        uint256 actualAmount = amount;

        if(parentAddress[recipient] == address(0) && recipient != uniswapV2Pair){
            if(sender == uniswapV2Pair){
                parentAddress[recipient] = _defaultAddress;
            }else{
                parentAddress[recipient] = sender;
            }
        }

        if(!isWhiteListed(sender) && !isWhiteListed(recipient)){
            
            uint256 fee = calculationFeeNum(amount,_feeRatio);
            //sell
            if(recipient == uniswapV2Pair){
                require(senderBalance >= amount.add(fee), "ERC20: There are not enough charges for the account balance");
                unchecked {
                    _balances[sender] -= fee;
                }
            }else{
                actualAmount = amount - fee;
            }
```