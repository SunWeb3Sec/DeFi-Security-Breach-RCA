# Public _transfer()

Type: Access Control
Date: 20230529
Lost: $2K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/NOON_exp.sol
Title: NOON (NO)

### Root cause:

Incorrect function visibility

### Vulnerable code snippet

[https://library.dedaub.com/decompile?md5=505e4227fb452bfde125eed91b9f861b](https://library.dedaub.com/decompile?md5=505e4227fb452bfde125eed91b9f861b)

The `_transfer` function has wrong visibility which does not follow standard ERC20 implentation.

```jsx
function _transfer(address varg0, address varg1, uint256 varg2) public payable {  **//vulnerable point**
    require(msg.data.length - 4 >= 96);
    require(varg1);
    require(varg2 <= _balanceOf[varg0]);
    require(_balanceOf[varg1] + varg2 > _balanceOf[varg1]);
    _balanceOf[varg0] = _balanceOf[varg0] - varg2;
    _balanceOf[varg1] += varg2;
    emit Transfer(varg0, varg1, varg2);
    assert(_balanceOf[varg1] + _balanceOf[varg0] == _balanceOf[varg0] + _balanceOf[varg1]);
}
```

### Attack tx:

[0x23fb7f093e827ed061 | Phalcon](https://explorer.phalcon.xyz/tx/eth/0x23fb7f093e827ed061aafb574cfd420eab879621c7f78cb341292e106a3a88c0)

### Analysis:

[https://twitter.com/hexagate_/status/1663501545105702912](https://twitter.com/hexagate_/status/1663501545105702912)