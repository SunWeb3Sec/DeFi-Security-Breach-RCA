# Incorrect profit calculation via balanceOf

Type: Flashloans, Miscalculation, Yield
Date: 20210519
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20210519-pancakebunny---price-oracle-manipulation
Title: PancakeBunny
fixed?: fixed

Root cause:  Incorrect profit calculation via balanceOf

Very similar PancakeHunny.

Vulnerable code snippet: 

[https://www.bscscan.com/address/0xed1443def66e4e8901377467d449499eaba1559a#code#F1#L235](https://www.bscscan.com/address/0xed1443def66e4e8901377467d449499eaba1559a#code#F1#L235)

[https://bscscan.com/address/0x819eea71d3f93bb604816f1797d4828c90219b5d#code#F1#L204](https://bscscan.com/address/0x819eea71d3f93bb604816f1797d4828c90219b5d#code#F1#L204)

```solidity
// @dev profits only (underlying + bunny) + no withdraw fee + perf fee
    function getReward() external override {
        uint amount = earned(msg.sender);
        uint shares = Math.min(amount.mul(totalShares).div(balance()), _shares[msg.sender]);
        totalShares = totalShares.sub(shares);
        _shares[msg.sender] = _shares[msg.sender].sub(shares);
        _cleanupIfDustShares();

        amount = _withdrawTokenWithCorrection(amount);
        uint depositTimestamp = _depositedAt[msg.sender];
        uint performanceFee = canMint() ? _minter.performanceFee(amount) : 0;
        if (performanceFee > DUST) {
            _minter.mintForV2(address(_stakingToken), 0, performanceFee, msg.sender, depositTimestamp);//check mintForV2
            amount = amount.sub(performanceFee);
        }

        _stakingToken.safeTransfer(msg.sender, amount);
        emit ProfitPaid(msg.sender, amount, performanceFee);
    }
```

```solidity
function mintForV2(address asset, uint _withdrawalFee, uint _performanceFee, address to, uint) external payable override onlyMinter {
        uint feeSum = _performanceFee.add(_withdrawalFee);
        _transferAsset(asset, feeSum);

        if (asset == BUNNY) {
            IBEP20(BUNNY).safeTransfer(DEAD, feeSum);
            return;
        }

        uint bunnyBNBAmount = _zapAssetsToBunnyBNB(asset, feeSum, true);
        if (bunnyBNBAmount == 0) return;

        IBEP20(BUNNY_BNB).safeTransfer(BUNNY_POOL, bunnyBNBAmount);
        IStakingRewards(BUNNY_POOL).notifyRewardAmount(bunnyBNBAmount);

        (uint valueInBNB,) = priceCalculator.valueOfAsset(BUNNY_BNB, bunnyBNBAmount);// check valueOfAsset
        uint contribution = valueInBNB.mul(_performanceFee).div(feeSum);
...
function valueOfAsset(address asset, uint amount) public view override returns (uint valueInBNB, uint valueInUSD) {
        if (asset == address(0) || asset == WBNB) {
            valueInBNB = amount;
            valueInUSD = amount.mul(priceOfBNB()).div(1e18);
        }
        else if (keccak256(abi.encodePacked(IPancakePair(asset).symbol())) == keccak256("Cake-LP")) {
            if (IPancakePair(asset).totalSupply() == 0) return (0, 0);

            if (IPancakePair(asset).token0() == WBNB || IPancakePair(asset).token1() == WBNB) {
                valueInBNB = amount.mul(IBEP20(WBNB).balanceOf(address(asset))).mul(2).div(IPancakePair(asset).totalSupply()); **//vulnerable point,** incorrect calculation
                valueInUSD = valueInBNB.mul(priceOfBNB()).div(1e18);
```