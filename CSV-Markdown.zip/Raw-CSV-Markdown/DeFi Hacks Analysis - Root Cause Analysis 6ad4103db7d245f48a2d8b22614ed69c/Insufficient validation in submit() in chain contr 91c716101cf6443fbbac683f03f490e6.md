# Insufficient validation in submit() in chain contract.

Type: MaliciosProposal, lending
Date: 20220508
Lost: $3 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220508-fortress-loans---malicious-proposal--price-oracle-manipulation
Title: Fortress Loans

Root cause: Insufficient validation in submit() in chain contract.

Vulnerable code snippet:

[https://bscscan.com/address/0xc11b687cd6061a6516e23769e4657b6efa25d78e#code#F1#L142](https://bscscan.com/address/0xc11b687cd6061a6516e23769e4657b6efa25d78e#code#F1#L142)

L142 was commented out. There is no verification to ensure the function call is triggered properly. Anyone can call submit function to manipulate price oracle.

```solidity
function submit(
    uint32 _dataTimestamp,
    bytes32 _root,
    bytes32[] memory _keys,
    uint256[] memory _values,
    uint8[] memory _v,
    bytes32[] memory _r,
    bytes32[] memory _s
  ) public {
...
...
require(i >= requiredSignatures, "not enough signatures");
    // we turn on power once we have proper DPoS
    // require(power * 100 / staked >= 66, "not enough power was gathered");
```