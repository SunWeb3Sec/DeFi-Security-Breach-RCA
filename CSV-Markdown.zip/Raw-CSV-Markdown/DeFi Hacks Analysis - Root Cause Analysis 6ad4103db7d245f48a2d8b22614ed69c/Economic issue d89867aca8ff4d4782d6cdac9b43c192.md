# Economic issue

Type: Dex/AMM, Economic
Date: 20221011
Lost: $47 M
Title: Mango

Root cause: Economic issue 

The vulnerability stemmed from the thin liquidity on the exchange market between MNGO and the USDC stablecoin, which was used as the price reference for a MNGO perpetual swap.

![Untitled](Economic%20issue%20d89867aca8ff4d4782d6cdac9b43c192/Untitled.png)

---

![Untitled](Economic%20issue%20d89867aca8ff4d4782d6cdac9b43c192/Untitled%201.png)

![Untitled](Economic%20issue%20d89867aca8ff4d4782d6cdac9b43c192/Untitled%202.png)

![Untitled](Economic%20issue%20d89867aca8ff4d4782d6cdac9b43c192/Untitled%203.png)