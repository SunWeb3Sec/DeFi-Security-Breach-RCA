# FlashLoan Price Manipulation

Type: Sandwich
Date: 20230512
Lost: $50k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/LW_exp.sol
Title: LW

**Root cause:**

KALOS: LW was hacked on May 11, 2023. This vulnerability is under the category of Rugpull cases, which, unlike other instances, were exploited by owners. A total of 6 accounts had funds forcefully drained.

**Vulnerable code snippet:**

```solidity
receive() external payable {
        if(thanPrice==0) return;
        if(IERC20(_token).balanceOf(_marketAddr ) >=3000e18 ){
            IERC20(_token).transferFrom(_marketAddr,address(this),3000e18);
            swapTokensForDead(3000e18); **//vulnerable point**
            thanPrice-=1;
        }
    }
```

**Attack tx:**

[https://bscscan.com/tx/0xb846f3aeb9b3027fe138b23bbf41901c155bd6d4b24f08d6b83bd37a975e4e4a](https://bscscan.com/tx/0xb846f3aeb9b3027fe138b23bbf41901c155bd6d4b24f08d6b83bd37a975e4e4a)

[https://bscscan.com/tx/0x96b34dc3a98cd4055a984132d7f3f4cc5a16b2525113b8ef83c55ac0ba2b3713](https://bscscan.com/tx/0x96b34dc3a98cd4055a984132d7f3f4cc5a16b2525113b8ef83c55ac0ba2b3713)

**Analysis:**

[https://twitter.com/PeckShieldAlert/status/1656850634312925184](https://twitter.com/PeckShieldAlert/status/1656850634312925184)

[https://twitter.com/hexagate_/status/1657051084131639296](https://twitter.com/hexagate_/status/1657051084131639296)

[https://twitter.com/kalos_security/status/1668092799512907777](https://twitter.com/kalos_security/status/1668092799512907777)