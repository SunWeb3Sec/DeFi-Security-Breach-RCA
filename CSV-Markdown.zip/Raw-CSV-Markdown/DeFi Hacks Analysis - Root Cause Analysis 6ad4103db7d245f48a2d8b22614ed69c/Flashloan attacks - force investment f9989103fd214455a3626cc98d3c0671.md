# Flashloan attacks - force investment

Type: Flashloans
Date: 20221202
Lost: $170k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Overnight_exp.sol
Title: OverNight

**Root cause:** 

Flashloan - force investment

**Vulnerable code snippet:**

[https://snowtrace.io/address/0xed2a7edd7413021d440b09d654f3b87712abab66#code#F24#L731](https://snowtrace.io/address/0xed2a7edd7413021d440b09d654f3b87712abab66#code#F24#L731)

![Untitled](Flashloan%20attacks%20-%20force%20investment%20f9989103fd214455a3626cc98d3c0671/Untitled.png)

image:peckshield

**Attack tx:**

[https://explorer.phalcon.xyz/tx/avax/0xf10807f9a675dd2db9a45e39f37c68a4116006f9a40e97a68c145e3859557809](https://explorer.phalcon.xyz/tx/avax/0xf10807f9a675dd2db9a45e39f37c68a4116006f9a40e97a68c145e3859557809)

**Analysis:**

[https://twitter.com/peckshield/status/1598704809690877952](https://twitter.com/peckshield/status/1598704809690877952)

[https://twitter.com/overnight_fi/status/1572614168976691200](https://twitter.com/overnight_fi/status/1572614168976691200)

[https://medium.com/coinmonks/psa-in-crypto-transparency-doesnt-necessarily-equal-safety-86b23ae9f471](https://medium.com/coinmonks/psa-in-crypto-transparency-doesnt-necessarily-equal-safety-86b23ae9f471)