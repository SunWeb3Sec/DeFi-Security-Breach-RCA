# Incorrect validation and External calls can fail deliberately.

Type: DoS, ERC721
Date: 20220423
Lost: $34 M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20220423-akutar-nft---denial-of-service
Title: Akutar NFT

Root cause: Incorrect validation and External calls can fail deliberately.

Vulnerable code snippet:

(1)DOS

[https://etherscan.io/address/0xf42c318dbfbaab0eee040279c6a2588fa01a961d#code#L585](https://etherscan.io/address/0xf42c318dbfbaab0eee040279c6a2588fa01a961d#code#L585)

Bidder can be a malicious contract to cause DOS.

```solidity
function processRefunds() external {
      require(block.timestamp > expiresAt, "Auction still in progress");
      uint256 _refundProgress = refundProgress;
      uint256 _bidIndex = bidIndex;
      require(_refundProgress < _bidIndex, "Refunds already processed");
      
      uint256 gasUsed;
      uint256 gasLeft = gasleft();
      uint256 price = getPrice();
      
      for (uint256 i=_refundProgress; gasUsed < 5000000 && i < _bidIndex; i++) {
          bids memory bidData = allBids[i];
          if (bidData.finalProcess == 0) {
            uint256 refund = (bidData.price - price) * bidData.bidsPlaced;
            uint256 passes = mintPassOwner[bidData.bidder];
            if (passes > 0) {
                refund += mintPassDiscount * (bidData.bidsPlaced < passes ? bidData.bidsPlaced : passes);
            }
            allBids[i].finalProcess = 1;
            if (refund > 0) {
                (bool sent, ) = bidData.bidder.call{value: refund}(""); // low-lecel call
                require(sent, "Failed to refund bidder");
```

How to fix, follow favor pull over push for external calls.

[https://consensys.github.io/smart-contract-best-practices/development-recommendations/general/external-calls/#favor-pull-over-push-for-external-calls](https://consensys.github.io/smart-contract-best-practices/development-recommendations/general/external-calls/#favor-pull-over-push-for-external-calls)

(2)Fund lock

[https://etherscan.io/address/0xf42c318dbfbaab0eee040279c6a2588fa01a961d#code#L618](https://etherscan.io/address/0xf42c318dbfbaab0eee040279c6a2588fa01a961d#code#L618)

It should compare with `_bidIndex` instead of `totalBids`. Due to this issue, the requirement will never be satisfied, and the Ether in the contract can be locked for ever

```solidity
function claimProjectFunds() external onlyOwner {
        require(block.timestamp > expiresAt, "Auction still in progress");
        require(refundProgress >= totalBids, "Refunds not yet processed"); // wrong **//vulnerable point**
        require(akuNFTs.airdropProgress() >= totalBids, "Airdrop not complete");

        (bool sent, ) = project.call{value: address(this).balance}("");
        require(sent, "Failed to withdraw");        
    }
```