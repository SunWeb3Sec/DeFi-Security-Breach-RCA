# Incorrect access control

Type: Arbitrary call, Yield
Date: 20221010
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221010-carrot---public-functioncall
Title: Carrot

Root cause: public function call, call transferowner 0xbf699b4b. All wallets granted approvals are impacted.

Step1, transReward to set owner.

Step2, transferFrom. 

Vulnerable code snippet:

[https://bscscan.com/address/0xcFF086EaD392CcB39C49eCda8C974ad5238452aC#code#L1406](https://bscscan.com/address/0xcFF086EaD392CcB39C49eCda8C974ad5238452aC#code#L1406)

```solidity
function transReward(bytes memory data) public { //data is controllable
        pool.functionCall(data); **//vulnerable point**
    }
```

Pool contract: 0x6863b549bf730863157318df4496ed111adfa64f

![changeowner.png](Incorrect%20access%20control%206a8464281c2c47cf871ef77cc9c01f88/changeowner.png)

---

![POC.png](Incorrect%20access%20control%206a8464281c2c47cf871ef77cc9c01f88/POC.png)

REF: [https://twitter.com/1nf0s3cpt/status/1580116116151889920](https://twitter.com/1nf0s3cpt/status/1580116116151889920)