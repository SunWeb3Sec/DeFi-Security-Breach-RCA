# Price Manipulation with Pre-Approval BUSD

Type: Flashloans, Price Manipulation
Date: 20221026
Lost: $200k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/ULME.sol
Title: ULME

**Root cause:**

**`buyMiner`** function in the contract UniverseGoldMountain (ULME) is public and could potentially enable price manipulation, it appears that the attacker is exploiting this vulnerability to their advantage. By leveraging the flashloan, the attacker can potentially manipulate the price of ULME tokens and benefit from the price changes in the process.

**Vulnerable code snippet:**

```solidity
function buyMiner(address user,uint256 usdt)public returns (bool){
        address[]memory token=new address[](2);
        token[0]=_usdt_token;
        token[1]=address(this);
        usdt=usdt.add(usdt.div(10));
        require(IERC20(_usdt_token).transferFrom(user,address(this),usdt), "buyUlm: transferFrom to ulm error");
        uint256 time=sale_date;
        sale_date=0;
        address k=0x25812c28CBC971F7079879a62AaCBC93936784A2;
        IUniswapV2Router01(_roter).swapExactTokensForTokens(usdt,1000000,token,k,block.timestamp+60);
        IUniswapV2Router01(k).transfer(address(this),address(this),IERC20(address(this)).balanceOf(k));
        sale_date=time;
        return true;
    }
```

**Attack tx:**

[https://bscscan.com/tx/0xdb9a13bc970b97824e082782e838bdff0b76b30d268f1d66aac507f1d43ff4ed](https://bscscan.com/tx/0xdb9a13bc970b97824e082782e838bdff0b76b30d268f1d66aac507f1d43ff4ed)

**Analysis:**

1. Utilize a Flashloan to borrow BUSD from the lending platform.
2. Execute a swap of the borrowed BUSD for ULME tokens via PancakeSwap.
3. Utilize pre-approved users who possess BUSD tokens to trigger the **`buyMiner`** function of the ULME token.
4. Employ indirect price manipulation to exchange ULME tokens back for BUSD. And this behavior will increase the ULME token again.
5. Repay the Flashloan and secure a profit of 50,646 BUSD as the profit.

[https://twitter.com/BlockSecTeam/status/1584839309781135361](https://twitter.com/BlockSecTeam/status/1584839309781135361) 

[https://twitter.com/BeosinAlert/status/1584888021299916801](https://twitter.com/BeosinAlert/status/1584888021299916801)