# Arbitrary call via functionCallWithValue

Type: Arbitrary call, swap
Date: 20221011
Lost: $200,000
POC: https://github.com/SunWeb3Sec/DeFiHackLabs#20221011-rabby-wallet-swaprouter---arbitrary-external-call-vulnerability
Title: Rabby wallet

Root cause: arbitrary external call vulnerability.

Since data is controllable by an attacker, so he can perform arbitrary external calls via functionCallWithValue. In this incident, the attacker sends funds out over transferfrom function.

![截圖 2022-10-26 下午3.54.03.png](Arbitrary%20call%20via%20functionCallWithValue%20724e5c7c2a9c40929cfb7bfe116eec54/%25E6%2588%25AA%25E5%259C%2596_2022-10-26_%25E4%25B8%258B%25E5%258D%25883.54.03.png)

Source code: [https://github.com/RabbyHub/Rabby/blob/1860bdd69da09292171457cb08bfd4a0bf89617d/docs/PeckShield-Audit-Report-RabbyRouter-v1.0.pdf](https://github.com/RabbyHub/Rabby/blob/1860bdd69da09292171457cb08bfd4a0bf89617d/docs/PeckShield-Audit-Report-RabbyRouter-v1.0.pdf)

Check:

[https://twitter.com/1nf0s3cpt/status/1579844213562576897](https://twitter.com/1nf0s3cpt/status/1579844213562576897)