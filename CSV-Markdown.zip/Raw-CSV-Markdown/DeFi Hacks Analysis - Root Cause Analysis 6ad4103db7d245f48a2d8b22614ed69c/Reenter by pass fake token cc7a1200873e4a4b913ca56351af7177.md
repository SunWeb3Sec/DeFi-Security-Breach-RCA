# Reenter by pass fake token

Type: Insufficient validation, Reentrancy
Date: 20221229
Lost: 15.32 ETH
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/JAY_exp.sol
Title: JAY

**Root cause:** 

Reentrancy.

The attacker exploits this vulnerability to reenter the JAY contract. Specifically, the attacker first borrows 72.5 ETH for flash loan and uses 22 ETH to buy JAY token. Then he uses another 50.5 ETH to call the buyJay function, passing the fake ERC-721 token.

In the transferFrom function of the fake ERC-721 token, the attacker reenters the JAY contract by calling the sell function, selling all the JAY token. As the Ether balance has been increased at the start of the buyJay function, the JAY token price is manipulated.

The attacker repeated the procedure twice in a single transaction, with a total profit of 15.32 Ether.

**Vulnerable code snippet:**

```solidity
function buyJay(
        address[] calldata erc721TokenAddress,
        uint256[] calldata erc721Ids,
        address[] calldata erc1155TokenAddress,
        uint256[] calldata erc1155Ids,
        uint256[] calldata erc1155Amounts
    ) public payable {
        require(start, "Not started!");
        uint256 total = erc721TokenAddress.length;
        if (total != 0) buyJayWithERC721(erc721TokenAddress, erc721Ids);

        if (erc1155TokenAddress.length != 0)
            total = total.add(
                buyJayWithERC1155(
                    erc1155TokenAddress,
                    erc1155Ids,
                    erc1155Amounts
                )
            );

        if (total >= 100)
            require(
                msg.value >= (total).mul(sellNftFeeEth).div(2),
                "You need to pay ETH more"
            );
        else
            require(
                msg.value >= (total).mul(sellNftFeeEth),
                "You need to pay ETH more"
            );

        _mint(msg.sender, ETHtoJAY(msg.value).mul(97).div(100));

        (bool success, ) = dev.call{value: msg.value.div(34)}("");
        require(success, "ETH Transfer failed.");

        nftsSold += total;

        emit Price(block.timestamp, JAYtoETH(1 * 10**18));
    }

function JAYtoETH(uint256 value) public view returns (uint256) {
        return (value * address(this).balance).div(totalSupply());
    }

```

**Attack tx:** 

[https://etherscan.io/tx/0xd4fafa1261f6e4f9c8543228a67caf9d02811e4ad3058a2714323964a8db61f6](https://etherscan.io/tx/0xd4fafa1261f6e4f9c8543228a67caf9d02811e4ad3058a2714323964a8db61f6)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1608372475225866240](https://twitter.com/BlockSecTeam/status/1608372475225866240)