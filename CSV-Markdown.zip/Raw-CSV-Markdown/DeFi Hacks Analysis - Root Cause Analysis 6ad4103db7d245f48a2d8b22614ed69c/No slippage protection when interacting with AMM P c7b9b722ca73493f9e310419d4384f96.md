# No slippage protection when interacting with AMM Pair

Type: Sandwich
Date: 20230503
Lost: $74K
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/NeverFall_exp.sol
Title: NeverFall

**Root cause:**

KALOS: The root cause lies in the logic that evaluates the price of the token, which is based on the Pair from PancakeSwap. If you examine the sell() function of the NeverFall contract, you can easily identify the cause.

**Vulnerable code snippet:**

```solidity
function buy(uint256 amountU) public returns(uint256){
        require(startBuy,"not start");
        //收usdt
        IERC20(usdtAddress).safeTransferFrom(msg.sender,address(this),amountU);

        uint256 beforeLiquidityAmount = balanceOf(address(this));
        //90%加池子
        IERC20(usdtAddress).approve(uniswapV2Router,amountU);
        addLiquidity(initSupply, amountU * buyAddLiqFee / 100);
        uint256 afterLiquidityAmount = balanceOf(address(this));
        //5%的usdt购买
        buySwap(amountU * buySwapFee / 100);
        super._transfer(address(this), msg.sender, beforeLiquidityAmount - afterLiquidityAmount - balanceOf(pairTempAddress)); 
        super._transfer(pairTempAddress, address(this), balanceOf(pairTempAddress));
        //营销
        IERC20(usdtAddress).safeTransfer(marketingAddress,amountU * buyMarketingFee / 100);
        emit BuyNF(msg.sender,amountU);
        return beforeLiquidityAmount - afterLiquidityAmount - balanceOf(pairTempAddress);
    } 

    function sell(uint256 amount) public returns(uint256){
        super._transfer(msg.sender, address(this), amount);
        //撤池子 退给用户U
        uint256 balanceNF = this.balanceOf(uniswapV2Pair);
        uint256 pairTotalSupply = IERC20(uniswapV2Pair).totalSupply();
        uint256 needLiquidity = amount * pairTotalSupply / balanceNF; **//vulnerable point**
        
        uint256 beforeU = IERC20(usdtAddress).balanceOf(address(this));
        removeLiquidity(needLiquidity,amount * 90 / 100,0);
        uint256 afterU = IERC20(usdtAddress).balanceOf(address(this));
        uint256 outU =  afterU - beforeU;

        IERC20(usdtAddress).safeTransfer(msg.sender, outU * sellFee / 100);
         //营销
        IERC20(usdtAddress).safeTransfer(marketingAddress,outU * sellMarketingFee / 100);
        emit SellNF(msg.sender,amount,outU);
        return outU * sellFee / 100;  
    }
```

**Attack tx:**

[https://bscscan.com/address/0x5ABDe8B434133C98c36F4B21476791D95D888bF5#contracts](https://bscscan.com/address/0x5ABDe8B434133C98c36F4B21476791D95D888bF5#contracts)

**Analysis:**

[https://twitter.com/BeosinAlert/status/1653619782317662211](https://twitter.com/BeosinAlert/status/1653619782317662211)

[https://twitter.com/kalos_security/status/1668092312906514433](https://twitter.com/kalos_security/status/1668092312906514433)