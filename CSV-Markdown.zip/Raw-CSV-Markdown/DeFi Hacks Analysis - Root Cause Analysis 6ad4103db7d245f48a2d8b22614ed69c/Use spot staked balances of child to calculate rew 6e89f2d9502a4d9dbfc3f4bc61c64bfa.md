# Use spot staked balances of child to calculate rewards

Type: Flashloans, Reward
Date: 20230510
Lost: $197k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/SNK_exp.sol
Title: SNK

**Root cause:**

Phalcon: The attacker exploits the `bindParent` function in contract SNKMiner to amplify his staking rewards. Specifically, this function binds one account as a staking account's child.

SNKMiner depends on SNK balance of staking accounts' children to calculate the amount of reward(SNK) distributing to staking accounts. As a result, the attacker leverages flashloan to increase the SNK balance of children, which can further lift their parents' staking rewards.

KALOS: The vulnerability lies in the bindParent() and getReward() functions. The bindParent() function allows setting the parent and child nodes, while the dynamicEarned() function within the getReward() function calculates rewards based on the balances of those child nodes. As a result, it is possible to receive a much larger amount of rewards than what should actually be obtained.

**Vulnerable code snippet:**

```solidity
function getReward() public updateReward(msg.sender) checkStart {
        uint256 reward = dynamicEarned(msg.sender) + privateEarned(msg.sender); **//vulnerable point**
        if (reward > 0) {
            prewards[msg.sender] = 0;
            drewards[msg.sender] = 0;

            token.safeTransfer(msg.sender, reward);

            totalRewards = totalRewards.add(reward);
        }
  }

function privateEarned(address account) public view returns (uint256) {
        if (block.timestamp < starttime) {
            return 0;
        }

        return
            balanceOf(account)
                .mul(rewardPerToken().sub(userRewardPerTokenPaid[account]))
                .mul(35)
                .div(precision)
                .div(100)
                .add(prewards[account]);
 }

function dynamicEarned(address account) public view returns (uint256) {
        if (block.timestamp < starttime) {
            return 0;
        }

        if (balanceOf(account) < 10e18) {
            return 0;
        }
        
        return
            _getMyChildersBalanceOf(account)
                .mul(rewardPerToken().sub(userRewardPerTokenPaid[account]))
                .mul(45)
                .div(precision)
                .div(100)
                .add(drewards[account]);
 }

function _getMyChildersBalanceOf(address user) private view returns (uint256) {
        address[] memory childers = inv.getInviterSuns(user);

        uint256 totalBalances;
        for (uint256 index = 0; index < childers.length; index++) {
            totalBalances += balanceOf(childers[index]); **//vulnerable point**
        }

        return totalBalances;
 }
```

**Attack tx:**

[https://bscscan.com/address/0xA3f5ea945c4970f48E322f1e70F4CC08e70039ee#code](https://bscscan.com/address/0xA3f5ea945c4970f48E322f1e70F4CC08e70039ee#code)

**Analysis:**

[https://twitter.com/Phalcon_xyz/status/1656176776425644032](https://twitter.com/Phalcon_xyz/status/1656176776425644032)

[https://twitter.com/kalos_security/status/1668092691262091265](https://twitter.com/kalos_security/status/1668092691262091265)