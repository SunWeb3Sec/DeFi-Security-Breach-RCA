# Predicting Random Numbers (RFB) - Bad randomness

Type: Bad randomness
Date: 20221205
Lost: 12 BNB
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/RFB_exp.sol
Title: RFB

**Root cause:** 

Bad randomness

The attacker exploits this vulnerability by purchasing RFB tokens only when they are confident of winning. If their attempt fails, the function reverts, resulting in the attacker losing only the gas cost for the transaction. This strategy allows the attacker to optimize their attempts and minimize potential losses, making the system susceptible to manipulation.

**Vulnerable code snippet:**

[https://bscscan.com/address/0x26f1457f067bF26881F311833391b52cA871a4b5#code#L419](https://bscscan.com/address/0x26f1457f067bF26881F311833391b52cA871a4b5#code#L419)

```jsx
function randMod(address buyer,uint256 buyamount) internal  returns(uint){

        uint randnum = uint(keccak256(abi.encodePacked(block.number,block.timestamp,buyer,_balances[pair]))); //vulnerable point
        uint256 buyBNBamount = buyamount.div(10**_decimals).mul(getPrice());
        // increase nonce
        if(randnum%(10000*luckyMultiplier) == 8888 && buyBNBamount > (0.1 ether)){
            distributor.withdrawDistributor(buyer, 79);
            distributor.withdrawDistributor(marketingFeeReceiver,9);
        }else if(randnum%(1000*luckyMultiplier) == 888){
            if(buyBNBamount.mul(100) > 10 ether){
                buyBNBamount = 0.1 ether;
            }
            try distributor.withdrawPlazz(buyer, buyBNBamount.mul(100).mul(90).div(100)){}catch {}
            try distributor.withdrawPlazz(marketingFeeReceiver, buyBNBamount.mul(100).mul(10).div(100)){}catch {}
        }else if(randnum%(100*luckyMultiplier) == 88){
            if(buyBNBamount.mul(10) > 10 ether){
                buyBNBamount = 1 ether;
            }
            try distributor.withdrawPlazz(buyer, buyBNBamount.mul(10).mul(90).div(100)){}catch {}
            try distributor.withdrawPlazz(marketingFeeReceiver, buyBNBamount.mul(10).mul(10).div(100)){}catch {}
        }else if(randnum%(10*luckyMultiplier) == 8){
            if(buyBNBamount > 10 ether){
                buyBNBamount = 10 ether;
            }
            try distributor.withdrawPlazz(buyer, buyBNBamount.mul(90).div(100)){}catch {}
            try distributor.withdrawPlazz(marketingFeeReceiver, buyBNBamount.mul(10).div(100)){}catch {}
        }
        return randnum;
    }
```

**Attack tx:**

[https://explorer.phalcon.xyz/tx/bsc/0xcc8fdb3c6af8bb9dfd87e913b743a13bbf138a143c27e0f387037887d28e3c7a](https://explorer.phalcon.xyz/tx/bsc/0xcc8fdb3c6af8bb9dfd87e913b743a13bbf138a143c27e0f387037887d28e3c7a)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1599991294947778560](https://twitter.com/BlockSecTeam/status/1599991294947778560)

[https://blog.solidityscan.com/roast-football-hack-analysis-e9316170c443](https://blog.solidityscan.com/roast-football-hack-analysis-e9316170c443)

[https://neptunemutual.com/blog/roast-football-lost-funds-through-exploited-reward-system/](https://neptunemutual.com/blog/roast-football-lost-funds-through-exploited-reward-system/)