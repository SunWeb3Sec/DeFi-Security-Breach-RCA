# Logic flaw in the withdraw function

Type: Business Logic Flaw, Flashloans, Price Manipulation
Date: 20230402
Lost: $550k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Allbridge_exp.sol
Title: Allbridge

**Root cause:**

QuillAudits: The root cause of the issue was a logic flaw in the withdraw function. This flaw allowed for manipulation of the swap price of the pool. The exploiter acted as a liquidity provider and swapper, enabling them to manipulate the price and drain the funds from the pool.

**Vulnerable code snippet:**

```jsx
// Subtract X and Y for that amount, calculate current price and withdraw the token to the user according to the price
    function withdraw(uint256 amountLp) external {
        uint256 totalLpAmount_ = totalLpAmount; // Gas optimization

        _withdrawLp(msg.sender, amountLp);

        // Calculate actual and virtual tokens using burned LP amount share
        // Swap the difference, get total amount to transfer/burn
        uint256 amountSP = _preWithdrawSwap(
            tokenBalance * amountLp / totalLpAmount_, 
            vUsdBalance * amountLp / totalLpAmount_
        );

        // Always equal amounts removed from actual and virtual tokens
        tokenBalance -= amountSP;
        vUsdBalance -= amountSP;
        
        // Update D and transfer tokens to the sender
        _updateD();
        token.safeTransfer(msg.sender, fromSystemPrecision(amountSP));
    }
```

**Attack tx:**

[https://bscscan.com/tx/0x7ff1364c3b3b296b411965339ed956da5d17058f3164425ce800d64f1aef8210](https://bscscan.com/tx/0x7ff1364c3b3b296b411965339ed956da5d17058f3164425ce800d64f1aef8210)

**Analysis:**

[https://twitter.com/peckshield/status/1642356701100916736](https://twitter.com/peckshield/status/1642356701100916736)

[https://twitter.com/BeosinAlert/status/1642372700726505473](https://twitter.com/BeosinAlert/status/1642372700726505473)

[https://medium.com/coinmonks/decoding-allbridge-570k-flash-loan-exploit-quillaudits-8da8dccd729d](https://medium.com/coinmonks/decoding-allbridge-570k-flash-loan-exploit-quillaudits-8da8dccd729d)