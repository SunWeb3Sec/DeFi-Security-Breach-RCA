# Staking reward is based on spot price

Type: Flashloans, Price Manipulation, claimTokens
Date: 20221214
Lost: $76k
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Nmbplatform_exp.sol
Title: Nmbplatform

**Root cause:** 

Staking reward is based on spot price.

The price feed of NIMB and GNIMB (the reward token) will be needed when calculating the staking reward. However, the price of NIMB is calculated based on the manipulated NIMB - NBU_WBNB pair.

**Vulnerable code snippet:**

```solidity
function getReward() public override nonReentrant whenNotPaused {
        uint256 reward = earned(msg.sender);
        if (reward > 0) {
            for (uint256 i = 0; i < stakeNonces[msg.sender]; i++) {
                stakeNonceInfos[msg.sender][i].stakeTime = block.timestamp;
            }
        rewardsPaymentToken.safeTransfer(msg.sender, reward);
        emit RewardPaid(msg.sender, address(rewardsPaymentToken), reward);

        }
    }
function earnedByNonce(address account, uint256 nonce) public view returns (uint256) {
        uint256 amount = stakeNonceInfos[account][nonce].rewardsTokenAmount * 
            (block.timestamp - stakeNonceInfos[account][nonce].stakeTime) *
             stakeNonceInfos[account][nonce].rewardRate / (100 * rewardDuration);
        return getTokenAmountForToken(address(rewardsToken), address(rewardsPaymentToken), amount);
    }
function getTokenAmountForToken(address tokenSrc, address tokenDest, uint tokenAmount) public view returns (uint) { 
        if (tokenSrc == tokenDest) return tokenAmount;
        if (usePriceFeeds && address(priceFeed) != address(0)) {
            (uint256 rate, uint256 precision) = priceFeed.queryRate(tokenSrc, tokenDest);
            return tokenAmount * rate / precision;
        } 
        address[] memory path = new address[](2);
        path[0] = tokenSrc;
        path[1] = tokenDest;
        return swapRouter.getAmountsOut(tokenAmount, path)[1];
    }
```

**Attack tx:** 

[https://bscscan.com/tx/0x7d2d8d2cda2d81529e0e0af90c4bfb39b6e74fa363c60b031d719dd9d153b012](https://bscscan.com/tx/0x7d2d8d2cda2d81529e0e0af90c4bfb39b6e74fa363c60b031d719dd9d153b012)
[https://bscscan.com/tx/0x42f56d3e86fb47e1edffa59222b33b73e7407d4b5bb05e23b83cb1771790f6c1](https://bscscan.com/tx/0x42f56d3e86fb47e1edffa59222b33b73e7407d4b5bb05e23b83cb1771790f6c1)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1602881707958407168](https://twitter.com/BlockSecTeam/status/1602881707958407168)

[https://twitter.com/BlockSecTeam/status/1602881707958407168](https://twitter.com/BlockSecTeam/status/1602881707958407168)