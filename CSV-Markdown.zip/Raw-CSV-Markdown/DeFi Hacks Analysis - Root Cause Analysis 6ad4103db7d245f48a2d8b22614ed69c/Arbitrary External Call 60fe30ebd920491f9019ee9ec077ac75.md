# Arbitrary External Call

Type: Arbitrary call, Dex/AMM
Date: 20221225
Lost: $1.5M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Rubic_exp.sol
Title: Rubic

**Root cause:**  

Arbitrary External Call

The attacker abused that USDC had been added as a router (by the admin), leading to an arbitrary function call with USDC contract. Then the attacker invoked transferFrom to steal the victim's USDC.

**Vulnerable code snippet:**

```solidity
function routerCallNative(BaseCrossChainParams calldata _params, bytes calldata _data)
        external
        payable
        nonReentrant
        whenNotPaused
        eventEmitter(_params)
    {
        if (!availableRouters.contains(_params.router)) {
            revert RouterNotAvailable();
        }

        IntegratorFeeInfo memory _info = integratorToFeeInfo[_params.integrator];

        uint256 _amountIn = accrueTokenFees(
            _params.integrator,
            _info,
            accrueFixedCryptoFee(_params.integrator, _info),
            0,
            address(0)
        );

        AddressUpgradeable.functionCallWithValue(_params.router, _data, _amountIn);
    }

```

**Attack tx:** 

[https://explorer.phalcon.xyz/tx/eth/0x9a97d85642f956ad7a6b852cf7bed6f9669e2c2815f3279855acf7f1328e7d46](https://explorer.phalcon.xyz/tx/eth/0x9a97d85642f956ad7a6b852cf7bed6f9669e2c2815f3279855acf7f1328e7d46)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1606993118901198849](https://twitter.com/BlockSecTeam/status/1606993118901198849)

[https://twitter.com/peckshield/status/1606937055761952770](https://twitter.com/peckshield/status/1606937055761952770)