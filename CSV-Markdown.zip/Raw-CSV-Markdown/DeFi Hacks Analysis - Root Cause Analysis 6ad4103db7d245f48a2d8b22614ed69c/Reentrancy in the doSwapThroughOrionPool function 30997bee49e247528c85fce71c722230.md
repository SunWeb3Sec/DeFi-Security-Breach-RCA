# Reentrancy in the doSwapThroughOrionPool function

Type: Reentrancy
Date: 20230203
Lost: $3M
POC: https://github.com/SunWeb3Sec/DeFiHackLabs/blob/main/src/test/Orion_exp.sol
Title: Orion Protocol

**Root cause:** 

Reentrancy in the doSwapThroughOrionPool function

The doswapThroughOrionPool function allows a user-provided swap path to be used with malicious tokens that can be used to re-enter deposits.

After the transfer happens, the curBalance is updated. Therefore, a callback function is added to the transfer in the fake token. The callback code calls the depositAsset function, causing the curBalance to be updated incorrectly. Then, the attacker calls the withdraw function to take away the funds after paying back the flash loan.

**Vulnerable code snippet:**

[https://etherscan.io/address/0x420a50a62b17c18b36c64478784536ba980feac8#code#F1#L78](https://etherscan.io/address/0x420a50a62b17c18b36c64478784536ba980feac8#code#F1#L78)

```solidity
function doSwapThroughOrionPool(
        address user,
        address to,
        IPoolFunctionality.SwapData calldata swapData
    ) external override returns (uint256 amountOut, uint256 amountIn) {
        bool withFactory = swapData.path.length > 2 &&
            (supportedFactories[swapData.path[0]] != FactoryType.UNSUPPORTED);
        address curFactory = withFactory ? swapData.path[0] : factory;
        address[] memory new_path;

        uint256 tokenIndex = withFactory ? 1 : 0;
        new_path = new address[](swapData.path.length - tokenIndex);

        for ((uint256 i, uint256 j) = (tokenIndex, 0); i < swapData.path.length; (++i, ++j)) {
            new_path[j] = swapData.path[i] == address(0) ? WETH : swapData.path[i];
        }

        (uint256 amount_spend_base_units, uint256 amount_receive_base_units) = (
            LibUnitConverter.decimalToBaseUnit(
                swapData.path[tokenIndex],
                swapData.amount_spend
            ),
            LibUnitConverter.decimalToBaseUnit(
                swapData.path[swapData.path.length - 1],
                swapData.amount_receive
            )
        );
        {
        (uint256 userAmountIn, uint256 userAmountOut) = _doSwapTokens(InternalSwapData( **//vulnerable point**
            user,
            amount_spend_base_units,
            amount_receive_base_units,
            withFactory ? swapData.path[1] : swapData.path[0],
            new_path,
            swapData.is_exact_spend,
            to,
            curFactory,
            supportedFactories[curFactory],
            swapData.supportingFee
        ));

        //  Anyway user gave amounts[0] and received amounts[len-1]
        amountOut = LibUnitConverter.baseUnitToDecimal(
            swapData.path[tokenIndex],
            userAmountIn
        );
        amountIn = LibUnitConverter.baseUnitToDecimal(
            swapData.path[swapData.path.length - 1],
            userAmountOut
        );
        }
    }
```

**Attack tx:**

[https://etherscan.io/tx/0xa6f63fcb6bec8818864d96a5b1bb19e8bd85ee37b2cc916412e720988440b2aa](https://etherscan.io/tx/0xa6f63fcb6bec8818864d96a5b1bb19e8bd85ee37b2cc916412e720988440b2aa)

[https://bscscan.com/tx/0xfb153c572e304093023b4f9694ef39135b6ed5b2515453173e81ec02df2e2104](https://bscscan.com/tx/0xfb153c572e304093023b4f9694ef39135b6ed5b2515453173e81ec02df2e2104)

**Analysis:**

[https://twitter.com/BlockSecTeam/status/1621263393054420992](https://twitter.com/BlockSecTeam/status/1621263393054420992)

[https://www.numencyber.com/analysis-of-orionprotocol-reentrancy-attack-with-poc/](https://www.numencyber.com/analysis-of-orionprotocol-reentrancy-attack-with-poc/)

**Similar events**
[https://github.com/SunWeb3Sec/DeFiHackLabs#20221223---defrost---reentrancy](https://github.com/SunWeb3Sec/DeFiHackLabs#20221223---defrost---reentrancy)
[https://github.com/SunWeb3Sec/DeFiHackLabs#20221110---dfxfinance---reentrancy](https://github.com/SunWeb3Sec/DeFiHackLabs#20221110---dfxfinance---reentrancy)